// login.js
// Handles: Sign In tab + Register tab only.
// The "Have an Invite" tab has been removed — invited users simply
// use their email and the temp password from the invitation email
// on the normal Sign In tab. auth:login auto-claims their account.
'use strict';

// ── Tab switcher ──────────────────────────────────────────────
function switchTab(name) {
  ['Login', 'Register'].forEach(function(t) {
    var panel  = document.getElementById('panel' + t);
    var tabBtn = document.getElementById('tabBtn' + t);
    if (!panel || !tabBtn) return;
    panel.classList.toggle('active', t === name);
    tabBtn.classList.toggle('active', t === name);
  });
}

document.getElementById('tabBtnLogin').addEventListener('click', function() { switchTab('Login'); });
document.getElementById('tabBtnRegister').addEventListener('click', function() { switchTab('Register'); });

document.getElementById('goToRegister').addEventListener('click', function(e) {
  e.preventDefault(); switchTab('Register');
});
document.getElementById('goToLoginFromRegister').addEventListener('click', function(e) {
  e.preventDefault(); switchTab('Login');
});

// ── Password eye toggle — Sign In ─────────────────────────────
var passwordInput     = document.getElementById('passwordInput');
var togglePasswordBtn = document.getElementById('togglePassword');

function togglePassword() {
  if (!passwordInput || !togglePasswordBtn) return;
  var isPassword = passwordInput.type === 'password';
  passwordInput.type = isPassword ? 'text' : 'password';
  var eye    = '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#444" viewBox="0 0 24 24"><path d="M12 5c-7 0-11 7-11 7s4 7 11 7 11-7 11-7-4-7-11-7zm0 12a5 5 0 110-10 5 5 0 010 10z"/></svg>';
  var eyeOff = '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#444" viewBox="0 0 24 24"><path d="M1 1l22 22-1.5 1.5L18 19.5c-1.8 1-3.8 1.5-6 1.5-7 0-11-7-11-7 1.3-2.3 3.1-4.3 5.3-5.7L1 2.5 1 1zm11 4c7 0 11 7 11 7-.7 1.2-1.6 2.4-2.7 3.3L10.3 5.3c.5-.2 1.1-.3 1.7-.3z"/></svg>';
  togglePasswordBtn.innerHTML = isPassword ? eyeOff : eye;
  togglePasswordBtn.setAttribute('aria-label', isPassword ? 'Hide password' : 'Show password');
}

if (passwordInput && togglePasswordBtn) {
  togglePasswordBtn.addEventListener('click', togglePassword);
  togglePasswordBtn.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); togglePassword(); }
  });
}

// ── Password eye toggle — Register ────────────────────────────
var regPwInput  = document.getElementById('registerPasswordInline');
var regPwToggle = document.getElementById('toggleRegisterPasswordInline');

function toggleRegisterPw() {
  if (!regPwInput || !regPwToggle) return;
  var isPassword = regPwInput.type === 'password';
  regPwInput.type = isPassword ? 'text' : 'password';
  regPwToggle.textContent = isPassword ? '\uD83D\uDE48' : '\uD83D\uDC41\uFE0F';
  regPwToggle.setAttribute('aria-label', isPassword ? 'Hide password' : 'Show password');
}

if (regPwInput && regPwToggle) {
  regPwToggle.addEventListener('click', toggleRegisterPw);
  regPwToggle.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleRegisterPw(); }
  });
}

// ── Sign In form ──────────────────────────────────────────────
document.getElementById('loginForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  var data = Object.fromEntries(new FormData(e.target));
  var messageEl = document.getElementById('loginMessage');
  messageEl.textContent = '';

  // Default is now 'offline' — matches the checked radio in login.html
  var selectedMode = document.querySelector('input[name="mode"]:checked')?.value || 'offline';
  localStorage.setItem('qaModel', selectedMode);

  try {
    var res = await window.api.login(data);
    if (res && res.token) {
      localStorage.setItem('token', res.token);
      window.api.navigateTo('index.html');
    } else {
      messageEl.style.color = 'red';
      messageEl.textContent = (res && res.error) || 'Login failed';
    }
  } catch (err) {
    messageEl.style.color = 'red';
    messageEl.textContent = 'Error: ' + err.message;
  }
});

// ── Register form ─────────────────────────────────────────────
document.getElementById('registerFormInline').addEventListener('submit', async function(e) {
  e.preventDefault();
  var data = Object.fromEntries(new FormData(e.target));
  var msgEl = document.getElementById('registerMessageInline');
  msgEl.textContent = ''; msgEl.style.color = 'red';

  if (!data.name || !data.name.trim()) { msgEl.textContent = 'Please enter your name.'; return; }
  if (!data.email)                     { msgEl.textContent = 'Please enter your email.'; return; }
  if (!data.password || data.password.length < 6) { msgEl.textContent = 'Password must be at least 6 characters.'; return; }

  try {
    var res = await window.api.register({ email: data.email, password: data.password });
    if (res && res.success) {
      msgEl.style.color = 'green'; msgEl.textContent = 'Account created! Signing you in\u2026';
      var loginRes = await window.api.login({ email: data.email, password: data.password });
      if (loginRes && loginRes.token) {
        if (window.api.updateUserProfile) {
          try { await window.api.updateUserProfile({ name: data.name.trim() }, loginRes.token); } catch (_) {}
        }
        // New accounts default to offline mode
        localStorage.setItem('qaModel', 'offline');
        localStorage.setItem('token', loginRes.token);
        window.api.navigateTo('index.html');
      } else {
        msgEl.style.color = 'red';
        msgEl.textContent = (loginRes && loginRes.error) || 'Account created but login failed. Please sign in.';
      }
    } else {
      msgEl.textContent = (res && res.error) || 'Registration failed.';
    }
  } catch (err) {
    msgEl.textContent = 'Error: ' + err.message;
  }
});

// ── Auto-redirect if already logged in ────────────────────────
(function checkExistingSession() {
  var token = localStorage.getItem('token');
  if (!token) return;
  window.api.getCurrentUser(token).then(function(r) {
    if (r && r.success) window.api.navigateTo('index.html');
  }).catch(function() {});
})();