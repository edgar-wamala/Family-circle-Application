//p2pClient.js
const DEFAULT_SERVER = 'http://localhost:5020';
const urlServer = new URLSearchParams(location.search).get('server');
const SERVER = (urlServer && urlServer.trim()) || DEFAULT_SERVER;
const API = SERVER;
const WS_URL = (() => {
  try {
    const u = new URL(SERVER);
    return (u.protocol === 'https:' ? 'wss:' : 'ws:') + '//' + u.host;
  } catch {
    return 'ws://localhost:5020';
  }
})();

/* ============================= DOM ============================= */
const statusEl = document.getElementById('status');
const inlineMsg = document.getElementById('inlineMsg');

const selectedGroupIdEl = document.getElementById('selectedGroupId');
const selectedGroupNameEl = document.getElementById('selectedGroupName');

const sidebarGroupName = document.getElementById('sidebarGroupName');
const topGroupName = document.getElementById('topGroupName');

const inviteNotificationList = document.getElementById('inviteNotificationList');
const groupPicker = document.getElementById('groupPicker');
const groupPickerWrap = document.getElementById('groupPickerWrap');
const createGroupNameInput = document.getElementById('createGroupNameInput');
const createGroupBtn = document.getElementById('createGroupBtn');
const noGroupState = document.getElementById('noGroupState');

const notifBellBtn = document.getElementById('notifBellBtn');
const notifDropdown = document.getElementById('notifDropdown');
const inviteBellCount = document.getElementById('inviteBellCount');
const inviteMembersPanel = document.getElementById('inviteMembersPanel');

const circleTreeView = document.getElementById('circleTreeView');
const circleManageView = document.getElementById('circleManageView');
const circleManageBtn = document.getElementById('circleManageBtn');
const circleBackToTreeBtn = document.getElementById('circleBackToTreeBtn');
const circleTreeCanvas = document.getElementById('circleTreeCanvas');
const circleTreeLines = document.getElementById('circleTreeLines');
const circleTreeRefreshBtn = document.getElementById('circleTreeRefreshBtn');
const circleAutoLayoutBtn = document.getElementById('circleAutoLayoutBtn');

const circleInviteEmailEl = document.getElementById('circleInviteEmail');
const circleInviteBtn = document.getElementById('circleInviteBtn');
const circleRefreshBtn = document.getElementById('circleRefreshBtn');
const circlePeopleList = document.getElementById('circlePeopleList');

const circleNameInput = document.getElementById('circleNameInput');
const circleRenameBtn = document.getElementById('circleRenameBtn');

const phName = document.getElementById('phName');
const phEmail = document.getElementById('phEmail');
const phAddBtn = document.getElementById('phAddBtn');

const relASelect = document.getElementById('relASelect');
const relBSelect = document.getElementById('relBSelect');
const relKindSelect = document.getElementById('relKindSelect');
const relAddBtn = document.getElementById('relAddBtn');
const relList = document.getElementById('relList');

const memberProfileModalEl = document.getElementById('memberProfileModal');
const memberProfileModalTitle = document.getElementById('memberProfileModalTitle');
const memberProfileModalBody = document.getElementById('memberProfileModalBody');

/* ============================= State ============================= */
let currentUser = null;
let currentGroupId = null;
let currentGroupOwnerId = null;
let availableGroups = [];

let ws = null;
let authed = false;

let lastTree = {
  group: null,
  people: [],
  relations: [],
  positions: [],
  invites: []
};

const nodeEls = new Map();
let memberProfileModal = null;

/* ============================= Helpers ============================= */
function setStatus(t) {
  if (statusEl) statusEl.textContent = t;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, m => ({
    '&':'&amp;',
    '<':'&lt;',
    '>':'&gt;',
    '"':'&quot;',
    "'":"&#39;"
  }[m]));
}

let msgHideTimer = null;
function showInline(text) {
  if (!inlineMsg) return console.log('[NOTICE]', text);
  inlineMsg.textContent = text;
  inlineMsg.classList.remove('d-none', 'hidden');
  clearTimeout(msgHideTimer);
  msgHideTimer = setTimeout(() => inlineMsg.classList.add('d-none'), 5000);
}

function setBusy(btn, busyText) {
  if (!btn) return () => {};
  const orig = btn.textContent;
  btn.disabled = true;
  btn.textContent = busyText || 'Working…';
  return () => {
    btn.disabled = false;
    btn.textContent = orig;
  };
}

function initialsFrom(nameOrEmail) {
  const s = String(nameOrEmail || '').trim();
  if (!s) return '?';
  const parts = s.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

function avatarHTML(label) {
  const initials = initialsFrom(label);
  return `<span class="avatar" aria-hidden="true">${escapeHtml(initials)}</span>`;
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function setGroupName(name) {
  const safe = name || 'No Group Selected';
  if (selectedGroupNameEl) selectedGroupNameEl.value = safe;
  if (circleNameInput) circleNameInput.value = name || '';
  if (sidebarGroupName) sidebarGroupName.textContent = safe;
  if (topGroupName) topGroupName.textContent = name || '';
}

function clearTreeUI() {
  lastTree = {
    group: null,
    people: [],
    relations: [],
    positions: [],
    invites: []
  };

  if (circlePeopleList) {
    circlePeopleList.innerHTML = `<div class="text-muted">No family circle selected yet.</div>`;
  }
  if (relList) {
    relList.innerHTML = `<div class="text-muted">No relationships to show.</div>`;
  }
  if (relASelect) relASelect.innerHTML = '';
  if (relBSelect) relBSelect.innerHTML = '';

  if (circleTreeCanvas) {
    [...circleTreeCanvas.querySelectorAll('.tree-node')].forEach(n => n.remove());
  }
  if (circleTreeLines) {
    circleTreeLines.innerHTML = '';
  }
}

function updateNoGroupState() {
  const hasGroups = availableGroups.length > 0;
  if (noGroupState) noGroupState.classList.toggle('hidden', hasGroups);
  if (groupPickerWrap) groupPickerWrap.classList.toggle('hidden', !hasGroups);
}

function isCurrentUserOwner() {
  return currentUser?.id && currentGroupOwnerId && currentUser.id === currentGroupOwnerId;
}

/* Relationship label helpers */
const REL_LABEL = {
  mother: 'Mother',
  father: 'Father',
  spouse: 'Spouse',
  friend: 'Friend',
  guardian: 'Guardian',
  grandparent: 'Grandparent',
  aunt_uncle: 'Aunt/Uncle',
  sibling: 'Sibling',
  cousin: 'Cousin'
};

const UNDIRECTED = new Set(['spouse', 'friend', 'sibling', 'cousin']);

/* ============================= REST ============================= */
async function postJSON(url, body) {
  const res = await fetch(url, {
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify(body || {})
  });

  let data = null;
  try {
    data = await res.json();
  } catch {}

  if (!res.ok) {
    throw new Error((data && data.error) || res.statusText || 'Request failed');
  }

  return data || {};
}

/* ============================= SSO bootstrap ============================= */
async function bootstrapFromMainApp() {
  const token = localStorage.getItem('token');
  if (!token) throw new Error('No session token. Please sign in from the main app.');

  const res = await window.api.getCurrentUser(token);
  if (!res?.success || !res.data?.email) {
    throw new Error(res?.error || 'Not authenticated');
  }

  const localUser = res.data;
  currentUser = {
    email: localUser.email,
    name: localUser.name || localUser.email
  };

  localStorage.setItem('user', JSON.stringify(currentUser));
  setStatus(`Signed in as ${currentUser.name}`);
}

/* ============================= WebSocket auth ============================= */
function connectWS() {
  ws = new WebSocket(WS_URL);

  ws.onopen = () => {
    setStatus('WebSocket connected.');
    authed = false;
    if (currentUser) {
      ws.send(JSON.stringify({
        type:'auth',
        userId: currentUser.id,
        email: currentUser.email,
        name: currentUser.name
      }));
    }
  };

  ws.onclose = () => {
    setStatus('WebSocket disconnected.');
    authed = false;
  };

  ws.onerror = (e) => {
    console.error('WS error', e);
    setStatus('WebSocket error.');
  };

  ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }

    if (msg.type === 'auth-ok') {
      authed = true;
      currentUser = { id: msg.userId, email: msg.email, name: msg.name };
      localStorage.setItem('user', JSON.stringify(currentUser));
      setStatus(`Authenticated as ${currentUser.name}`);
    }

    if (msg.type === 'auth-error') {
      authed = false;
      showInline(`Auth failed: ${msg.reason || 'unknown'}`);
    }
  };
}

async function ensureWSAuthed() {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    connectWS();
    await new Promise(res => {
      if (!ws) return res();
      if (ws.readyState === WebSocket.OPEN) return res();
      ws.addEventListener('open', res, { once:true });
    });
  }

  if (!authed && currentUser) {
    ws.send(JSON.stringify({
      type:'auth',
      userId: currentUser.id,
      email: currentUser.email,
      name: currentUser.name
    }));

    await new Promise((res, rej) => {
      const onMsg = (ev) => {
        let m;
        try { m = JSON.parse(ev.data); } catch { return; }

        if (m.type === 'auth-ok') {
          ws.removeEventListener('message', onMsg);
          authed = true;
          res();
        }

        if (m.type === 'auth-error') {
          ws.removeEventListener('message', onMsg);
          rej(new Error(m.reason || 'auth-error'));
        }
      };

      ws.addEventListener('message', onMsg);

      setTimeout(() => {
        ws.removeEventListener('message', onMsg);
        if (!authed) rej(new Error('auth timeout'));
      }, 5000);
    }).catch(e => showInline(`Auth error: ${e.message}`));
  }
}

/* ============================= Groups ============================= */
function renderGroupPicker() {
  if (!groupPicker) return;

  groupPicker.innerHTML = '';

  if (!availableGroups.length) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = 'No groups available';
    groupPicker.appendChild(opt);
    groupPicker.value = '';
    return;
  }

  availableGroups.forEach(g => {
    const opt = document.createElement('option');
    opt.value = g.id;
    opt.textContent = g.name;
    groupPicker.appendChild(opt);
  });

  if (currentGroupId) {
    groupPicker.value = currentGroupId;
  }
}

async function refreshGroups(preferredGroupId = null) {
  if (!currentUser?.id) return;

  const res = await fetch(`${API}/api/me/${currentUser.id}/groups`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Could not load groups');

  const groups = data.groups || [];
  availableGroups = groups;

  if (!groups.length) {
    currentGroupId = null;
    currentGroupOwnerId = null;
    setGroupName('No Group Selected');
    renderGroupPicker();
    updateNoGroupState();
    clearTreeUI();
    return;
  }

  const selected =
    groups.find(g => g.id === preferredGroupId) ||
    groups.find(g => g.id === currentGroupId) ||
    groups[0];

  currentGroupId = selected.id;
  currentGroupOwnerId = selected.ownerId;

  if (selectedGroupIdEl) selectedGroupIdEl.value = selected.id;
  setGroupName(selected.name);

  renderGroupPicker();
  updateNoGroupState();
}

/* ============================= Invitation notifications ============================= */
function renderInviteNotifications(invites) {
  if (!inviteNotificationList || !inviteBellCount) return;

  const rows = invites || [];
  inviteNotificationList.innerHTML = '';

  if (rows.length) {
    inviteBellCount.textContent = String(rows.length);
    inviteBellCount.classList.remove('hidden');
  } else {
    inviteBellCount.textContent = '0';
    inviteBellCount.classList.add('hidden');
  }

  if (!rows.length) {
    inviteNotificationList.innerHTML = `<div class="text-muted small">No pending invitations.</div>`;
    return;
  }

  rows.forEach(inv => {
    const created = inv.createdAt ? new Date(inv.createdAt).toLocaleString() : '';
    const card = document.createElement('div');
    card.className = 'notif-item';

    card.innerHTML = `
      <div class="fw-semibold">${escapeHtml(inv.groupName || 'Family Circle')}</div>
      <div class="small text-muted">Invited by ${escapeHtml(inv.ownerName || 'Group Owner')}</div>
      ${created ? `<div class="small text-muted mb-2">Sent: ${escapeHtml(created)}</div>` : `<div class="mb-2"></div>`}
      <div class="d-flex gap-2">
        <button class="btn btn-success btn-sm" data-accept-token="${escapeHtml(inv.token)}">Accept</button>
        <button class="btn btn-outline-danger btn-sm" data-reject-token="${escapeHtml(inv.token)}">Reject</button>
      </div>
    `;

    inviteNotificationList.appendChild(card);
  });

  inviteNotificationList.querySelectorAll('[data-accept-token]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const token = btn.getAttribute('data-accept-token');
      const done = setBusy(btn, 'Accepting…');

      try {
        const out = await postJSON(`${API}/api/invitations/respond`, {
          token,
          userId: currentUser.id,
          action: 'accept'
        });

        showInline('Invitation accepted.');
        if (notifDropdown) notifDropdown.classList.remove('open');
        await refreshGroups(out.groupId || null);
        await refreshInvitations();
        await refreshCircle(true);
      } catch (e) {
        showInline(`Accept failed: ${e.message}`);
      } finally {
        done();
      }
    });
  });

  inviteNotificationList.querySelectorAll('[data-reject-token]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const token = btn.getAttribute('data-reject-token');
      const done = setBusy(btn, 'Rejecting…');

      try {
        await postJSON(`${API}/api/invitations/respond`, {
          token,
          userId: currentUser.id,
          action: 'reject'
        });

        showInline('Invitation rejected.');
        await refreshInvitations();
      } catch (e) {
        showInline(`Reject failed: ${e.message}`);
      } finally {
        done();
      }
    });
  });
}

async function refreshInvitations() {
  if (!currentUser?.id) return;

  try {
    const res = await fetch(`${API}/api/me/${currentUser.id}/invitations`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not load invitations');
    renderInviteNotifications(data.invitations || []);
  } catch (e) {
    showInline(`Could not load invitations: ${e.message}`);
  }
}

/* ============================= Auto-layout engine ============================= */
function computeAutoLayout(tree, canvasW, canvasH) {
  const people = tree.people || [];
  const rels = tree.relations || [];

  const nodeW = 180;
  const nodeH = 172;
  const padX = 22;
  const padY = 22;
  const levelGapY = 165;

  const byId = new Map(people.map(p => [p.id, p]));
  const parentsOf = new Map();
  const childrenOf = new Map();
  const spousesOf = new Map();

  function addToMapSet(map, k, v) {
    if (!map.has(k)) map.set(k, new Set());
    map.get(k).add(v);
  }

  for (const r of rels) {
    if (r.kind === 'mother' || r.kind === 'father') {
      addToMapSet(parentsOf, r.b_person_id, r.a_person_id);
      addToMapSet(childrenOf, r.a_person_id, r.b_person_id);
    } else if (r.kind === 'spouse') {
      addToMapSet(spousesOf, r.a_person_id, r.b_person_id);
      addToMapSet(spousesOf, r.b_person_id, r.a_person_id);
    }
  }

  const level = new Map();
  const indeg = new Map();

  for (const p of people) indeg.set(p.id, 0);
  for (const [child, ps] of parentsOf.entries()) {
    indeg.set(child, (indeg.get(child) || 0) + ps.size);
  }

  const queue = [];
  for (const p of people) {
    if ((indeg.get(p.id) || 0) === 0) {
      level.set(p.id, 0);
      queue.push(p.id);
    }
  }

  if (queue.length === 0 && people.length) {
    for (const p of people) level.set(p.id, 0);
    queue.push(people[0].id);
  }

  while (queue.length) {
    const u = queue.shift();
    const uLvl = level.get(u) ?? 0;
    const kids = childrenOf.get(u);
    if (!kids) continue;

    for (const v of kids) {
      const nextLvl = Math.max(level.get(v) ?? 0, uLvl + 1);
      level.set(v, nextLvl);
      indeg.set(v, (indeg.get(v) || 1) - 1);
      if ((indeg.get(v) || 0) <= 0) queue.push(v);
    }
  }

  for (const p of people) {
    if (!level.has(p.id)) level.set(p.id, 0);
  }

  const levels = new Map();
  for (const p of people) {
    const lvl = level.get(p.id) || 0;
    if (!levels.has(lvl)) levels.set(lvl, []);
    levels.get(lvl).push(p.id);
  }

  const parentSig = new Map();
  for (const p of people) {
    const ps = [...(parentsOf.get(p.id) || [])].sort();
    parentSig.set(p.id, ps.join('|'));
  }

  for (const [lvl, arr] of levels.entries()) {
    arr.sort((a, b) => {
      const sa = parentSig.get(a) || '';
      const sb = parentSig.get(b) || '';
      if (sa !== sb) return sa.localeCompare(sb);
      const na = (byId.get(a)?.name || '').toLowerCase();
      const nb = (byId.get(b)?.name || '').toLowerCase();
      return na.localeCompare(nb);
    });
  }

  function reorderWithSpouses(ids) {
    const used = new Set();
    const out = [];

    for (const id of ids) {
      if (used.has(id)) continue;
      used.add(id);
      out.push(id);

      const sp = spousesOf.get(id);
      if (sp) {
        const spouseInLevel = [...sp].find(sid => !used.has(sid) && ids.includes(sid));
        if (spouseInLevel) {
          used.add(spouseInLevel);
          out.push(spouseInLevel);
        }
      }
    }

    return out;
  }

  for (const [lvl, arr] of levels.entries()) {
    levels.set(lvl, reorderWithSpouses(arr));
  }

  const layout = new Map();
  const maxLvl = Math.max(...[...levels.keys(), 0]);
  const usableW = Math.max(260, canvasW - padX * 2);

  for (let lvl = 0; lvl <= maxLvl; lvl++) {
    const ids = levels.get(lvl) || [];
    const count = ids.length || 1;

    const gap = Math.max(18, Math.floor((usableW - count * nodeW) / Math.max(1, count - 1)));
    const totalW = count * nodeW + (count - 1) * gap;
    let startX = Math.floor((canvasW - totalW) / 2);
    startX = clamp(startX, padX, padX + 40);

    const y = padY + lvl * levelGapY;
    ids.forEach((id, i) => {
      const x = startX + i * (nodeW + gap);
      layout.set(id, {
        x: clamp(x, 6, canvasW - nodeW - 6),
        y: clamp(y, 6, canvasH - nodeH - 6)
      });
    });
  }

  return layout;
}

/* ============================= Tree rendering ============================= */
function buildPositionMap(positionsArr) {
  const m = new Map();
  (positionsArr || []).forEach(p => {
    if (!p?.person_id) return;
    m.set(p.person_id, { x: Number(p.x), y: Number(p.y) });
  });
  return m;
}

function openMemberProfile(person) {
  if (!memberProfileModalEl || !memberProfileModalTitle || !memberProfileModalBody || !person) return;

  if (!memberProfileModal && window.bootstrap?.Modal) {
    memberProfileModal = new window.bootstrap.Modal(memberProfileModalEl);
  }

  const isMe = person.kind === 'user' && person.user_id === currentUser?.id;
  const roleText = person.kind === 'user' ? (person.role || 'member') : 'Pending / external';
  const kindText = person.kind || 'member';

  memberProfileModalTitle.textContent = person.name || person.email || 'Member Profile';
  memberProfileModalBody.innerHTML = `
    <div class="text-center mb-3">
      ${avatarHTML(person.name || person.email || '?')}
    </div>

    <div class="mb-3">
      <div class="profile-detail-label">Name</div>
      <div class="profile-detail-value">${escapeHtml(person.name || 'Unknown')}</div>
    </div>

    <div class="mb-3">
      <div class="profile-detail-label">Email</div>
      <div class="profile-detail-value">${escapeHtml(person.email || 'No email')}</div>
    </div>

    <div class="mb-3">
      <div class="profile-detail-label">Profile Type</div>
      <div class="profile-detail-value">${escapeHtml(kindText)}</div>
    </div>

    <div class="mb-3">
      <div class="profile-detail-label">Group Role</div>
      <div class="profile-detail-value">${escapeHtml(roleText)}</div>
    </div>

    <div>
      ${isMe ? '<span class="badge bg-primary">You</span>' : ''}
      ${person.kind !== 'user' ? `<span class="badge badge-kind">${escapeHtml(kindText)}</span>` : ''}
      ${person.kind === 'user' ? `<span class="badge badge-role">${escapeHtml(person.role || 'member')}</span>` : ''}
    </div>
  `;

  memberProfileModal?.show();
}

function renderTree(tree, forceAutoLayout = false) {
  if (!circleTreeCanvas || !circleTreeLines) return;

  nodeEls.clear();
  [...circleTreeCanvas.querySelectorAll('.tree-node')].forEach(n => n.remove());
  circleTreeLines.innerHTML = '';

  const W = circleTreeCanvas.clientWidth || 900;
  const H = circleTreeCanvas.clientHeight || 620;
  circleTreeLines.setAttribute('viewBox', `0 0 ${W} ${H}`);
  circleTreeLines.setAttribute('preserveAspectRatio', 'none');

  const savedPos = buildPositionMap(tree.positions);
  const hasAnySaved = (tree.positions || []).length > 0;
  const autoLayout = computeAutoLayout(tree, W, H);

  const people = tree.people || [];

  if (!people.length) {
    const empty = document.createElement('div');
    empty.className = 'tree-empty';
    empty.textContent = 'No people have been added to this family circle yet.';
    circleTreeCanvas.appendChild(empty);
    return;
  }

  people.forEach(p => {
    const el = document.createElement('div');
    el.className = 'tree-node';
    el.dataset.personId = p.id;

    const isMe = (p.kind === 'user' && p.user_id === currentUser?.id);
    const badgeYou = isMe ? `<span class="badge bg-primary">You</span>` : '';
    const badgeKind = p.kind !== 'user' ? `<span class="badge badge-kind">${escapeHtml(p.kind)}</span>` : '';
    const badgeRole = p.kind === 'user' ? `<span class="badge badge-role">${escapeHtml(p.role || 'member')}</span>` : '';
    const emailText = p.email
      ? `<div class="email">${escapeHtml(p.email)}</div>`
      : `<div class="email text-muted">No email</div>`;

    el.innerHTML = `
      <div class="profile-card">
        ${avatarHTML(p.name || p.email || '?')}
        <div class="name">${escapeHtml(p.name || p.email || 'Unknown')}</div>
        ${emailText}
        <div class="meta-badges">
          ${badgeYou}
          ${badgeKind}
          ${badgeRole}
        </div>
        <div class="profile-link" data-profile="${escapeHtml(p.id)}">View profile</div>
        ${isCurrentUserOwner() ? `<div class="quick" data-quick="${escapeHtml(p.id)}">Set relationship</div>` : ''}
      </div>
    `;

    const nodeW = 180;
    const nodeH = 172;

    let pos = null;
    if (!forceAutoLayout && hasAnySaved) pos = savedPos.get(p.id);
    if (!pos) {
      const a = autoLayout.get(p.id);
      pos = a ? { x: a.x, y: a.y } : { x: 30, y: 30 };
    }

    pos.x = clamp(pos.x, 6, W - nodeW - 6);
    pos.y = clamp(pos.y, 6, H - nodeH - 6);

    el.style.left = `${pos.x}px`;
    el.style.top = `${pos.y}px`;

    circleTreeCanvas.appendChild(el);
    nodeEls.set(p.id, el);

    enableDrag(el, p);

    el.querySelector('[data-profile]')?.addEventListener('click', (ev) => {
      ev.stopPropagation();
      openMemberProfile(p);
    });

    el.querySelector('[data-quick]')?.addEventListener('click', (ev) => {
      ev.stopPropagation();
      showManageView();

      if (relASelect && relBSelect) {
        relASelect.value = p.id;
        const mePerson = (tree.people || []).find(x => x.kind === 'user' && x.user_id === currentUser?.id);
        if (mePerson && mePerson.id !== p.id) relBSelect.value = mePerson.id;
      }

      relASelect?.focus();
    });

    el.addEventListener('dblclick', () => openMemberProfile(p));
  });

  drawLines(tree);
}

function nodeBox(personId) {
  const el = nodeEls.get(personId);
  if (!el) return null;

  const x = parseFloat(el.style.left || '0');
  const y = parseFloat(el.style.top || '0');
  const w = el.offsetWidth || 180;
  const h = el.offsetHeight || 172;

  return {
    x, y, w, h,
    cx: x + w / 2,
    cy: y + h / 2
  };
}

function styleForKind(kind) {
  const base = { stroke: '#205081', width: 2, opacity: 0.75, dash: null };

  switch (kind) {
    case 'mother': return { ...base, width: 3, opacity: 0.9, dash: null };
    case 'father': return { ...base, width: 2, opacity: 0.9, dash: '6 4' };
    case 'guardian': return { ...base, width: 2, opacity: 0.8, dash: '10 5' };
    case 'grandparent': return { ...base, width: 2, opacity: 0.6, dash: '3 7' };
    case 'aunt_uncle': return { ...base, width: 2, opacity: 0.6, dash: '2 2' };

    case 'spouse': return { ...base, width: 2, opacity: 0.6, dash: '2 6' };
    case 'friend': return { ...base, width: 2, opacity: 0.55, dash: '1 6' };
    case 'sibling': return { ...base, width: 2, opacity: 0.55, dash: '6 10' };
    case 'cousin': return { ...base, width: 2, opacity: 0.5, dash: '12 6' };

    default: return base;
  }
}

function drawLines(tree) {
  if (!circleTreeLines) return;
  circleTreeLines.innerHTML = '';

  const rels = tree.relations || [];
  for (const r of rels) {
    const A = nodeBox(r.a_person_id);
    const B = nodeBox(r.b_person_id);
    if (!A || !B) continue;

    let x1, y1, x2, y2;

    if (UNDIRECTED.has(r.kind)) {
      x1 = A.cx;
      y1 = A.cy;
      x2 = B.cx;
      y2 = B.cy;
    } else {
      x1 = A.cx;
      y1 = A.y + A.h;
      x2 = B.cx;
      y2 = B.y;
    }

    const st = styleForKind(r.kind);

    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', String(x1));
    line.setAttribute('y1', String(y1));
    line.setAttribute('x2', String(x2));
    line.setAttribute('y2', String(y2));
    line.setAttribute('stroke', st.stroke);
    line.setAttribute('stroke-width', String(st.width));
    line.setAttribute('opacity', String(st.opacity));
    if (st.dash) line.setAttribute('stroke-dasharray', st.dash);
    circleTreeLines.appendChild(line);

    const label = REL_LABEL[r.kind] || r.kind;
    const mx = (x1 + x2) / 2;
    const my = (y1 + y2) / 2;

    const approxW = clamp(8 * label.length + 16, 56, 140);
    const boxH = 18;

    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', String(mx - approxW / 2));
    rect.setAttribute('y', String(my - boxH / 2 - 8));
    rect.setAttribute('width', String(approxW));
    rect.setAttribute('height', String(boxH));
    rect.setAttribute('rx', '9');
    rect.setAttribute('ry', '9');
    rect.setAttribute('fill', 'rgba(255,255,255,0.90)');
    rect.setAttribute('stroke', 'rgba(32,80,129,0.25)');
    rect.setAttribute('stroke-width', '1');
    circleTreeLines.appendChild(rect);

    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', String(mx));
    text.setAttribute('y', String(my - 8 + 1));
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('dominant-baseline', 'middle');
    text.setAttribute('fill', '#205081');
    text.setAttribute('font-size', '11');
    text.setAttribute('font-weight', '700');
    text.textContent = label;
    circleTreeLines.appendChild(text);
  }
}

/* ============================= Dragging ============================= */
function enableDrag(el, person) {
  const isOwner = currentUser?.id && currentGroupOwnerId && currentUser.id === currentGroupOwnerId;
  const canMove = isOwner || (person.kind === 'user' && person.user_id === currentUser?.id);
  if (!canMove) return;

  let dragging = false;
  let startX = 0, startY = 0;
  let origLeft = 0, origTop = 0;

  function pointerDown(e) {
    if (e.target && e.target.closest && (e.target.closest('.quick') || e.target.closest('.profile-link'))) {
      return;
    }

    dragging = true;
    el.classList.add('dragging');

    const rect = circleTreeCanvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    startX = clientX - rect.left;
    startY = clientY - rect.top;

    origLeft = parseFloat(el.style.left || '0');
    origTop = parseFloat(el.style.top || '0');

    e.preventDefault?.();
  }

  function pointerMove(e) {
    if (!dragging) return;

    const rect = circleTreeCanvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    const dx = x - startX;
    const dy = y - startY;

    const nodeW = el.offsetWidth || 180;
    const nodeH = el.offsetHeight || 172;
    const W = circleTreeCanvas.clientWidth || 900;
    const H = circleTreeCanvas.clientHeight || 620;

    el.style.left = `${clamp(origLeft + dx, 6, W - nodeW - 6)}px`;
    el.style.top = `${clamp(origTop + dy, 6, H - nodeH - 6)}px`;

    drawLines(lastTree);
  }

  async function pointerUp() {
    if (!dragging) return;
    dragging = false;
    el.classList.remove('dragging');

    if (!currentGroupId) return;

    const x = Math.round(parseFloat(el.style.left || '0'));
    const y = Math.round(parseFloat(el.style.top || '0'));

    try {
      await postJSON(`${API}/api/group/${currentGroupId}/node/pos`, {
        fromUserId: currentUser.id,
        personId: person.id,
        x, y
      });

      const idx = (lastTree.positions || []).findIndex(p => p.person_id === person.id);
      const now = Date.now();

      if (idx >= 0) {
        lastTree.positions[idx] = { person_id: person.id, x, y, updated_at: now };
      } else {
        lastTree.positions.push({ person_id: person.id, x, y, updated_at: now });
      }
    } catch (e) {
      showInline(`Save position failed: ${e.message}`);
    }
  }

  el.addEventListener('mousedown', pointerDown);
  window.addEventListener('mousemove', pointerMove);
  window.addEventListener('mouseup', pointerUp);

  el.addEventListener('touchstart', pointerDown, { passive:false });
  window.addEventListener('touchmove', pointerMove, { passive:false });
  window.addEventListener('touchend', pointerUp);
}

/* ============================= Manage view ============================= */
function fillPeopleSelects(tree) {
  const people = (tree.people || []).slice();

  const label = (p) => {
    const tag = p.kind !== 'user' ? ` (${p.kind})` : '';
    return `${p.name || p.email || 'Unknown'}${tag}`;
  };

  function fill(sel) {
    if (!sel) return;
    sel.innerHTML = '';

    people.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = label(p);
      sel.appendChild(opt);
    });
  }

  fill(relASelect);
  fill(relBSelect);
}

function relationSentence(kind) {
  switch (kind) {
    case 'spouse': return 'is spouse of';
    case 'friend': return 'is friend of';
    case 'sibling': return 'is sibling of';
    case 'cousin': return 'is cousin of';
    case 'mother': return 'is mother of';
    case 'father': return 'is father of';
    case 'guardian': return 'is guardian of';
    case 'grandparent': return 'is grandparent of';
    case 'aunt_uncle': return 'is aunt/uncle of';
    default: return `is ${kind} of`;
  }
}

function renderRelationList(tree) {
  if (!relList) return;
  relList.innerHTML = '';

  const isOwner = currentUser?.id && currentGroupOwnerId && currentUser.id === currentGroupOwnerId;
  const byId = new Map((tree.people || []).map(p => [p.id, p]));
  const rels = tree.relations || [];

  if (!rels.length) {
    relList.textContent = 'No relationships set yet.';
    return;
  }

  rels.forEach(r => {
    const A = byId.get(r.a_person_id);
    const B = byId.get(r.b_person_id);
    const row = document.createElement('div');
    row.className = 'msg';

    const aName = escapeHtml(A?.name || A?.email || r.a_person_id);
    const bName = escapeHtml(B?.name || B?.email || r.b_person_id);

    row.innerHTML = `
      <div class="d-flex justify-content-between align-items-center gap-2 flex-wrap">
        <div>
          <strong>${aName}</strong>
          <span class="text-muted"> ${escapeHtml(relationSentence(r.kind))} </span>
          <strong>${bName}</strong>
          <span class="badge badge-kind ms-2">${escapeHtml(REL_LABEL[r.kind] || r.kind)}</span>
        </div>
        ${isOwner ? `<button class="btn btn-sm btn-outline-danger" data-rel-del="${escapeHtml(r.id)}">Delete</button>` : ''}
      </div>
    `;

    relList.appendChild(row);
  });

  if (isOwner) {
    relList.querySelectorAll('[data-rel-del]').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const rid = e.target.getAttribute('data-rel-del');

        try {
          await postJSON(`${API}/api/group/${currentGroupId}/relation/delete`, {
            fromUserId: currentUser.id,
            relationId: rid
          });

          showInline('Relationship deleted.');
          await refreshCircle();
        } catch (err) {
          showInline(`Delete failed: ${err.message}`);
        }
      });
    });
  }
}

function renderPeopleList(tree) {
  if (!circlePeopleList) return;
  circlePeopleList.innerHTML = '';

  const isOwner = currentUser?.id && currentGroupOwnerId && currentUser.id === currentGroupOwnerId;
  const people = tree.people || [];

  const byKind = {
    user: people.filter(p => p.kind === 'user'),
    placeholder: people.filter(p => p.kind === 'placeholder'),
    invite: people.filter(p => p.kind === 'invite')
  };

  function section(title) {
    const t = document.createElement('div');
    t.className = 'mt-2 mb-2';
    t.innerHTML = `<strong>${title}</strong>`;
    circlePeopleList.appendChild(t);
  }

  section('Members');
  if (!byKind.user.length) {
    const m = document.createElement('div');
    m.className = 'text-muted';
    m.textContent = 'No members yet.';
    circlePeopleList.appendChild(m);
  } else {
    byKind.user.forEach(p => {
      const isMe = p.user_id === currentUser?.id;
      const row = document.createElement('div');
      row.className = 'msg';

      row.innerHTML = `
        <div class="d-flex justify-content-between gap-2 flex-wrap">
          <div class="avatar-row">
            ${avatarHTML(p.name || p.email)}
            <div>
              <div><strong>${escapeHtml(p.name || p.email)}</strong> ${isMe ? `<span class="text-muted">(You)</span>` : ''}</div>
              <div class="small text-muted">${escapeHtml(p.email || '')}</div>
            </div>
          </div>
          <div class="member-actions">
            <span class="badge badge-role">${escapeHtml(p.role || 'member')}</span>
            <button class="btn btn-sm btn-outline-primary" data-profile-open="${escapeHtml(p.id)}">Profile</button>
          </div>
        </div>
      `;

      circlePeopleList.appendChild(row);
    });
  }

  section('Placeholders (no account)');
  if (!byKind.placeholder.length) {
    const m = document.createElement('div');
    m.className = 'text-muted';
    m.textContent = 'No placeholders yet.';
    circlePeopleList.appendChild(m);
  } else {
    byKind.placeholder.forEach(p => {
      const row = document.createElement('div');
      row.className = 'msg';
      row.innerHTML = `
        <div class="d-flex justify-content-between gap-2 flex-wrap">
          <div class="avatar-row">
            ${avatarHTML(p.name || '?')}
            <div>
              <div><strong>${escapeHtml(p.name || 'Unknown')}</strong> <span class="badge badge-kind">placeholder</span></div>
              ${p.email ? `<div class="small text-muted">${escapeHtml(p.email)}</div>` : `<div class="small text-muted">No email</div>`}
            </div>
          </div>
          <div>
            <button class="btn btn-sm btn-outline-primary" data-profile-open="${escapeHtml(p.id)}">Profile</button>
          </div>
        </div>
      `;
      circlePeopleList.appendChild(row);
    });
  }

  section('Pending invitations');
  if (!byKind.invite.length) {
    const m = document.createElement('div');
    m.className = 'text-muted';
    m.textContent = 'No pending invitations.';
    circlePeopleList.appendChild(m);
  } else {
    byKind.invite.forEach(p => {
      const row = document.createElement('div');
      row.className = 'msg';
      row.innerHTML = `
        <div class="d-flex justify-content-between gap-2 flex-wrap">
          <div class="avatar-row">
            ${avatarHTML(p.email || p.name || '?')}
            <div>
              <div><strong>${escapeHtml(p.name || p.email || 'Invite')}</strong></div>
              <div class="small text-muted"><span class="badge badge-wait">Waiting to accept</span></div>
            </div>
          </div>
          <div>
            <button class="btn btn-sm btn-outline-primary" data-profile-open="${escapeHtml(p.id)}">Profile</button>
          </div>
        </div>
      `;
      circlePeopleList.appendChild(row);
    });
  }

  circlePeopleList.querySelectorAll('[data-profile-open]').forEach(btn => {
    btn.addEventListener('click', () => {
      const personId = btn.getAttribute('data-profile-open');
      const person = (tree.people || []).find(p => p.id === personId);
      if (person) openMemberProfile(person);
    });
  });

  if (!isOwner && currentGroupId) {
    const note = document.createElement('div');
    note.className = 'mt-3 text-muted';
    note.textContent = 'Only the circle owner can add placeholders and edit relationships.';
    circlePeopleList.appendChild(note);
  }
}

/* ============================= Toggle views ============================= */
function showTreeView() {
  circleManageView?.classList.add('hidden');
  circleTreeView?.classList.remove('hidden');
  setTimeout(() => drawLines(lastTree), 60);
}

function showManageView() {
  if (!currentGroupId) {
    showInline('Select or create a group first.');
    return;
  }
  circleTreeView?.classList.add('hidden');
  circleManageView?.classList.remove('hidden');
}

window.p2pOpenInviteMembers = function () {
  if (!currentGroupId) {
    showInline('Select or create a group first.');
    return;
  }

  showManageView();
  setTimeout(() => {
    inviteMembersPanel?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    circleInviteEmailEl?.focus();
  }, 80);
};

circleManageBtn?.addEventListener('click', showManageView);
circleBackToTreeBtn?.addEventListener('click', showTreeView);

/* ============================= Refresh Circle ============================= */
async function refreshCircle(forceAutoLayout = false) {
  if (!currentUser?.id) return;

  await refreshGroups(currentGroupId);

  if (!currentGroupId) {
    clearTreeUI();
    return;
  }

  try {
    const res = await fetch(`${API}/api/group/${currentGroupId}/tree/${currentUser.id}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not load tree');

    lastTree = {
      group: data.group,
      people: data.people || [],
      relations: data.relations || [],
      positions: data.positions || [],
      invites: data.invites || []
    };

    currentGroupOwnerId = data.group?.ownerId || currentGroupOwnerId;
    if (data.group?.name) setGroupName(data.group.name);

    fillPeopleSelects(lastTree);
    renderRelationList(lastTree);
    renderPeopleList(lastTree);
    renderTree(lastTree, forceAutoLayout);
  } catch (e) {
    clearTreeUI();
    showInline(`Error loading circle: ${e.message}`);
  }
}

window.p2pRefreshCircle = () => refreshCircle(false);

circleTreeRefreshBtn?.addEventListener('click', () => refreshCircle(false));
circleRefreshBtn?.addEventListener('click', () => refreshCircle(false));

window.addEventListener('resize', () => {
  setTimeout(() => drawLines(lastTree), 100);
});

circleAutoLayoutBtn?.addEventListener('click', async () => {
  if (!currentGroupId) return showInline('No group selected.');
  showInline('Auto-layout applied. Dragging will save new positions.');
  await refreshCircle(true);
});

/* ============================= Notification dropdown ============================= */
notifBellBtn?.addEventListener('click', (e) => {
  e.stopPropagation();
  notifDropdown?.classList.toggle('open');
});

document.addEventListener('click', (e) => {
  if (!notifDropdown || !notifBellBtn) return;
  if (notifDropdown.contains(e.target) || notifBellBtn.contains(e.target)) return;
  notifDropdown.classList.remove('open');
});

/* ============================= Group create/select ============================= */
groupPicker?.addEventListener('change', async () => {
  const nextId = groupPicker.value || null;
  currentGroupId = nextId;
  await refreshCircle(false);
  showTreeView();
});

createGroupBtn?.addEventListener('click', async () => {
  if (!currentUser?.id) return showInline('Connecting…');

  const name = (createGroupNameInput?.value || '').trim();
  if (!name) return showInline('Enter a group name.');

  const done = setBusy(createGroupBtn, 'Creating…');
  try {
    const out = await postJSON(`${API}/api/group/create`, {
      fromUserId: currentUser.id,
      name
    });

    createGroupNameInput.value = '';
    showInline('Group created.');
    await refreshGroups(out.group?.id || null);
    await refreshCircle(true);
    showTreeView();
  } catch (e) {
    showInline(`Create group failed: ${e.message}`);
  } finally {
    done();
  }
});

/* ============================= Invite + Rename ============================= */
circleInviteBtn?.addEventListener('click', async () => {
  if (!currentUser?.id) return showInline('Connecting…');
  if (!currentGroupId) return showInline('No group selected.');

  const email = (circleInviteEmailEl.value || '').trim();
  if (!email) return showInline('Enter an email.');

  const done = setBusy(circleInviteBtn, 'Inviting…');

  try {
    const out = await postJSON(`${API}/api/group/invite-email`, {
      fromUserId: currentUser.id,
      groupId: currentGroupId,
      email
    });

    if (out.alreadyMember) {
      showInline('That user is already a member of this group.');
    } else if (out.alreadyPending) {
      showInline('An invitation is already pending for this email.');
    } else if (out.invitedExistingUser) {
      showInline('Invitation sent. The registered user will also see an approval notification in the app.');
    } else {
      showInline('Invitation sent.');
    }

    circleInviteEmailEl.value = '';
    await refreshCircle(false);
    await refreshInvitations();
  } catch (e) {
    showInline(`Invite failed: ${e.message}`);
  } finally {
    done();
  }
});

circleRenameBtn?.addEventListener('click', async () => {
  if (!currentUser?.id) return showInline('Connecting…');
  if (!currentGroupId) return showInline('No group selected.');

  const name = (circleNameInput?.value || '').trim();
  if (!name) return showInline('Enter a group name.');

  const done = setBusy(circleRenameBtn, 'Renaming…');

  try {
    await postJSON(`${API}/api/group/${currentGroupId}/rename`, {
      fromUserId: currentUser.id,
      name
    });

    showInline('Group renamed.');
    await refreshGroups(currentGroupId);
    await refreshCircle(false);
  } catch (e) {
    showInline(`Rename failed: ${e.message}`);
  } finally {
    done();
  }
});

/* ============================= Add placeholder ============================= */
phAddBtn?.addEventListener('click', async () => {
  if (!currentUser?.id) return showInline('Connecting…');
  if (!currentGroupId) return showInline('No group selected.');

  const name = (phName?.value || '').trim();
  const email = (phEmail?.value || '').trim();
  if (!name) return showInline('Enter placeholder name.');

  const done = setBusy(phAddBtn, 'Adding…');

  try {
    await postJSON(`${API}/api/group/${currentGroupId}/person/placeholder`, {
      fromUserId: currentUser.id,
      name,
      email: email || null
    });

    showInline('Placeholder added.');
    phName.value = '';
    phEmail.value = '';
    await refreshCircle(true);
  } catch (e) {
    showInline(`Add placeholder failed: ${e.message}`);
  } finally {
    done();
  }
});

/* ============================= Add relationship ============================= */
relAddBtn?.addEventListener('click', async () => {
  if (!currentUser?.id) return showInline('Connecting…');
  if (!currentGroupId) return showInline('No group selected.');

  const aPersonId = relASelect?.value;
  const bPersonId = relBSelect?.value;
  const kind = relKindSelect?.value;

  if (!aPersonId || !bPersonId) return showInline('Pick Person A and Person B.');
  if (aPersonId === bPersonId) return showInline('They cannot be the same person.');

  const done = setBusy(relAddBtn, 'Saving…');

  try {
    await postJSON(`${API}/api/group/${currentGroupId}/relation/add`, {
      fromUserId: currentUser.id,
      kind,
      aPersonId,
      bPersonId
    });

    showInline('Relationship saved.');
    await refreshCircle(true);
    showTreeView();
  } catch (e) {
    showInline(`Relationship failed: ${e.message}`);
  } finally {
    done();
  }
});

/* ============================= Boot ============================= */
async function boot() {
  try {
    await bootstrapFromMainApp();
    await ensureWSAuthed();
    await refreshInvitations();
    await refreshGroups();
    await refreshCircle(true);
    showTreeView();
  } catch (e) {
    console.warn('[SSO] failed:', e.message);
    showInline('Not signed in. Please open the main app and sign in first.');
    try { window.api?.navigateTo?.('login.html'); } catch (_) {}
  }
}

boot();