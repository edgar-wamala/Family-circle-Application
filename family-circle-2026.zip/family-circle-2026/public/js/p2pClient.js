// p2pClient.js  — SPA edition  (local Electron userData photo storage)
//
// Reads from index.html via window.KK:
//   window.KK.token, window.KK.currentUser, window.KK.showSection,
//   window.KK.showInline, window.KK.updateSidebarUserCard
//
// Exposes back via window.KK:
//   window.KK.p2pRefreshCircle, window.KK.p2pRefreshManagePanel,
//   window.KK.p2pRefreshGroupsPage, window.KK.p2pLoadDashboardTree
//
// ── PHOTO STRATEGY (100% local, no server changes) ───────────────────────────
//
//   Owner (logged-in user)
//     → profile_photo_path from Electron DB  →  file:// URI
//     → managed via the Profile section (unchanged)
//
//   All other circle members (real users, placeholders, invited)
//     → Stored in:  userData/circle_photos/<groupId>/<personId><ext>
//     → Index at:   userData/circle_photos/index.json
//     → IPC bridge: window.api.circlePhotos.save / get / list / delete
//     → Circle owner can upload for ANY member
//     → Real members can upload their own photo
//
//   Photo resolution order (photoSrcFor):
//     1. Logged-in user  →  profile_photo_path  (file://)
//     2. In-memory local cache  →  state.localPhotoCache  (file://)
//     3. Electron main-app photo (other real users, if API available)
//
'use strict';

/* ─────────────────────────────────────────────
   CONFIG
───────────────────────────────────────────── */
//const P2P_SERVER = 'http://localhost:5020';
const P2P_SERVER = 'http://f7c37c494f5816817.temporary.link:5020';
const P2P_API    = P2P_SERVER;
const P2P_WS_URL = (() => {
  try {
    const u = new URL(P2P_SERVER);
    return (u.protocol === 'https:' ? 'wss:' : 'ws:') + '//' + u.host;
  } catch { return 'ws://f7c37c494f5816817.temporary.link:5020'; }
})();

/* ─────────────────────────────────────────────
   WAIT FOR window.KK
───────────────────────────────────────────── */
function whenKKReady(fn) {
  if (window.KK?.token) { fn(); return; }
  setTimeout(() => whenKKReady(fn), 50);
}

/* ─────────────────────────────────────────────
   STATE
───────────────────────────────────────────── */
const state = {
  currentUser:          null,   // { id, email, name }
  currentGroupId:       null,
  currentGroupOwnerId:  null,
  availableGroups:      [],
  ws:                   null,
  authed:               false,
  lastTree:             { group: null, people: [], relations: [], positions: [], invites: [] },
  nodeEls:              new Map(),

  // personId → file:// src  (populated from circle-photos:list on each group load)
  localPhotoCache:      new Map(),

  // userId → src  (Electron main-app profile photos for other real users)
  mainAppPhotoCache:    new Map(),
};

/* ─────────────────────────────────────────────
   HELPERS
───────────────────────────────────────────── */
function esc(str) {
  return String(str ?? '').replace(/[&<>"']/g,
    m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
}

function initials(s) {
  const str = String(s || '').trim();
  if (!str) return '?';
  const parts = str.split(/\s+/).filter(Boolean);
  return parts.length === 1
    ? parts[0].slice(0, 2).toUpperCase()
    : (parts[0][0] + parts[1][0]).toUpperCase();
}

function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }

function showInline(msg) { window.KK?.showInline?.(msg) ?? console.log('[P2P]', msg); }

function setP2PStatus(text, connected = false) {
  const el  = document.getElementById('p2pStatus');
  const dot = document.getElementById('p2pStatusDot');
  if (el)  el.textContent = text;
  if (dot) dot.classList.toggle('connected', connected);
}

function setBusy(btn, label) {
  if (!btn) return () => {};
  const orig = btn.textContent;
  btn.disabled = true; btn.textContent = label || 'Working…';
  return () => { btn.disabled = false; btn.textContent = orig; };
}

function setGroupName(name) {
  const safe = name || 'No Group Selected';
  const sGN  = document.getElementById('selectedGroupName');
  const tGB  = document.getElementById('topGroupBadge');
  const cni  = document.getElementById('circleNameInput');
  if (sGN) sGN.value = safe;
  if (cni) cni.value = name || '';
  if (tGB) { tGB.textContent = safe; tGB.style.display = name ? '' : 'none'; }
}

function isOwner() {
  return !!(
    state.currentUser?.id &&
    state.currentGroupOwnerId &&
    state.currentUser.id === state.currentGroupOwnerId
  );
}

/* ─────────────────────────────────────────────
   REST
───────────────────────────────────────────── */
async function post(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  let data = null; try { data = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error(data?.error || res.statusText || 'Request failed');
  return data || {};
}

/* ─────────────────────────────────────────────
   PHOTO — LOCAL ELECTRON STORAGE
───────────────────────────────────────────── */

/**
 * Resolve the best available photo src for a person.
 * Priority:
 *   1. Logged-in user  →  Electron profile_photo_path / profile_photo_url
 *   2. Local circle photo cache  →  file:// path from userData
 *   3. Electron main-app cache for other real users (if API available)
 */
function photoSrcFor(person) {
  if (!person) return null;
  const cu   = window.KK?.currentUser;
  const myId = cu?.id || cu?._id;

  // 1) Logged-in user's own Electron profile photo
  if (person.kind === 'user' && person.user_id && person.user_id === myId) {
    if (cu.profile_photo_path) return `file://${cu.profile_photo_path}`;
    if (cu.profile_photo_url)  return cu.profile_photo_url;
  }

  // 2) Local circle photo (stored in userData by circlePhotosHandler.js)
  const local = state.localPhotoCache.get(person.id);
  if (local) return local;

  // 3) Electron main-app photo cache for other real users
  if (person.kind === 'user' && person.user_id) {
    const cached = state.mainAppPhotoCache.get(person.user_id);
    if (cached) return cached;
  }

  return null;
}

/**
 * Load all locally stored photos for the current group into state.localPhotoCache.
 * Called every time we switch groups or refresh.
 */
async function loadLocalPhotosForGroup(groupId) {
  if (!groupId || !window.api?.circlePhotos?.list) return;
  try {
    const r = await window.api.circlePhotos.list(groupId);
    if (!r?.success) return;
    // r.photos = { personId: absoluteFilePath, … }
    for (const [personId, filePath] of Object.entries(r.photos || {})) {
      state.localPhotoCache.set(personId, `file://${filePath}`);
    }
  } catch (_) {}
}

/**
 * Save a photo for a circle member into Electron userData.
 * file  — File object from an <input type="file">
 * Returns the file:// src on success.
 *
 * Root-cause fix: with contextIsolation:true, file.path is undefined in the
 * renderer. We read the file as a base64 data-URL here and send that to the
 * main process, which writes it to disk and returns the stored file path.
 */
async function saveLocalPhotoForPerson(person, file) {
  if (!window.api?.circlePhotos?.save) {
    throw new Error('circlePhotos IPC bridge not available. Add it to preload.js.');
  }

  // Read file as base64 data-URL in the renderer process.
  // This works correctly with contextIsolation:true (no file.path needed).
  const dataURL = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = ev => resolve(ev.target.result);
    reader.onerror = ()  => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });

  // Derive extension from MIME type
  const extMap = { 'image/jpeg':'.jpg', 'image/png':'.png', 'image/webp':'.webp', 'image/gif':'.gif' };
  const ext = extMap[file.type] || '.jpg';

  // Send base64 to main process — it writes the file and returns the path
  const r = await window.api.circlePhotos.save({
    groupId:  state.currentGroupId,
    personId: person.id,
    dataURL,   // base64 data-URL  (replaces sourcePath)
    ext,       // file extension hint
  });

  if (!r?.success) throw new Error(r?.error || 'Save failed');

  // Cache the file:// path so subsequent renders (and re-logins) pick it up
  const fileSrc = `file://${r.filePath}`;
  state.localPhotoCache.set(person.id, fileSrc);

  return fileSrc;
}

/**
 * Open a native file picker and save the chosen photo for a person.
 * Calls onSuccess(src) with the new file:// src.
 */
function pickAndSavePhoto(person, onSuccess) {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'image/jpeg,image/png,image/webp,image/gif';
  inp.style.display = 'none';
  document.body.appendChild(inp);

  inp.addEventListener('change', async () => {
    const file = inp.files?.[0];
    document.body.removeChild(inp);
    if (!file) return;

    showInline('Saving photo…');
    try {
      const src = await saveLocalPhotoForPerson(person, file);
      onSuccess?.(src);
      showInline('✅ Photo saved!');
    } catch (err) {
      showInline(`❌ ${err.message || 'Failed to save photo'}`);
    }
  });

  inp.click();
}

/**
 * Prefetch Electron main-app profile photos for real members (best-effort).
 */
async function preloadMemberPhotos(people) {
  if (!window.api?.getUserProfilePhoto) return;
  const token = window.KK?.token;
  const myId  = window.KK?.currentUser?.id || window.KK?.currentUser?._id;
  const targets = people.filter(p =>
    p.kind === 'user' && p.user_id && p.user_id !== myId &&
    !state.mainAppPhotoCache.has(p.user_id) &&
    !state.localPhotoCache.has(p.id)   // don't bother if we already have a circle photo
  );
  for (let i = 0; i < targets.length; i += 4) {
    await Promise.all(targets.slice(i, i + 4).map(async p => {
      try {
        const r = await window.api.getUserProfilePhoto(p.user_id, token);
        if (r?.success && (r.profile_photo_path || r.profile_photo_url)) {
          state.mainAppPhotoCache.set(
            p.user_id,
            r.profile_photo_path ? `file://${r.profile_photo_path}` : r.profile_photo_url
          );
        }
      } catch (_) {}
    }));
  }
}

/**
 * Patch a single tree node's photo in-place without re-rendering the tree.
 */
function updateNodePhoto(personId, src) {
  const el = state.nodeEls.get(personId); if (!el) return;
  const pw = el.querySelector('.tn-photo'); if (!pw) return;
  const hadOverlay = !!pw.querySelector('.tn-photo-overlay');
  pw.innerHTML =
    `<img src="${esc(src)}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">` +
    (hadOverlay ? `<div class="tn-photo-overlay" title="Click to change photo">📷</div>` : '');
}

/* ─────────────────────────────────────────────
   SSO BOOTSTRAP
───────────────────────────────────────────── */
async function bootstrapFromMainApp() {
  const token = window.KK?.token;
  if (!token) throw new Error('No session token — sign in first.');
  if (!window.api?.getCurrentUser) throw new Error('Electron API bridge not available.');

  const r = await window.api.getCurrentUser(token);
  if (!r?.success || !r.data?.email) throw new Error(r?.error || 'Not authenticated');

  window.KK.currentUser = r.data;
  window.KK.updateSidebarUserCard?.(r.data);

  state.currentUser = {
    id:    r.data.id || r.data._id,
    email: r.data.email,
    name:  r.data.name || r.data.email,
  };
  setP2PStatus(`Signed in as ${state.currentUser.name}`, true);
}

/* ─────────────────────────────────────────────
   WEBSOCKET
───────────────────────────────────────────── */
function connectWS() {
  state.ws = new WebSocket(P2P_WS_URL);
  state.ws.onopen = () => {
    setP2PStatus('Connected', true);
    state.authed = false;
    if (state.currentUser) {
      state.ws.send(JSON.stringify({
        type: 'auth',
        userId: state.currentUser.id,
        email:  state.currentUser.email,
        name:   state.currentUser.name,
      }));
    }
  };
  state.ws.onclose = () => { setP2PStatus('Disconnected'); state.authed = false; };
  state.ws.onerror = () => setP2PStatus('Connection error');
  state.ws.onmessage = ev => {
    let msg; try { msg = JSON.parse(ev.data); } catch { return; }
    if (msg.type === 'auth-ok') {
      state.authed      = true;
      state.currentUser = { id: msg.userId, email: msg.email, name: msg.name };
      setP2PStatus(`Connected as ${state.currentUser.name}`, true);
    }
    if (msg.type === 'auth-error') {
      state.authed = false;
      showInline(`Auth failed: ${msg.reason || 'unknown'}`);
    }
  };
}

async function ensureWSAuthed() {
  if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
    connectWS();
    await new Promise(res => {
      if (!state.ws || state.ws.readyState === WebSocket.OPEN) return res();
      state.ws.addEventListener('open', res, { once: true });
    });
  }
  if (!state.authed && state.currentUser) {
    state.ws.send(JSON.stringify({
      type: 'auth', userId: state.currentUser.id,
      email: state.currentUser.email, name: state.currentUser.name,
    }));
    await new Promise((res, rej) => {
      const fn = ev => {
        let m; try { m = JSON.parse(ev.data); } catch { return; }
        if (m.type === 'auth-ok')    { state.ws.removeEventListener('message', fn); state.authed = true; res(); }
        if (m.type === 'auth-error') { state.ws.removeEventListener('message', fn); rej(new Error(m.reason)); }
      };
      state.ws.addEventListener('message', fn);
      setTimeout(() => {
        state.ws.removeEventListener('message', fn);
        if (!state.authed) rej(new Error('auth timeout'));
      }, 5000);
    }).catch(e => showInline(`Auth error: ${e.message}`));
  }
}

/* ─────────────────────────────────────────────
   GROUPS
───────────────────────────────────────────── */
function renderGroupPicker() {
  const gp = document.getElementById('groupPicker'); if (!gp) return;
  gp.innerHTML = '';
  if (!state.availableGroups.length) {
    const o = document.createElement('option'); o.value = ''; o.textContent = 'No circles yet';
    gp.appendChild(o); return;
  }
  state.availableGroups.forEach(g => {
    const o = document.createElement('option'); o.value = g.id; o.textContent = g.name;
    gp.appendChild(o);
  });
  if (state.currentGroupId) gp.value = state.currentGroupId;
}

async function refreshGroups(preferredId = null) {
  if (!state.currentUser?.id) return;
  const res  = await fetch(`${P2P_API}/api/me/${state.currentUser.id}/groups`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Could not load groups');
  state.availableGroups = data.groups || [];

  if (!state.availableGroups.length) {
    state.currentGroupId = null; state.currentGroupOwnerId = null;
    setGroupName(null); renderGroupPicker();
    document.getElementById('noGroupState')?.style.setProperty('display', '');
    clearTreeUI(); return;
  }

  const sel = state.availableGroups.find(g => g.id === preferredId)
           || state.availableGroups.find(g => g.id === state.currentGroupId)
           || state.availableGroups[0];
  state.currentGroupId      = sel.id;
  state.currentGroupOwnerId = sel.ownerId;
  document.getElementById('selectedGroupId').value = sel.id;
  setGroupName(sel.name); renderGroupPicker();
  document.getElementById('noGroupState')?.style.setProperty('display', 'none');
}

/* ─────────────────────────────────────────────
   INVITATION NOTIFICATIONS
───────────────────────────────────────────── */
function renderInviteNotifications(invites) {
  const list = document.getElementById('inviteNotificationList');
  const bell = document.getElementById('inviteBellCount');
  if (!list || !bell) return;
  const rows = invites || [];
  list.innerHTML = '';
  bell.textContent  = String(rows.length);
  bell.style.display = rows.length ? '' : 'none';

  if (!rows.length) {
    list.innerHTML = '<div style="font-size:.83rem;color:var(--muted);">No pending invitations.</div>';
    return;
  }

  rows.forEach(inv => {
    const card = document.createElement('div'); card.className = 'notif-item';
    card.innerHTML = `
      <div style="font-weight:700;font-size:.88rem;">${esc(inv.groupName || 'Family Circle')}</div>
      <div style="font-size:.78rem;color:var(--muted);">Invited by ${esc(inv.ownerName || 'Owner')}</div>
      ${inv.createdAt ? `<div style="font-size:.73rem;color:var(--muted);margin-bottom:6px;">${new Date(inv.createdAt).toLocaleString()}</div>` : '<div class="mb-1"></div>'}
      <div class="d-flex gap-2">
        <button class="btn btn-success btn-sm"        data-accept-token="${esc(inv.token)}">Accept</button>
        <button class="btn btn-outline-danger btn-sm" data-reject-token="${esc(inv.token)}">Decline</button>
      </div>`;
    list.appendChild(card);
  });

  list.querySelectorAll('[data-accept-token]').forEach(btn => btn.addEventListener('click', async () => {
    const tok = btn.getAttribute('data-accept-token'), done = setBusy(btn, 'Accepting…');
    try {
      const out = await post(`${P2P_API}/api/invitations/respond`, { token: tok, userId: state.currentUser.id, action: 'accept' });
      showInline('Invitation accepted!');
      document.getElementById('notifDropdown')?.classList.remove('open');
      await refreshGroups(out.groupId || null); await refreshInvitations(); await refreshCircle(true);
    } catch (e) { showInline(`Accept failed: ${e.message}`); }
    finally { done(); }
  }));

  list.querySelectorAll('[data-reject-token]').forEach(btn => btn.addEventListener('click', async () => {
    const tok = btn.getAttribute('data-reject-token'), done = setBusy(btn, 'Declining…');
    try {
      await post(`${P2P_API}/api/invitations/respond`, { token: tok, userId: state.currentUser.id, action: 'reject' });
      showInline('Invitation declined.'); await refreshInvitations();
    } catch (e) { showInline(`Decline failed: ${e.message}`); }
    finally { done(); }
  }));
}

async function refreshInvitations() {
  if (!state.currentUser?.id) return;
  try {
    const res  = await fetch(`${P2P_API}/api/me/${state.currentUser.id}/invitations`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not load invitations');
    renderInviteNotifications(data.invitations || []);
  } catch (e) { showInline(`Could not load invitations: ${e.message}`); }
}

/* ─────────────────────────────────────────────
   AUTO-LAYOUT
───────────────────────────────────────────── */
function computeAutoLayout(tree, canvasW, canvasH) {
  const people = tree.people || [], rels = tree.relations || [];
  const nodeW = 140, nodeH = 160, padX = 20, padY = 20, levelGapY = 155;
  const parentsOf = new Map(), childrenOf = new Map(), spousesOf = new Map();
  function addSet(m, k, v) { if (!m.has(k)) m.set(k, new Set()); m.get(k).add(v); }
  for (const r of rels) {
    if (r.kind === 'mother' || r.kind === 'father') { addSet(parentsOf, r.b_person_id, r.a_person_id); addSet(childrenOf, r.a_person_id, r.b_person_id); }
    else if (r.kind === 'spouse') { addSet(spousesOf, r.a_person_id, r.b_person_id); addSet(spousesOf, r.b_person_id, r.a_person_id); }
  }
  const level = new Map(), indeg = new Map();
  for (const p of people) indeg.set(p.id, 0);
  for (const [c, ps] of parentsOf.entries()) indeg.set(c, (indeg.get(c) || 0) + ps.size);
  const queue = [];
  for (const p of people) { if (!indeg.get(p.id)) { level.set(p.id, 0); queue.push(p.id); } }
  if (!queue.length && people.length) { level.set(people[0].id, 0); queue.push(people[0].id); }
  while (queue.length) {
    const u = queue.shift(), uL = level.get(u) ?? 0;
    for (const v of (childrenOf.get(u) || [])) {
      const nl = Math.max(level.get(v) ?? 0, uL + 1); level.set(v, nl);
      indeg.set(v, (indeg.get(v) || 1) - 1); if ((indeg.get(v) || 0) <= 0) queue.push(v);
    }
  }
  for (const p of people) if (!level.has(p.id)) level.set(p.id, 0);
  const levels = new Map();
  for (const p of people) { const l = level.get(p.id) || 0; if (!levels.has(l)) levels.set(l, []); levels.get(l).push(p.id); }
  function reorderSpouses(ids) {
    const used = new Set(), out = [];
    for (const id of ids) {
      if (used.has(id)) continue; used.add(id); out.push(id);
      const sp = spousesOf.get(id); if (sp) { const s = [...sp].find(sid => !used.has(sid) && ids.includes(sid)); if (s) { used.add(s); out.push(s); } }
    }
    return out;
  }
  for (const [l, arr] of levels.entries()) levels.set(l, reorderSpouses(arr));
  const layout = new Map(), maxLvl = Math.max(...[...levels.keys(), 0]), usableW = Math.max(260, canvasW - padX * 2);
  for (let l = 0; l <= maxLvl; l++) {
    const ids = levels.get(l) || [], count = ids.length || 1;
    const gap = Math.max(16, Math.floor((usableW - count * nodeW) / Math.max(1, count - 1)));
    const totalW = count * nodeW + (count - 1) * gap;
    const startX = clamp(Math.floor((canvasW - totalW) / 2), padX, padX + 40);
    const y = padY + l * levelGapY;
    ids.forEach((id, i) => layout.set(id, {
      x: clamp(startX + i * (nodeW + gap), 6, canvasW - nodeW - 6),
      y: clamp(y, 6, canvasH - nodeH - 6),
    }));
  }
  return layout;
}

/* ─────────────────────────────────────────────
   LINE DRAWING
───────────────────────────────────────────── */
const REL_LABEL  = { mother:'Mother', father:'Father', spouse:'Spouse', friend:'Friend', guardian:'Guardian', grandparent:'Grandparent', aunt_uncle:'Aunt/Uncle', sibling:'Sibling', cousin:'Cousin' };
const UNDIRECTED = new Set(['spouse','friend','sibling','cousin']);

function styleForKind(kind) {
  const b = { stroke:'#3b82f6', width:2, opacity:.65, dash:null };
  const m = { mother:{stroke:'#7c3aed',width:2.5,opacity:.85}, father:{stroke:'#1d4ed8',width:2.5,opacity:.85,dash:'7 4'}, guardian:{stroke:'#0891b2',width:2,opacity:.7,dash:'10 5'}, grandparent:{stroke:'#059669',width:2,opacity:.6,dash:'4 8'}, aunt_uncle:{stroke:'#d97706',width:1.5,opacity:.55,dash:'3 4'}, spouse:{stroke:'#e11d48',width:2,opacity:.65,dash:'2 6'}, friend:{stroke:'#6b7280',width:1.5,opacity:.5,dash:'1 6'}, sibling:{stroke:'#f59e0b',width:2,opacity:.6,dash:'6 8'}, cousin:{stroke:'#a78bfa',width:1.5,opacity:.5,dash:'12 6'} };
  return { ...b, ...(m[kind] || {}) };
}

function clearTreeUI() {
  state.lastTree = { group:null, people:[], relations:[], positions:[], invites:[] };
  const c = document.getElementById('circleTreeCanvas'); if (!c) return;
  [...c.querySelectorAll('.tree-node,.tree-empty')].forEach(n => n.remove());
  const l = document.getElementById('circleTreeLines'); if (l) l.innerHTML = '';
}

function buildPosMap(arr) {
  const m = new Map();
  (arr || []).forEach(p => p?.person_id && m.set(p.person_id, { x:Number(p.x), y:Number(p.y) }));
  return m;
}

function nodeBox(id) {
  const el = state.nodeEls.get(id); if (!el) return null;
  const x = parseFloat(el.style.left||'0'), y = parseFloat(el.style.top||'0');
  const w = el.offsetWidth||140, h = el.offsetHeight||160;
  return { x, y, w, h, cx:x+w/2, cy:y+h/2 };
}

function drawLines(tree) {
  const svg = document.getElementById('circleTreeLines'); if (!svg) return;
  svg.innerHTML = '';
  for (const r of (tree.relations||[])) {
    const A = nodeBox(r.a_person_id), B = nodeBox(r.b_person_id); if (!A||!B) continue;
    const x1=A.cx, y1=UNDIRECTED.has(r.kind)?A.cy:A.y+A.h;
    const x2=B.cx, y2=UNDIRECTED.has(r.kind)?B.cy:B.y;
    const st = styleForKind(r.kind);
    const line = document.createElementNS('http://www.w3.org/2000/svg','line');
    line.setAttribute('x1',x1); line.setAttribute('y1',y1);
    line.setAttribute('x2',x2); line.setAttribute('y2',y2);
    line.setAttribute('stroke',st.stroke); line.setAttribute('stroke-width',st.width); line.setAttribute('opacity',st.opacity);
    if (st.dash) line.setAttribute('stroke-dasharray',st.dash);
    svg.appendChild(line);
    const label=REL_LABEL[r.kind]||r.kind, mx=(x1+x2)/2, my=(y1+y2)/2, bw=Math.max(56,label.length*8+16), bh=18;
    const rect = document.createElementNS('http://www.w3.org/2000/svg','rect');
    rect.setAttribute('x',mx-bw/2); rect.setAttribute('y',my-bh/2-6); rect.setAttribute('width',bw); rect.setAttribute('height',bh);
    rect.setAttribute('rx','9'); rect.setAttribute('fill','rgba(255,255,255,.92)'); rect.setAttribute('stroke',st.stroke); rect.setAttribute('stroke-width','1');
    svg.appendChild(rect);
    const txt = document.createElementNS('http://www.w3.org/2000/svg','text');
    txt.setAttribute('x',mx); txt.setAttribute('y',my-6+1); txt.setAttribute('text-anchor','middle'); txt.setAttribute('dominant-baseline','middle');
    txt.setAttribute('fill',st.stroke); txt.setAttribute('font-size','10'); txt.setAttribute('font-weight','700');
    txt.textContent = label; svg.appendChild(txt);
  }
}

/* ─────────────────────────────────────────────
   MEMBER PROFILE MODAL
───────────────────────────────────────────── */
let _memberModal = null;

function openMemberProfile(person) {
  const modalEl = document.getElementById('memberProfileModal'); if (!modalEl||!person) return;
  if (!_memberModal && window.bootstrap?.Modal) _memberModal = new window.bootstrap.Modal(modalEl);

  const myId      = state.currentUser?.id;
  const isMe      = person.kind === 'user' && person.user_id === myId;
  const canUpload = isOwner() || isMe;
  const src       = photoSrcFor(person);

  document.getElementById('memberProfileModalTitle').textContent = person.name || person.email || 'Profile';
  document.getElementById('memberProfileModalBody').innerHTML = `
    <div class="text-center mb-3">
      <div class="profile-modal-photo" id="modalPhotoWrap" style="${canUpload ? 'cursor:pointer;position:relative;' : ''}">
        ${src
          ? `<img id="modalPhotoImg" src="${esc(src)}" alt=""/>`
          : `<div class="pm-initials">${esc(initials(person.name||person.email||'?'))}</div>`}
        ${canUpload
          ? `<div id="modalPhotoOverlay" style="position:absolute;inset:0;border-radius:50%;background:rgba(0,0,0,.4);opacity:0;transition:opacity .2s;display:flex;align-items:center;justify-content:center;font-size:1.4rem;pointer-events:auto;">📷</div>`
          : ''}
      </div>
      ${canUpload ? `<div style="font-size:.72rem;color:var(--muted);margin-top:5px;">Click photo to upload / change</div>` : ''}
      <div id="modalPhotoStatus" style="font-size:.78rem;min-height:1.2em;margin-top:3px;"></div>
    </div>
    <div class="detail-row"><span class="detail-label">Name</span><span class="detail-val">${esc(person.name||'Unknown')}</span></div>
    <div class="detail-row"><span class="detail-label">Email</span><span class="detail-val">${esc(person.email||'—')}</span></div>
    <div class="detail-row"><span class="detail-label">Type</span><span class="detail-val">${esc(person.kind||'member')}</span></div>
    ${isMe ? '<div class="mt-3 text-center"><span class="tag tag-member">This is you</span></div>' : ''}`;

  if (canUpload) {
    const wrap = document.getElementById('modalPhotoWrap');
    const ovl  = document.getElementById('modalPhotoOverlay');
    if (wrap && ovl) {
      wrap.addEventListener('mouseenter', () => ovl.style.opacity = '1');
      wrap.addEventListener('mouseleave', () => ovl.style.opacity = '0');
      wrap.addEventListener('click', () => {
        pickAndSavePhoto(person, newSrc => {
          // Update modal photo
          const img = document.getElementById('modalPhotoImg');
          if (img) { img.src = newSrc; }
          else {
            const wrap2 = document.getElementById('modalPhotoWrap');
            const ini   = wrap2?.querySelector('.pm-initials');
            if (ini) { const i = document.createElement('img'); i.id = 'modalPhotoImg'; i.src = newSrc; i.alt = ''; ini.replaceWith(i); }
          }
          const st = document.getElementById('modalPhotoStatus');
          if (st) { st.textContent = '✅ Photo saved!'; setTimeout(() => { st.textContent = ''; }, 3000); }
          // Update tree node and manage panel
          updateNodePhoto(person.id, newSrc);
          if (document.getElementById('invite')?.classList.contains('visible')) refreshManagePanel();
        });
      });
    }
  }

  _memberModal?.show();
}

/* ─────────────────────────────────────────────
   RENDER FULL TREE
───────────────────────────────────────────── */
async function renderTree(tree, forceAuto = false) {
  const canvas = document.getElementById('circleTreeCanvas');
  const lines  = document.getElementById('circleTreeLines');
  if (!canvas || !lines) return;

  state.nodeEls.clear();
  [...canvas.querySelectorAll('.tree-node,.tree-empty')].forEach(n => n.remove());
  lines.innerHTML = '';

  const W = canvas.clientWidth || 900, H = canvas.clientHeight || 640;
  lines.setAttribute('viewBox', `0 0 ${W} ${H}`);

  const savedPos   = buildPosMap(tree.positions), hasSaved = (tree.positions||[]).length > 0;
  const autoLayout = computeAutoLayout(tree, W, H);
  const people     = tree.people || [];
  const myId       = state.currentUser?.id;

  if (!people.length) {
    const e = document.createElement('div'); e.className = 'tree-empty';
    e.innerHTML = `<div class="empty-icon">🌳</div><p>No people yet.<br>Go to <strong>Invite Members</strong> to add them.</p>`;
    canvas.appendChild(e); return;
  }

  const hintEl = document.getElementById('treeHint');
  if (hintEl) hintEl.textContent = `${people.length} people · drag nodes · hover photo to upload`;

  // Prefetch Electron profile photos for real members (async, updates nodes after)
  preloadMemberPhotos(people).then(() => {
    people.forEach(p => {
      const el = state.nodeEls.get(p.id); if (!el) return;
      const pw = el.querySelector('.tn-photo'); if (!pw || pw.querySelector('img')) return;
      const src = photoSrcFor(p);
      if (src) {
        const hasOverlay = !!pw.querySelector('.tn-photo-overlay');
        pw.innerHTML = `<img src="${esc(src)}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">` +
          (hasOverlay ? `<div class="tn-photo-overlay" title="Click to change photo">📷</div>` : '');
      }
    });
    drawLines(tree);
  });

  people.forEach(p => {
    const isMe      = p.kind === 'user' && p.user_id === myId;
    const canUpload = isOwner() || isMe;
    const el        = document.createElement('div');
    el.className    = 'tree-node' + (isMe ? ' is-me' : '');
    el.dataset.personId = p.id;

    const badge = isMe
      ? `<div class="tn-badge-you">You</div>`
      : p.kind === 'placeholder' ? `<div class="tn-badge-ph">Placeholder</div>`
      : p.kind === 'invite'      ? `<div class="tn-badge-inv">Invited</div>`
      : '';

    const src = photoSrcFor(p);
    const photoInner = src
      ? `<img src="${esc(src)}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`
      : `<div class="tn-initials">${esc(initials(p.name||p.email||'?'))}</div>`;
    const overlay = canUpload
      ? `<div class="tn-photo-overlay" title="Click to upload photo">📷</div>`
      : '';

    el.innerHTML = `
      <div class="tn-photo" style="position:relative;">${photoInner}${overlay}</div>
      <div class="tn-name">${esc(p.name||p.email||'Unknown')}</div>
      ${p.role ? `<div class="tn-role">${esc(p.role)}</div>` : ''}
      ${badge}
      <div class="tn-actions">
        <button class="tn-btn" data-profile="${esc(p.id)}">Profile</button>
      </div>`;

    const nodeW = 140, nodeH = 160;
    let pos = (!forceAuto && hasSaved) ? savedPos.get(p.id) : null;
    if (!pos) pos = autoLayout.get(p.id) || { x:30, y:30 };
    pos.x = clamp(pos.x, 6, W-nodeW-6); pos.y = clamp(pos.y, 6, H-nodeH-6);
    el.style.left = `${pos.x}px`; el.style.top = `${pos.y}px`;

    canvas.appendChild(el);
    state.nodeEls.set(p.id, el);
    enableDrag(el, p);

    // Profile button
    el.querySelector('[data-profile]')?.addEventListener('click', ev => {
      ev.stopPropagation(); openMemberProfile(p);
    });

    // Camera overlay — direct upload on photo click
    if (canUpload) {
      el.querySelector('.tn-photo-overlay')?.addEventListener('click', ev => {
        ev.stopPropagation();
        pickAndSavePhoto(p, newSrc => {
          updateNodePhoto(p.id, newSrc);
          if (document.getElementById('invite')?.classList.contains('visible')) refreshManagePanel();
        });
      });
    }
  });

  drawLines(tree);
}

/* ─────────────────────────────────────────────
   DRAG
───────────────────────────────────────────── */
function enableDrag(el, person) {
  const canMove = isOwner() || (person.kind === 'user' && person.user_id === state.currentUser?.id);
  if (!canMove) return;
  let dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
  const canvas = () => document.getElementById('circleTreeCanvas');

  function down(e) {
    if (e.target?.closest?.('.tn-btn,.tn-photo-overlay')) return;
    dragging = true; el.classList.add('dragging');
    const rect = canvas().getBoundingClientRect();
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    sx = cx-rect.left; sy = cy-rect.top;
    ox = parseFloat(el.style.left||'0'); oy = parseFloat(el.style.top||'0');
    e.preventDefault?.();
  }
  function move(e) {
    if (!dragging) return;
    const c = canvas(), rect = c.getBoundingClientRect();
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    const nW = el.offsetWidth||140, nH = el.offsetHeight||160;
    const W = c.clientWidth||900, H = c.clientHeight||640;
    el.style.left = `${clamp(ox+(cx-rect.left)-sx, 6, W-nW-6)}px`;
    el.style.top  = `${clamp(oy+(cy-rect.top)-sy,  6, H-nH-6)}px`;
    drawLines(state.lastTree);
  }
  async function up() {
    if (!dragging) return; dragging = false; el.classList.remove('dragging');
    if (!state.currentGroupId) return;
    const x = Math.round(parseFloat(el.style.left||'0')), y = Math.round(parseFloat(el.style.top||'0'));
    try {
      await post(`${P2P_API}/api/group/${state.currentGroupId}/node/pos`, { fromUserId:state.currentUser.id, personId:person.id, x, y });
      const idx = (state.lastTree.positions||[]).findIndex(p => p.person_id === person.id);
      const now = Date.now();
      if (idx >= 0) state.lastTree.positions[idx] = { person_id:person.id, x, y, updated_at:now };
      else state.lastTree.positions.push({ person_id:person.id, x, y, updated_at:now });
    } catch (e) { showInline(`Save position failed: ${e.message}`); }
  }

  el.addEventListener('mousedown', down); window.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
  el.addEventListener('touchstart', down, { passive:false }); window.addEventListener('touchmove', move, { passive:false }); window.addEventListener('touchend', up);
}

/* ─────────────────────────────────────────────
   MANAGE PANEL
───────────────────────────────────────────── */
function personCardHTML(p) {
  const myId = state.currentUser?.id, isMe = p.kind==='user' && p.user_id===myId;
  const src  = photoSrcFor(p), canUpload = isOwner() || isMe;
  let tags = '';
  if (isMe)                 tags += `<span class="tag tag-member">You</span>`;
  if (p.kind==='user')        tags += `<span class="tag tag-member">${esc(p.role||'member')}</span>`;
  if (p.kind==='placeholder') tags += `<span class="tag tag-ph">Placeholder</span>`;
  if (p.kind==='invite')      tags += `<span class="tag tag-inv">Pending invite</span>`;
  return `<div class="person-card">
    <div class="person-photo" data-pid="${esc(p.id)}" style="${canUpload ? 'cursor:pointer;' : ''}" title="${canUpload ? 'Click to upload photo' : ''}">
      ${src ? `<img src="${esc(src)}" alt=""/>` : `<div class="p-initials">${esc(initials(p.name||p.email||'?'))}</div>`}
    </div>
    <div class="person-info">
      <div class="p-name">${esc(p.name||p.email||'Unknown')}</div>
      ${p.email ? `<div class="p-email">${esc(p.email)}</div>` : ''}
      <div class="p-tags">${tags}</div>
    </div>
    <div class="person-actions">
      <button class="btn btn-outline-primary btn-sm" data-profile-open="${esc(p.id)}">View</button>
    </div>
  </div>`;
}

function wirePanelCards(container, people) {
  // Profile modal button
  container?.querySelectorAll('[data-profile-open]').forEach(btn => {
    btn.addEventListener('click', () => {
      const p = people.find(x => x.id === btn.getAttribute('data-profile-open'));
      if (p) openMemberProfile(p);
    });
  });
  // Photo upload on card photo bubble
  container?.querySelectorAll('.person-photo[data-pid]').forEach(photoEl => {
    const p = people.find(x => x.id === photoEl.getAttribute('data-pid')); if (!p) return;
    const myId = state.currentUser?.id, isMe = p.kind==='user' && p.user_id===myId;
    if (!isOwner() && !isMe) return;
    photoEl.addEventListener('click', () => {
      pickAndSavePhoto(p, newSrc => {
        const img = photoEl.querySelector('img');
        if (img) img.src = newSrc;
        else photoEl.innerHTML = `<img src="${esc(newSrc)}" alt=""/>`;
        updateNodePhoto(p.id, newSrc);
      });
    });
  });
}

function renderMembersTab() {
  const grid = document.getElementById('membersGrid'); if (!grid) return;
  const members = (state.lastTree.people||[]).filter(p => p.kind==='user');
  if (!members.length) { grid.innerHTML = '<div class="text-muted" style="font-size:.84rem;">No members yet.</div>'; return; }
  grid.innerHTML = members.map(personCardHTML).join(''); wirePanelCards(grid, members);
}

function renderInviteTab() {
  const grid = document.getElementById('pendingInviteGrid'); if (!grid) return;
  const inv = (state.lastTree.people||[]).filter(p => p.kind==='invite');
  if (!inv.length) { grid.innerHTML = '<div class="text-muted" style="font-size:.84rem;">No pending invitations.</div>'; return; }
  grid.innerHTML = inv.map(personCardHTML).join(''); wirePanelCards(grid, inv);
}

function renderPlaceholdersTab() {
  const grid = document.getElementById('placeholderGrid'); if (!grid) return;
  const phs = (state.lastTree.people||[]).filter(p => p.kind==='placeholder');
  if (!phs.length) { grid.innerHTML = '<div class="text-muted" style="font-size:.84rem;">No direct members yet.</div>'; return; }
  grid.innerHTML = phs.map(personCardHTML).join(''); wirePanelCards(grid, phs);
}

function renderRelationsTab() {
  const rl = document.getElementById('relList'); if (!rl) return;
  const rels = state.lastTree.relations||[], byId = new Map((state.lastTree.people||[]).map(p => [p.id,p]));
  if (!rels.length) { rl.innerHTML = '<div class="text-muted" style="font-size:.84rem;">No relationships set yet.</div>'; return; }
  rl.innerHTML = rels.map(r => {
    const A = byId.get(r.a_person_id), B = byId.get(r.b_person_id);
    return `<div class="rel-item">
      <div class="rel-names"><strong>${esc(A?.name||r.a_person_id)}</strong><span style="color:var(--muted);margin:0 4px;">→</span><strong>${esc(B?.name||r.b_person_id)}</strong></div>
      <div style="display:flex;gap:6px;align-items:center;">
        <span class="rel-badge">${esc(REL_LABEL[r.kind]||r.kind)}</span>
        ${isOwner() ? `<button class="btn btn-sm btn-outline-danger" data-rel-del="${esc(r.id)}">✕</button>` : ''}
      </div></div>`;
  }).join('');
  if (isOwner()) rl.querySelectorAll('[data-rel-del]').forEach(btn => btn.addEventListener('click', async () => {
    try { await post(`${P2P_API}/api/group/${state.currentGroupId}/relation/delete`, { fromUserId:state.currentUser.id, relationId:btn.getAttribute('data-rel-del') }); showInline('Relationship deleted.'); await refreshCircle(); }
    catch (e) { showInline(`Delete failed: ${e.message}`); }
  }));
}

function fillPeopleSelects(tree) {
  const people = (tree.people||[]).slice();
  const label  = p => `${p.name||p.email||'Unknown'}${p.kind!=='user' ? ` (${p.kind})` : ''}`;
  [document.getElementById('relASelect'), document.getElementById('relBSelect')].forEach(sel => {
    if (!sel) return; sel.innerHTML = '';
    people.forEach(p => { const o = document.createElement('option'); o.value=p.id; o.textContent=label(p); sel.appendChild(o); });
  });
}

function refreshManagePanel() {
  if (!state.currentGroupId) {
    document.getElementById('inviteNoGroup')?.style.setProperty('display', '');
    document.getElementById('invitePanel')?.style.setProperty('display', 'none'); return;
  }
  document.getElementById('inviteNoGroup')?.style.setProperty('display', 'none');
  document.getElementById('invitePanel')?.style.setProperty('display', '');
  const mpgn = document.getElementById('managePanelGroupName');
  if (mpgn) { const g = state.availableGroups.find(x => x.id===state.currentGroupId); mpgn.textContent = g ? g.name : 'Family Circle'; }
  renderMembersTab(); renderInviteTab(); renderPlaceholdersTab(); renderRelationsTab();
}

/* ─────────────────────────────────────────────
   GROUPS PAGE
───────────────────────────────────────────── */
function renderGroupsPage() {
  const grid = document.getElementById('groupListGrid'); if (!grid) return;
  if (!state.availableGroups.length) {
    grid.innerHTML = `<div class="empty-state"><div class="es-icon">🌐</div><h4>No circles yet</h4><p>Create your first family circle above.</p></div>`;
    return;
  }
  grid.innerHTML = state.availableGroups.map(g => {
    const sel = g.id === state.currentGroupId;
    return `<div class="group-item-card ${sel?'selected':''}" data-group-id="${esc(g.id)}">
      <div class="group-icon">🌳</div>
      <div class="group-item-info">
        <div class="g-name">${esc(g.name)}</div>
        <div class="g-meta">${g.ownerId===state.currentUser?.id ? '👑 You are owner' : '👥 Member'}</div>
        ${sel ? `<div class="g-meta" style="color:var(--success);font-weight:700;">✓ Active</div>` : ''}
      </div>
      <div class="group-item-actions">
        ${!sel ? `<button class="btn btn-outline-primary btn-sm" data-select-group="${esc(g.id)}">Select</button>` : `<span class="tag tag-member">Active</span>`}
      </div></div>`;
  }).join('');
  grid.querySelectorAll('[data-select-group]').forEach(btn => btn.addEventListener('click', async () => {
    const gid = btn.getAttribute('data-select-group'), g = state.availableGroups.find(x => x.id===gid);
    state.currentGroupId = gid;
    if (g) { state.currentGroupOwnerId=g.ownerId; setGroupName(g.name); const gp=document.getElementById('groupPicker'); if(gp) gp.value=gid; }
    await refreshCircle(true); renderGroupsPage(); showInline(`Switched to: ${g?.name||'circle'}`);
  }));
}

async function refreshGroupsPage() { await refreshGroups(state.currentGroupId); renderGroupsPage(); }

/* ─────────────────────────────────────────────
   FULL CIRCLE REFRESH
───────────────────────────────────────────── */
async function refreshCircle(forceAuto = false) {
  if (!state.currentUser?.id) return;
  await refreshGroups(state.currentGroupId);
  if (!state.currentGroupId) { clearTreeUI(); return; }

  // Load all locally stored photos for this group before rendering
  await loadLocalPhotosForGroup(state.currentGroupId);

  try {
    const res  = await fetch(`${P2P_API}/api/group/${state.currentGroupId}/tree/${state.currentUser.id}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not load tree');

    state.lastTree = {
      group:     data.group,
      people:    data.people    || [],
      relations: data.relations || [],
      positions: data.positions || [],
      invites:   data.invites   || [],
    };
    state.currentGroupOwnerId = data.group?.ownerId || state.currentGroupOwnerId;
    if (data.group?.name) setGroupName(data.group.name);

    fillPeopleSelects(state.lastTree);
    await renderTree(state.lastTree, forceAuto);
    if (document.getElementById('invite')?.classList.contains('visible')) refreshManagePanel();
  } catch (e) { clearTreeUI(); showInline(`Error loading circle: ${e.message}`); }
}

/* ─────────────────────────────────────────────
   DASHBOARD MINI-TREE
───────────────────────────────────────────── */
async function loadDashboardTree() {
  const nodesEl = document.getElementById('dashTreeNodes');
  const emptyEl = document.getElementById('dashTreeEmpty');
  const hintEl  = document.getElementById('dashTreeHint');
  const linesEl = document.getElementById('dashTreeLines');
  if (!nodesEl || !emptyEl) return;

  try {
    const user = state.currentUser; if (!user?.id) return;

    const gr      = await (await fetch(`${P2P_API}/api/me/${user.id}/groups`)).json();
    const groups  = gr.groups || [];
    if (!groups.length) { emptyEl.style.display='flex'; if(hintEl) hintEl.textContent='No family circle yet.'; return; }

    const group   = groups[0];

    // Load local photos for this group
    await loadLocalPhotosForGroup(group.id);

    const treeRes = await fetch(`${P2P_API}/api/group/${group.id}/tree/${user.id}`);
    if (!treeRes.ok) return;
    const tree    = await treeRes.json();
    const people  = tree.people || [];

    if (!people.length) { emptyEl.style.display='flex'; if(hintEl) hintEl.textContent=`${group.name} — No members yet`; return; }

    emptyEl.style.display='none';
    if (hintEl) hintEl.textContent=`${group.name} · ${people.length} people`;
    nodesEl.innerHTML=''; if(linesEl) linesEl.innerHTML='';

    const canvas  = document.getElementById('familyTreeEmbed');
    const W=canvas?.clientWidth||800, H=canvas?.clientHeight||480;
    const layout  = computeAutoLayout(tree, W, H);
    const savedPos = buildPosMap(tree.positions||[]);
    const nodeMap = new Map();

    people.forEach(p => {
      const el   = document.createElement('div');
      const isMe = p.kind==='user' && p.user_id===user.id;
      el.style.cssText = `position:absolute;width:120px;text-align:center;padding:10px 8px 8px;border-radius:14px;background:${isMe?'linear-gradient(180deg,#f0f7ff,#fff)':'#fff'};border:1.5px solid ${isMe?'#1d6fc4':'#dde6f0'};box-shadow:0 4px 14px rgba(15,40,80,.09);pointer-events:none;user-select:none;z-index:2;`;
      const src  = photoSrcFor(p), ini = initials(p.name||p.email||'?');
      const photoHtml = src
        ? `<img src="${esc(src)}" style="width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid ${isMe?'#1d6fc4':'#dde6f0'};"/>`
        : `<div style="width:48px;height:48px;border-radius:50%;background:#e8f2fc;display:flex;align-items:center;justify-content:center;font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:1rem;color:#1a5fa8;margin:0 auto;border:2px solid ${isMe?'#1d6fc4':'#dde6f0'};">${ini}</div>`;
      el.innerHTML=`
        <div style="margin:0 auto 6px;display:flex;justify-content:center;">${photoHtml}</div>
        <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:700;font-size:.75rem;color:#111827;line-height:1.2;word-break:break-word;">${esc(p.name||p.email||'Unknown')}</div>
        ${isMe?'<div style="font-size:.58rem;background:#1d6fc4;color:#fff;border-radius:999px;padding:1px 6px;display:inline-block;margin-top:3px;">You</div>':''}
        ${p.kind==='placeholder'?'<div style="font-size:.58rem;background:#fef3c7;color:#92400e;border-radius:999px;padding:1px 6px;display:inline-block;margin-top:3px;">Placeholder</div>':''}
        ${p.kind==='invite'?'<div style="font-size:.58rem;background:#fde8d8;color:#9a3412;border-radius:999px;padding:1px 6px;display:inline-block;margin-top:3px;">Invited</div>':''}`;
      const nW=120, nH=148;
      let pos = savedPos.get(p.id)||layout.get(p.id)||{x:30,y:30};
      pos.x=Math.max(4,Math.min(W-nW-4,pos.x)); pos.y=Math.max(4,Math.min(H-nH-4,pos.y));
      el.style.left=`${pos.x}px`; el.style.top=`${pos.y}px`;
      nodesEl.appendChild(el); nodeMap.set(p.id, {el,pos,w:nW,h:nH});
    });

    if (linesEl) {
      linesEl.setAttribute('viewBox',`0 0 ${W} ${H}`);
      for (const r of (tree.relations||[])) {
        const A=nodeMap.get(r.a_person_id), B=nodeMap.get(r.b_person_id); if(!A||!B) continue;
        const x1=A.pos.x+A.w/2, y1=UNDIRECTED.has(r.kind)?A.pos.y+A.h/2:A.pos.y+A.h;
        const x2=B.pos.x+B.w/2, y2=UNDIRECTED.has(r.kind)?B.pos.y+B.h/2:B.pos.y;
        const color=styleForKind(r.kind).stroke;
        const line=document.createElementNS('http://www.w3.org/2000/svg','line');
        line.setAttribute('x1',x1); line.setAttribute('y1',y1); line.setAttribute('x2',x2); line.setAttribute('y2',y2);
        line.setAttribute('stroke',color); line.setAttribute('stroke-width','1.5'); line.setAttribute('opacity','0.6');
        linesEl.appendChild(line);
      }
    }
  } catch (e) { console.warn('[Dashboard tree]', e.message||e); }
}

/* ─────────────────────────────────────────────
   EVENT WIRING
───────────────────────────────────────────── */
function wireEvents() {
  document.getElementById('groupPicker')?.addEventListener('change', async function () {
    state.currentGroupId = this.value || null;
    const g = state.availableGroups.find(x => x.id===state.currentGroupId);
    if (g) { state.currentGroupOwnerId=g.ownerId; setGroupName(g.name); }
    await refreshCircle(false);
  });

  document.getElementById('createGroupBtn')?.addEventListener('click', async () => {
    if (!state.currentUser?.id) return showInline('Connecting…');
    const name=(document.getElementById('createGroupNameInput')?.value||'').trim(); if(!name) return showInline('Enter a circle name.');
    const done=setBusy(document.getElementById('createGroupBtn'),'Creating…');
    try { const out=await post(`${P2P_API}/api/group/create`,{fromUserId:state.currentUser.id,name}); document.getElementById('createGroupNameInput').value=''; showInline('Circle created!'); await refreshGroups(out.group?.id||null); await refreshCircle(true); renderGroupsPage(); }
    catch(e){ showInline(`Create failed: ${e.message}`); } finally { done(); }
  });

  document.getElementById('circleInviteBtn')?.addEventListener('click', async () => {
    if (!state.currentGroupId) return showInline('No circle selected.');
    const email=(document.getElementById('circleInviteEmail')?.value||'').trim(); if(!email) return showInline('Enter an email address.');
    const done=setBusy(document.getElementById('circleInviteBtn'),'Sending…');
    try { const out=await post(`${P2P_API}/api/group/invite-email`,{fromUserId:state.currentUser.id,groupId:state.currentGroupId,email}); if(out.alreadyMember) showInline('Already a member.'); else if(out.alreadyPending) showInline('Already pending.'); else showInline('Invitation sent! 🎉'); document.getElementById('circleInviteEmail').value=''; await refreshCircle(false); await refreshInvitations(); renderInviteTab(); }
    catch(e){ showInline(`Invite failed: ${e.message}`); } finally { done(); }
  });

  document.getElementById('circleRenameBtn')?.addEventListener('click', async () => {
    if (!state.currentGroupId) return showInline('No circle selected.');
    const name=(document.getElementById('circleNameInput')?.value||'').trim(); if(!name) return showInline('Enter a name.');
    const done=setBusy(document.getElementById('circleRenameBtn'),'Saving…');
    try { await post(`${P2P_API}/api/group/${state.currentGroupId}/rename`,{fromUserId:state.currentUser.id,name}); showInline('Circle renamed.'); await refreshGroups(state.currentGroupId); await refreshCircle(false); renderGroupsPage(); }
    catch(e){ showInline(`Rename failed: ${e.message}`); } finally { done(); }
  });

  document.getElementById('phAddBtn')?.addEventListener('click', async () => {
    if (!state.currentGroupId) return showInline('No circle selected.');
    const name=(document.getElementById('phName')?.value||'').trim(), email=(document.getElementById('phEmail')?.value||'').trim();
    if(!name) return showInline('Enter a name.');
    const done=setBusy(document.getElementById('phAddBtn'),'Adding…');
    try { await post(`${P2P_API}/api/group/${state.currentGroupId}/person/placeholder`,{fromUserId:state.currentUser.id,name,email:email||null}); showInline('Placeholder added!'); document.getElementById('phName').value=''; document.getElementById('phEmail').value=''; await refreshCircle(true); renderPlaceholdersTab(); }
    catch(e){ showInline(`Add failed: ${e.message}`); } finally { done(); }
  });

  document.getElementById('relAddBtn')?.addEventListener('click', async () => {
    if (!state.currentGroupId) return showInline('No circle selected.');
    const aId=document.getElementById('relASelect')?.value, bId=document.getElementById('relBSelect')?.value, kind=document.getElementById('relKindSelect')?.value;
    if(!aId||!bId) return showInline('Pick both people.'); if(aId===bId) return showInline('Cannot be the same person.');
    const done=setBusy(document.getElementById('relAddBtn'),'…');
    try { await post(`${P2P_API}/api/group/${state.currentGroupId}/relation/add`,{fromUserId:state.currentUser.id,kind,aPersonId:aId,bPersonId:bId}); showInline('Relationship saved!'); await refreshCircle(true); renderRelationsTab(); }
    catch(e){ showInline(`Relationship failed: ${e.message}`); } finally { done(); }
  });

  document.getElementById('circleTreeRefreshBtn')?.addEventListener('click', () => refreshCircle(false));
  document.getElementById('circleRefreshBtn')?.addEventListener('click', () => { refreshCircle(false); refreshManagePanel(); });
  document.getElementById('circleAutoLayoutBtn')?.addEventListener('click', async () => {
    if (!state.currentGroupId) return showInline('No circle selected.');
    showInline('Auto-layout applied.'); await refreshCircle(true);
  });

  document.getElementById('notifBellBtn')?.addEventListener('click', e => {
    e.stopPropagation(); document.getElementById('notifDropdown')?.classList.toggle('open');
  });
  document.addEventListener('click', e => {
    const d=document.getElementById('notifDropdown'), b=document.getElementById('notifBellBtn');
    if(!d||!b||d.contains(e.target)||b.contains(e.target)) return;
    d.classList.remove('open');
  });

  window.addEventListener('resize', () => setTimeout(() => drawLines(state.lastTree), 100));
}

/* ─────────────────────────────────────────────
   CSS — camera overlay on tree nodes
   Injected once into <head> so no changes to index.html needed.
───────────────────────────────────────────── */
function injectStyles() {
  if (document.getElementById('p2p-styles')) return;
  const s = document.createElement('style'); s.id = 'p2p-styles';
  s.textContent = `
    .tn-photo { overflow: visible !important; }
    .tn-photo-overlay {
      position: absolute; inset: 0; border-radius: 50%;
      background: rgba(0,0,0,.45);
      display: flex; align-items: center; justify-content: center;
      font-size: 1.1rem; opacity: 0; transition: opacity .2s;
      cursor: pointer; z-index: 3; pointer-events: auto;
    }
    .tree-node:hover .tn-photo-overlay { opacity: 1; }
    .tree-node.dragging .tn-photo-overlay { opacity: 0 !important; }
  `;
  document.head.appendChild(s);
}

/* ─────────────────────────────────────────────
   EXPOSE TO index.html via window.KK
───────────────────────────────────────────── */
function exposeAPI() {
  window.KK.p2pRefreshCircle      = refreshCircle;
  window.KK.p2pRefreshManagePanel = refreshManagePanel;
  window.KK.p2pRefreshGroupsPage  = refreshGroupsPage;
  window.KK.p2pLoadDashboardTree  = loadDashboardTree;
}

/* ─────────────────────────────────────────────
   BOOT
───────────────────────────────────────────── */
whenKKReady(async () => {
  injectStyles();
  exposeAPI();
  wireEvents();
  try {
    await bootstrapFromMainApp();
    await ensureWSAuthed();
    await refreshInvitations();
    await refreshGroups();
    await loadDashboardTree();
  } catch (e) {
    console.warn('[p2pClient boot]', e.message);
    showInline('Family circle offline — check your connection.');
  }
});
