// src/preload.js
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  login:          (credentials) => ipcRenderer.invoke('auth:login', credentials),
  register:       (credentials) => ipcRenderer.invoke('auth:register', credentials),
  logout:         ()            => ipcRenderer.invoke('auth:logout'),
  decodeToken:    (token)       => ipcRenderer.invoke('auth:decode-token', token),
  getCurrentUser: (token)       => ipcRenderer.invoke('auth:get-current-user', token),
  updateUserProfile: (profile, token) => ipcRenderer.invoke('auth:update-profile', { profile, token }),

  // ── Invitation / claim ────────────────────────────────────────
  checkInvitation: (email) => ipcRenderer.invoke('auth:check-invitation', email),
  claimInvitation: ({ email, inviteToken }) =>
    ipcRenderer.invoke('auth:claim-invitation', { email, inviteToken }),

  // ── Change password ───────────────────────────────────────────
  changePassword: (payload) => ipcRenderer.invoke('auth:change-password', payload),

  // ── File uploads ──────────────────────────────────────────────
  uploadFiles: (data) => ipcRenderer.invoke('upload:files', data),

  // ── Upload progress ───────────────────────────────────────────
  onUploadProgress: (cb) =>
    ipcRenderer.on('upload:progress', (_e, data) => cb(data)),
  removeUploadProgressListener: () =>
    ipcRenderer.removeAllListeners('upload:progress'),

  // ── Records ───────────────────────────────────────────────────
  getAllRecords:    (token)        => ipcRenderer.invoke('records:get-all', token),
  getRecordById:   (id, token)    => ipcRenderer.invoke('records:get-one', { id, token }),
  deleteRecord:    (id, token)    => ipcRenderer.invoke('records:delete', { id, token }),
  deleteRecords:   (ids, token)   => ipcRenderer.invoke('records:delete-many', { ids, token }),
  regenerateTopic: (id, token)    => ipcRenderer.invoke('records:regenerate-topic', { id, token }),

  // ── Ask / QA (non-streaming) ──────────────────────────────────
  askQuestionOn:  (question, token, scope = { type: 'all' }) =>
    ipcRenderer.invoke('ask:on:question',  { question, token, scope }),
  askQuestionOff: (question, token, scope = { type: 'all' }) =>
    ipcRenderer.invoke('ask:off:question', { question, token, scope }),
  askCategoryOn:  (category, token, scope = { type: 'all' }) =>
    ipcRenderer.invoke('ask:on:category',  { category, token, scope }),
  askCategoryOff: (category, token, scope = { type: 'all' }) =>
    ipcRenderer.invoke('ask:off:category', { category, token, scope }),

  // ── Media ─────────────────────────────────────────────────────
  getAllPhotos: (token) => ipcRenderer.invoke('photos:get-all', token),
  getAllMusic:  (token) => ipcRenderer.invoke('music:get-all',  token),

  // ── Ollama / llama-server status ──────────────────────────────
  getOllamaStatus:     () => ipcRenderer.invoke('ollama:status'),
  ensureOllamaStarted: () => ipcRenderer.invoke('ollama:ensure-started'),
  stopOllama:          () => ipcRenderer.invoke('ollama:stop'),

  // ── Navigation ────────────────────────────────────────────────
  navigateTo: (page) => ipcRenderer.send('navigate-to', page),

  // ── Streaming Q&A ─────────────────────────────────────────────
  askStreamStart: ({ question, token, scope, topK = 4, mode }) =>
    ipcRenderer.send('ask:on:question:stream', { question, token, scope, topK, mode }),
  onAskStreamChunk: (cb) =>
    ipcRenderer.on('ask:on:question:stream:chunk', (_e, data) => cb(data)),
  onAskStreamError: (cb) =>
    ipcRenderer.on('ask:on:question:stream:error', (_e, msg) => cb(msg)),
  removeAskStreamListeners: () => {
    ipcRenderer.removeAllListeners('ask:on:question:stream:chunk');
    ipcRenderer.removeAllListeners('ask:on:question:stream:error');
  },

  // ── ElevenLabs STT / TTS ─────────────────────────────────────
  transcribeWithElevenLabs: (uint8, mimeType) =>
    ipcRenderer.invoke('stt:elevenlabs', { audio: Buffer.from(uint8), mimeType }),
  ttsElevenLabs: (text) => ipcRenderer.invoke('tts:elevenlabs', { text }),

  setElevenLabsKey:       (apiKey) => ipcRenderer.invoke('elevenlabs:key:set',   { apiKey }),
  getElevenLabsKeyStatus: ()       => ipcRenderer.invoke('elevenlabs:key:get'),
  clearElevenLabsKey:     ()       => ipcRenderer.invoke('elevenlabs:key:clear'),

  // Alternate naming used by some renderer code
  sttElevenlabs: (payload) => ipcRenderer.invoke('stt:elevenlabs', payload),
  ttsElevenlabs: (payload) => ipcRenderer.invoke('tts:elevenlabs', payload),

  // ── Circle photos ─────────────────────────────────────────────
  circlePhotos: {
    save:   (payload) => ipcRenderer.invoke('circle-photos:save',   payload),
    get:    (payload) => ipcRenderer.invoke('circle-photos:get',    payload),
    list:   (payload) => ipcRenderer.invoke('circle-photos:list',   payload),
    delete: (payload) => ipcRenderer.invoke('circle-photos:delete', payload),
  },

  // ── Database management ───────────────────────────────────────
  dbInfo:            ()  => ipcRenderer.invoke('db:info'),
  dbBackup:          ()  => ipcRenderer.invoke('db:backup'),
  dbBackupTo:        ()  => ipcRenderer.invoke('db:backup-to'),
  dbRestore:         ()  => ipcRenderer.invoke('db:restore'),
  dbListBackups:     ()  => ipcRenderer.invoke('db:list-backups'),
  dbDeleteBackup:    (p) => ipcRenderer.invoke('db:delete-backup', p),
  dbRestoreFromList: (p) => ipcRenderer.invoke('db:restore-from-list', p),
  dbOpenFolder:      ()  => ipcRenderer.invoke('db:open-folder'),

  // ── Bio-Metrics ───────────────────────────────────────────────
  // Fetch SLEDSS results from sledss.elderchatgpt.com
  // payload: { email: string, password: string }
  // returns: { success: bool, data: { score, date, risk, interpretation, domains[], notes } }
  fetchSledss: (payload) => ipcRenderer.invoke('biometrics:fetch-sledss', payload),

  // Fetch Memory Test results from elderchatgpt.com/memorytest
  // payload: { email: string, password: string }
  // returns: { success: bool, data: { score, date, risk, interpretation, domains[], recs[] } }
  fetchMemoryTest: (payload) => ipcRenderer.invoke('biometrics:fetch-memory', payload),

  // Upload a bio-metrics text blob as a queryable Vault document
  // payload: { text: string, token: string }
  // returns: { success: bool, data: { recordId: number } }
  uploadBioMetrics: (payload) => ipcRenderer.invoke('biometrics:upload-vault', payload),

  // Load a named demo profile directly into the Vault for LLM testing
  // payload: { profile: 'moderate' | 'high' | 'low', token: string }
  // returns: { success: bool, data: { recordId, profile, patient, sledss, memoryTest, combinedInsights } }
  loadBioDemo: (payload) => ipcRenderer.invoke('biometrics:load-demo', payload),
});

contextBridge.exposeInMainWorld('p2p', {
  saveFile: async (name, uint8) => {
    const res = await ipcRenderer.invoke('p2p:save-file', { name, data: Buffer.from(uint8) });
    return res;
  },
});