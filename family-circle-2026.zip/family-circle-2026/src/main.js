// src/main.js
const { app, BrowserWindow, ipcMain, nativeImage, Menu } = require('electron');
const path = require('path');

// ── Database manager (MUST load before ipcMainHandlers) ───────
const { handleStartupDatabaseCheck } = require('../app/ipc/dbManager');

// ── Load all IPC handlers ──────────────────────────────────────
require('../app/ipc/ipcMainHandlers');

// ── llama-server lifecycle ─────────────────────────────────────
const { ensureStarted, stop: stopLlama } = require('../app/ipc/llamaProcess');

// ── Keep-alive pings ───────────────────────────────────────────
const { startKeepAlive, stopKeepAlive } = require('../app/ipc/keepAlive');

let mainWindow;

function getIconPath() {
  const base = app.isPackaged
    ? path.join(process.resourcesPath, 'assets', 'icons')
    : path.join(__dirname, '..', 'assets', 'icons');
  if (process.platform === 'win32')  return path.join(base, 'family-circle.ico');
  if (process.platform === 'darwin') return path.join(base, 'family-circle.icns');
  return path.join(base, 'family-circle.png');
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1200,
    height: 800,
    icon:   getIconPath(),
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration:  false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  Menu.setApplicationMenu(null);
  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, '..', 'public', 'login.html'));
}

app.whenReady().then(async () => {

  // ── Step 1: Handle database (existing/new/delete) ─────────────
  // This shows a native dialog BEFORE the window opens if needed
  try {
    const result = await handleStartupDatabaseCheck();
    console.log('[main] Database ready, action:', result.action);
  } catch (e) {
    console.error('[main] Database check failed:', e.message);
    // Open DB anyway so app can still function
    try { require('../database/db').openDatabase(); } catch (_) {}
  }

  // ── Step 2: Start llama-server ────────────────────────────────
  console.log('[main] Starting local AI servers...');
  try {
    const ok = await ensureStarted({ log: true });
    if (ok) console.log('[main] ✓ Both AI servers ready');
    else     console.warn('[main] ⚠ AI servers did not start');
  } catch (e) {
    console.warn('[main] AI server start error:', e.message);
  }

  // ── Step 3: Keep-alive pings ──────────────────────────────────
  try { startKeepAlive(); } catch (e) { console.warn('[main] Keep-alive failed:', e.message); }

  // ── Step 4: Open the window ───────────────────────────────────
  createWindow();
});

ipcMain.on('navigate-to', (_event, page) => {
  const win = BrowserWindow.getFocusedWindow();
  if (win) win.loadFile(path.join(__dirname, '..', 'public', page));
});

// Triggered by renderer when user clicks "Uninstall" or a settings option
ipcMain.handle('app:check-uninstall-db', async () => {
  const { handleUninstallDatabaseCheck } = require('../app/ipc/dbManager');
  await handleUninstallDatabaseCheck();
  return { success: true };
});

app.on('before-quit', async () => {
  try { stopKeepAlive(); } catch (_) {}
  try { stopLlama({ log: true }); } catch (_) {}
});

app.on('window-all-closed', async () => {
  if (process.platform !== 'darwin') {
    try { stopKeepAlive(); } catch (_) {}
    try { stopLlama({ log: true }); } catch (_) {}
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});