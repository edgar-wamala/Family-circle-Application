// database/db.js
const path     = require('path');
const fs       = require('fs');
const { app }  = require('electron');
const Database = require('better-sqlite3');

const dbDirectory = app.getPath('userData');
const dbPath      = path.join(dbDirectory, 'family.db');
const backupDir   = path.join(dbDirectory, 'backups');

if (!fs.existsSync(dbDirectory)) fs.mkdirSync(dbDirectory, { recursive: true });
if (!fs.existsSync(backupDir))   fs.mkdirSync(backupDir,   { recursive: true });

let db = null;

// ── Open or reopen the database ───────────────────────────────
function openDatabase() {
  if (db) { try { db.close(); } catch (_) {} }
  db = new Database(dbPath);
  console.log('Connected to SQLite DB at:', dbPath);
  runMigrations();
  return db;
}

// ── Check if a database file already exists ───────────────────
function databaseExists() {
  return fs.existsSync(dbPath);
}

// ── Delete the database file ──────────────────────────────────
function deleteDatabase() {
  if (db) { try { db.close(); db = null; } catch (_) {} }
  if (fs.existsSync(dbPath)) fs.unlinkSync(dbPath);
  console.log('Database deleted.');
}

// ── Backup the database ───────────────────────────────────────
// Returns the path of the backup file created
function backupDatabase(customPath = null) {
  if (!fs.existsSync(dbPath)) throw new Error('No database to back up.');

  const stamp      = new Date().toISOString().replace(/[:.]/g, '-');
  const backupName = `family-backup-${stamp}.db`;
  const dest       = customPath || path.join(backupDir, backupName);

  // Use better-sqlite3's built-in backup (safe, no corruption)
  if (db) {
    db.backup(dest);
  } else {
    fs.copyFileSync(dbPath, dest);
  }

  console.log('Database backed up to:', dest);
  return dest;
}

// ── Restore the database from a backup file ───────────────────
function restoreDatabase(backupFilePath) {
  if (!fs.existsSync(backupFilePath))
    throw new Error('Backup file not found: ' + backupFilePath);

  // Close current connection
  if (db) { try { db.close(); db = null; } catch (_) {} }

  // Copy backup over current DB
  fs.copyFileSync(backupFilePath, dbPath);
  console.log('Database restored from:', backupFilePath);

  // Reopen
  openDatabase();
}

// ── List all backup files ─────────────────────────────────────
function listBackups() {
  if (!fs.existsSync(backupDir)) return [];
  return fs.readdirSync(backupDir)
    .filter(f => f.endsWith('.db'))
    .map(f => {
      const full  = path.join(backupDir, f);
      const stats = fs.statSync(full);
      return {
        name:     f,
        path:     full,
        size:     stats.size,
        sizeKB:   Math.round(stats.size / 1024),
        created:  stats.birthtime.toISOString(),
        modified: stats.mtime.toISOString(),
      };
    })
    .sort((a, b) => new Date(b.modified) - new Date(a.modified)); // newest first
}

// ── Run all migrations ────────────────────────────────────────
function runMigrations() {
  // Users table
  db.prepare(`
    CREATE TABLE IF NOT EXISTS users (
      id       INTEGER PRIMARY KEY AUTOINCREMENT,
      email    TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL
    )
  `).run();

  // Records table
  db.prepare(`
    CREATE TABLE IF NOT EXISTS records (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id        INTEGER,
      extracted_text TEXT NOT NULL,
      extracted_json TEXT,
      uploaded_at    TEXT DEFAULT CURRENT_TIMESTAMP,
      file_name      TEXT,
      topic          TEXT,
      file_path      TEXT
    )
  `).run();

  // Records column migrations
  const recordCols = ['file_name TEXT', 'topic TEXT', 'file_path TEXT'];
  const existingRecordCols = db.prepare('PRAGMA table_info(records)').all().map(c => c.name);
  for (const col of recordCols) {
    const name = col.split(' ')[0];
    if (!existingRecordCols.includes(name)) {
      try {
        db.prepare(`ALTER TABLE records ADD COLUMN ${col}`).run();
        console.log(`✅ Added ${name} column to records`);
      } catch (e) { console.warn(`⚠️ Could not add ${name}:`, e.message); }
    }
  }

  // Users column migrations
  const userColDefs = [
    'name TEXT', 'phone TEXT', 'age INTEGER', 'dob TEXT',
    'gender TEXT', 'profile_photo_path TEXT', 'address TEXT',
    'server_user_id TEXT', 'profile_photo_url TEXT', 'claimed_at INTEGER',
  ];
  const existingUserCols = db.prepare('PRAGMA table_info(users)').all().map(c => c.name);
  for (const col of userColDefs) {
    const name = col.split(' ')[0];
    if (!existingUserCols.includes(name)) {
      try {
        db.prepare(`ALTER TABLE users ADD COLUMN ${col}`).run();
        console.log(`✅ Added ${name} column to users`);
      } catch (e) { console.warn(`⚠️ Could not add ${name}:`, e.message); }
    }
  }
}

// ── Async helpers ─────────────────────────────────────────────
function getAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    try   { resolve(db.prepare(sql).get(params)); }
    catch (err) { reject(err); }
  });
}

function allAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    try   { resolve(db.prepare(sql).all(params)); }
    catch (err) { reject(err); }
  });
}

function runAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    try   { resolve(db.prepare(sql).run(params)); }
    catch (err) { reject(err); }
  });
}

// ── Initial open ──────────────────────────────────────────────
// Called by dbManager AFTER showing the user any prompts.
// Do NOT auto-open here — let dbManager decide.
module.exports = {
  openDatabase,
  databaseExists,
  deleteDatabase,
  backupDatabase,
  restoreDatabase,
  listBackups,
  dbPath,
  backupDir,
  getAsync,
  allAsync,
  runAsync,
  get db() { return db; },
};