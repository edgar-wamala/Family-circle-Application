// app/ipc/circlePhotosHandler.js
//
// Stores profile photos for family circle members locally in:
//   {userData}/circle_photos/{groupId}/{personId}{ext}
//
// An index file tracks all saved paths:
//   {userData}/circle_photos/index.json
//   → { "<groupId>/<personId>": "<absolute file path>" }
//
// IPC channels exposed:
//   circle-photos:save   { groupId, personId, dataURL, ext } → { success, filePath }
//   circle-photos:get    { groupId, personId }             → { success, filePath|null }
//   circle-photos:list   { groupId }                       → { success, photos: {personId→filePath} }
//   circle-photos:delete { groupId, personId }             → { success }

'use strict';

const { ipcMain, app } = require('electron');
const fs   = require('fs');
const path = require('path');

// ── Helpers ──────────────────────────────────────────────────────────────────

function getBaseDir() {
  const dir = path.join(app.getPath('userData'), 'circle_photos');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function getIndexPath() {
  return path.join(getBaseDir(), 'index.json');
}

function loadIndex() {
  try {
    const p = getIndexPath();
    if (!fs.existsSync(p)) return {};
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (_) { return {}; }
}

function saveIndex(idx) {
  try { fs.writeFileSync(getIndexPath(), JSON.stringify(idx, null, 2), 'utf8'); } catch (_) {}
}

function indexKey(groupId, personId) {
  return `${groupId}/${personId}`;
}

function getGroupDir(groupId) {
  const dir = path.join(getBaseDir(), String(groupId));
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

// ── IPC: Save photo ───────────────────────────────────────────────────────────
//
// payload: { groupId, personId, dataURL, ext }
//   dataURL — base64 data-URL string sent from renderer
//             (renderer uses FileReader because file.path is undefined
//              when contextIsolation:true)
//   ext     — file extension hint, e.g. ".jpg"
//
// Decodes the base64 and writes the image to userData, updates the index.
// ─────────────────────────────────────────────────────────────────────────────
ipcMain.handle('circle-photos:save', async (_event, { groupId, personId, dataURL, ext }) => {
  if (!groupId || !personId || !dataURL) {
    return { success: false, error: 'groupId, personId and dataURL are required' };
  }
  if (!String(dataURL).startsWith('data:image/')) {
    return { success: false, error: 'dataURL must be a base64 image data-URL' };
  }
  // Guard against absurdly large payloads (~3 MB limit)
  if (dataURL.length > 4 * 1024 * 1024) {
    return { success: false, error: 'Image too large (max ~3 MB)' };
  }

  try {
    const fileExt  = (ext || '.jpg').toLowerCase();
    const groupDir = getGroupDir(groupId);
    const destPath = path.join(groupDir, `${personId}${fileExt}`);

    // Remove any previous file for this person (may have a different extension)
    const idx = loadIndex();
    const key = indexKey(groupId, personId);
    const oldPath = idx[key];
    if (oldPath && oldPath !== destPath && fs.existsSync(oldPath)) {
      try { fs.unlinkSync(oldPath); } catch (_) {}
    }

    // Decode base64 and write to disk
    const base64Data = dataURL.replace(/^data:image\/\w+;base64,/, '');
    fs.writeFileSync(destPath, Buffer.from(base64Data, 'base64'));

    // Update index
    idx[key] = destPath;
    saveIndex(idx);

    return { success: true, filePath: destPath };
  } catch (err) {
    console.error('[circle-photos:save]', err.message);
    return { success: false, error: err.message || 'Failed to save photo' };
  }
});

// ── IPC: Get one photo path ───────────────────────────────────────────────────
ipcMain.handle('circle-photos:get', async (_event, { groupId, personId }) => {
  if (!groupId || !personId) return { success: false, error: 'groupId and personId required' };
  const idx      = loadIndex();
  const filePath = idx[indexKey(groupId, personId)] || null;
  // Verify file still exists on disk
  if (filePath && !fs.existsSync(filePath)) {
    // Stale entry — clean up
    delete idx[indexKey(groupId, personId)];
    saveIndex(idx);
    return { success: true, filePath: null };
  }
  return { success: true, filePath };
});

// ── IPC: List all photos for a group ─────────────────────────────────────────
// Returns { personId → filePath } for every stored photo in the group.
ipcMain.handle('circle-photos:list', async (_event, { groupId }) => {
  if (!groupId) return { success: false, error: 'groupId required' };
  const idx    = loadIndex();
  const prefix = `${groupId}/`;
  const photos = {};
  let dirty    = false;

  for (const [key, filePath] of Object.entries(idx)) {
    if (!key.startsWith(prefix)) continue;
    const personId = key.slice(prefix.length);
    if (fs.existsSync(filePath)) {
      photos[personId] = filePath;
    } else {
      // Stale — clean up
      delete idx[key];
      dirty = true;
    }
  }
  if (dirty) saveIndex(idx);
  return { success: true, photos };
});

// ── IPC: Delete one photo ─────────────────────────────────────────────────────
ipcMain.handle('circle-photos:delete', async (_event, { groupId, personId }) => {
  if (!groupId || !personId) return { success: false, error: 'groupId and personId required' };
  try {
    const idx      = loadIndex();
    const key      = indexKey(groupId, personId);
    const filePath = idx[key];
    if (filePath && fs.existsSync(filePath)) {
      try { fs.unlinkSync(filePath); } catch (_) {}
    }
    delete idx[key];
    saveIndex(idx);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});
