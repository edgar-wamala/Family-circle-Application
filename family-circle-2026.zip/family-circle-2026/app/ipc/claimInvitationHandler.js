// app/ipc/claimInvitationHandler.js
//
// auth:check-invitation(email)
//   → Checks server for an invite (pending OR accepted) for this email
//   → Returns { hasPendingInvite, groupName, ownerName, token, tempPassword }
//
// auth:claim-invitation({ email, inviteToken })
//   → Creates a local SQLite account using tempPassword from server
//   → User can then sign in with email + tempPassword immediately
//
// KEY FIX: invites are now auto-accepted on the server when sent,
// so we check for BOTH pending and accepted invites.

'use strict';

const { ipcMain } = require('electron');
const bcrypt      = require('bcrypt');
const jwt         = require('jsonwebtoken');
const { getAsync, runAsync } = require('../database/db');

const P2P_SERVER = process.env.P2P_SERVER || 'http://localhost:5020';
const JWT_SECRET = process.env.JWT_SECRET  || 'your-very-secure-secret';

// ── Helpers ───────────────────────────────────────────────────
function shapeUser(row) {
  if (!row) return null;
  return {
    id:                 row.id,
    email:              row.email,
    name:               row.name               ?? null,
    phone:              row.phone              ?? null,
    age:                row.age                ?? null,
    dob:                row.dob                ?? null,
    gender:             row.gender             ?? null,
    profile_photo_path: row.profile_photo_path ?? null,
    profile_photo_url:  row.profile_photo_url  ?? null,
  };
}

function issueToken(userId, email) {
  return jwt.sign({ userId, email }, JWT_SECRET, { expiresIn: '30d' });
}

async function fetchJSON(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(12_000) });
  if (!res.ok) throw new Error(`Server returned ${res.status}`);
  return res.json();
}

async function postJSON(url, body) {
  const res = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
    signal:  AbortSignal.timeout(12_000),
  });
  let data = null;
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error(data?.error || `Server returned ${res.status}`);
  return data ?? {};
}

async function ensureColumns() {
  const cols = [
    `ALTER TABLE users ADD COLUMN server_user_id TEXT`,
    `ALTER TABLE users ADD COLUMN profile_photo_url TEXT`,
    `ALTER TABLE users ADD COLUMN claimed_at INTEGER`,
  ];
  for (const sql of cols) {
    try { await runAsync(sql); } catch (_) {} // safe — column may already exist
  }
}

// ── IPC: auth:check-invitation ────────────────────────────────
// Returns hasPendingInvite=true for BOTH pending and accepted invites
// so the login flow works whether the user logs in immediately or later.
ipcMain.handle('auth:check-invitation', async (_event, email) => {
  const clean = String(email || '').trim().toLowerCase();
  if (!clean) return { success: false, error: 'Email required' };

  // Already has a local account — no claim needed
  try {
    const local = await getAsync('SELECT id FROM users WHERE LOWER(email)=LOWER(?)', [clean]);
    if (local) return { success: true, hasPendingInvite: false, alreadyLocal: true };
  } catch (_) {}

  // Ask server — returns hasPendingInvite:true for pending OR accepted invites
  try {
    const data = await fetchJSON(
      `${P2P_SERVER}/api/invitation-check?email=${encodeURIComponent(clean)}`
    );
    return {
      success:          true,
      hasPendingInvite: !!(data.hasPendingInvite),
      alreadyLocal:     false,
      groupName:        data.groupName    ?? null,
      ownerName:        data.ownerName    ?? null,
      token:            data.token        ?? null,
      tempPassword:     data.tempPassword ?? null,
    };
  } catch (e) {
    return { success: false, error: `Could not reach server: ${e.message}` };
  }
});

// ── IPC: auth:claim-invitation ────────────────────────────────
// Called when a user with an accepted invite logs in for the first time.
// Creates a local account so they can log in offline from next time.
ipcMain.handle('auth:claim-invitation', async (_event, { email, inviteToken }) => {
  const clean = String(email || '').trim().toLowerCase();
  if (!clean) return { success: false, error: 'Email required' };

  await ensureColumns();

  // A. Already local — just return a token
  try {
    const local = await getAsync(
      'SELECT id,email,name,phone,age,dob,gender,profile_photo_path FROM users WHERE LOWER(email)=LOWER(?)',
      [clean]
    );
    if (local) {
      const token = issueToken(local.id, local.email);
      return { success: true, alreadyLocal: true, token, user: shapeUser(local) };
    }
  } catch (e) {
    return { success: false, error: `Local DB error: ${e.message}` };
  }

  // B. Get tempPassword from server so we can set up the local account
  let tempPassword   = null;
  let serverUserId   = null;
  let serverUserName = null;

  try {
    const data = await fetchJSON(
      `${P2P_SERVER}/api/invitation-check?email=${encodeURIComponent(clean)}`
    );
    tempPassword = data.tempPassword ?? null;
    serverUserId = data.serverId     ?? null;
  } catch (e) {
    return { success: false, error: `Could not reach server: ${e.message}` };
  }

  // C. Register / get server user
  try {
    const regRes   = await postJSON(`${P2P_SERVER}/api/register`, { email: clean, name: clean });
    serverUserId   = serverUserId   || regRes.user?.id   || null;
    serverUserName = regRes.user?.name || null;
  } catch (_) {}

  // D. Accept invite on server (idempotent — safe if already accepted)
  if (inviteToken) {
    try { await postJSON(`${P2P_SERVER}/api/invitations/accept-link`, { token: inviteToken }); } catch (_) {}
  }

  // E. Create local SQLite account
  try {
    const plainPassword = tempPassword
      ? String(tempPassword).trim()
      : `invite-${clean}-${Date.now()}`;

    const passwordHash = await bcrypt.hash(plainPassword, 10);

    const displayName = (serverUserName && serverUserName !== clean)
      ? serverUserName
      : clean.split('@')[0];

    await runAsync(
      `INSERT INTO users (email, password, name, server_user_id, claimed_at) VALUES (?, ?, ?, ?, ?)`,
      [clean, passwordHash, displayName, serverUserId ?? null, Date.now()]
    );

    const newRow = await getAsync('SELECT * FROM users WHERE LOWER(email)=LOWER(?)', [clean]);
    if (!newRow) throw new Error('Failed to read back new local user row');

    // F. Mark claimed on server (best-effort)
    if (serverUserId) {
      postJSON(`${P2P_SERVER}/api/user/mark-claimed`, { serverUserId, email: clean }).catch(() => {});
    }

    const token = issueToken(newRow.id, clean);
    return { success: true, alreadyLocal: false, token, user: shapeUser(newRow) };

  } catch (e) {
    return { success: false, error: `Failed to create local account: ${e.message}` };
  }
});