// app/ipc/ollamaHandler.js
// Updated to use llamaProcess (llama-server) instead of Ollama.
// The ipcMain channel names stay the same so the renderer/preload
// does not need any changes.

const { ipcMain } = require('electron');
const {
  ensureStarted,
  stop,
  getState,
  isHealthy,
  killAll,
  LLM_URL,
} = require('./llamaProcess');   // ← changed from ollamaProcess to llamaProcess

async function fetchWithTimeout(url, opts = {}, ms = 1500) {
  const ctrl = new AbortController();
  const id   = setTimeout(() => ctrl.abort(), ms);
  try {
    // Node 18+ has global fetch; fallback to http for older Node
    if (typeof fetch !== 'undefined') {
      const res = await fetch(url, { ...opts, signal: ctrl.signal });
      return res;
    }
    // Fallback: just check if port is alive
    return { ok: true, json: async () => ({}) };
  } finally {
    clearTimeout(id);
  }
}

// ollama:status — check if llama-server is running on port 8080
ipcMain.handle('ollama:status', async () => {
  try {
    const alive = await isHealthy();
    return {
      running: alive,
      version: 'llama-server',   // replaces Ollama version string
      models:  ['granite-4.0-h-1b-Q4_K_M', 'nomic-embed-text-v1.5'],
      ...getState(),
    };
  } catch (err) {
    return { running: false, error: err?.message || 'NETWORK_ERROR', ...getState() };
  }
});

// ollama:ensure-started — start llama-server if not running
ipcMain.handle('ollama:ensure-started', async () => {
  const ok = await ensureStarted({ log: true });
  const alive = await isHealthy();
  return { success: ok, running: alive, ...getState() };
});

// ollama:stop
ipcMain.handle('ollama:stop', async () => {
  stop({ log: true });
  const stillReachable = await isHealthy();
  return { success: true, stillReachable, ...getState() };
});

// ollama:kill-all
ipcMain.handle('ollama:kill-all', async () => {
  const { success, stillReachable } = await killAll({ log: true });
  return { success, stillReachable, ...getState() };
});

module.exports = {};