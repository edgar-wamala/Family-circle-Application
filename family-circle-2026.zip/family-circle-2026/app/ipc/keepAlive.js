// app/ipc/keepAlive.js
// Online pings → hosted Ollama server (unchanged)
// Local pings  → llama-server on ports 8080 (LLM) and 8081 (embed)
//                (changed from Ollama port 11434)

const axios = require('axios');

// ── Online hosted server (unchanged) ──────────────────────────
const SLM_URL_ONLINE     = process.env.SLM_URL          || 'http://208.109.228.76:11435/api/generate';
const OLLAMA_URL_ONLINE   = process.env.OLLAMA_URL       || 'http://208.109.228.76:11435';
const SLM_MODEL           = process.env.SLM_MODEL        || 'granite3.2:2b';
const OLLAMA_EMBED_MODEL  = process.env.OLLAMA_EMBED_MODEL || 'all-minilm';

// ── Local llama-server (changed from Ollama 11434) ─────────────
// LLM  → port 8080  /v1/chat/completions
// Embed → port 8081  /embedding
const LOCAL_LLM_URL   = 'http://127.0.0.1:8080';
const LOCAL_EMBED_URL = 'http://127.0.0.1:8081';

const KEEP_ALIVE_MS = Number(process.env.KEEP_ALIVE_MS || 90 * 60 * 1000);

let intervalId = null;

// ── Online pings (Ollama format — unchanged) ───────────────────
async function pingOnlineLLM() {
  try {
    await axios.post(
      SLM_URL_ONLINE,
      { model: SLM_MODEL, prompt: 'ping', stream: false, options: { num_predict: 1 } },
      { timeout: 20000 }
    );
    console.log('✅ Granite keep-alive ok [online]');
  } catch (e) {
    console.warn('⚠️  Granite keep-alive failed [online]:', e.message || e);
  }
}

async function pingOnlineEmbed() {
  try {
    await axios.post(
      `${OLLAMA_URL_ONLINE}/api/embeddings`,
      { model: OLLAMA_EMBED_MODEL, prompt: 'ok' },
      { timeout: 20000 }
    );
    console.log('✅ Embeddings keep-alive ok [online]');
  } catch (e) {
    console.warn('⚠️  Embeddings keep-alive failed [online]:', e.message || e);
  }
}

// ── Local pings (llama-server format — updated) ────────────────
async function pingLocalLLM() {
  try {
    // llama-server uses OpenAI-compatible /v1/chat/completions
    await axios.post(
      `${LOCAL_LLM_URL}/v1/chat/completions`,
      {
        messages: [{ role: 'user', content: 'ping' }],
        max_tokens: 1,
        temperature: 0,
        stream: false,
      },
      { timeout: 20000 }
    );
    console.log('✅ Granite keep-alive ok [local llama-server :8080]');
  } catch (e) {
    // Local server may not be running — that is fine
    console.warn('⚠️  Granite keep-alive failed [local]:', e.message || e);
  }
}

async function pingLocalEmbed() {
  try {
    // Nomic llama-server uses /embedding
    await axios.post(
      `${LOCAL_EMBED_URL}/embedding`,
      { content: 'search_query: ok' },
      { timeout: 20000 }
    );
    console.log('✅ Embeddings keep-alive ok [local nomic :8081]');
  } catch (e) {
    console.warn('⚠️  Embeddings keep-alive failed [local]:', e.message || e);
  }
}

async function pingAll() {
  // Online
  await pingOnlineLLM();
  await pingOnlineEmbed();
  // Local llama-server
  await pingLocalLLM();
  await pingLocalEmbed();
}

function startKeepAlive() {
  if (intervalId) return;
  pingAll();  // immediate warm ping on start
  intervalId = setInterval(pingAll, KEEP_ALIVE_MS);
  console.log(`🔄 Keep-alive started (every ${Math.round(KEEP_ALIVE_MS / 60000)} min) — online + local llama-server`);
}

function stopKeepAlive() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
    console.log('🛑 Keep-alive stopped');
  }
}

module.exports = { startKeepAlive, stopKeepAlive };