const { ipcMain } = require('electron');
const store = require('./secureStore');

ipcMain.handle('elevenlabs:key:set', async (_e, { apiKey }) => {
  if (!apiKey || typeof apiKey !== 'string') {
    return { success: false, error: 'Missing apiKey' };
  }
  store.set('elevenlabsApiKey', apiKey.trim());
  return { success: true };
});

ipcMain.handle('elevenlabs:key:get', async () => {
  const apiKey = store.get('elevenlabsApiKey') || '';
  return { success: true, apiKey: apiKey ? '***saved***' : '' }; // don’t return real key
});

ipcMain.handle('elevenlabs:key:clear', async () => {
  store.delete('elevenlabsApiKey');
  return { success: true };
});
