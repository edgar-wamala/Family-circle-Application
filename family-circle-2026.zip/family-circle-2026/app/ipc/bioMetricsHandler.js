// app/ipc/bioMetricsHandler.js
//
// IPC channels:
//   biometrics:fetch-sledss    — fetch from real API (falls back to demo)
//   biometrics:fetch-memory    — fetch from real API (falls back to demo)
//   biometrics:upload-vault    — write health report as a queryable Vault record
//   biometrics:load-demo       — inject a named demo profile straight to Vault (for testing)
//                                payload: { profile: 'moderate' | 'high' | 'low', token }
//
// Demo profiles are in bioMetricsDemoData.js

'use strict';

const { ipcMain, app } = require('electron');
const path   = require('path');
const fs     = require('fs');

const { runAsync, getAsync } = require('../database/db');
const { decodeToken }        = require('../model/userModel');
const { PROFILES, buildVaultText } = require('./bioMetricsDemoData');

const SLEDSS_BASE = process.env.SLEDSS_API_URL || 'https://sledss.elderchatgpt.com';
const MEMORY_BASE = process.env.MEMORY_API_URL || 'https://elderchatgpt.com/memorytest';
const API_TIMEOUT = 15_000;

// ── HTTP helper ───────────────────────────────────────────────
async function postJSON(url, body) {
  const ctrl  = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), API_TIMEOUT);
  try {
    const res  = await fetch(url, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body:    JSON.stringify(body),
      signal:  ctrl.signal,
    });
    clearTimeout(timer);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = text; }
    return { ok: res.ok, status: res.status, data };
  } catch (err) {
    clearTimeout(timer);
    throw err;
  }
}

// ── Normalise raw API responses ───────────────────────────────
function normaliseSledss(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const score  = raw.score ?? raw.total_score ?? raw.sledss_score ?? null;
  if (score === null) return null;
  const date   = raw.date ?? raw.assessment_date ?? raw.created_at?.slice(0, 10) ?? new Date().toISOString().slice(0, 10);
  const risk   = String(raw.risk ?? raw.risk_level ?? raw.category ?? 'unknown').toLowerCase();
  const interp = raw.interpretation ?? raw.summary ?? raw.comment ?? '';
  const domains = Array.isArray(raw.domains) ? raw.domains : Array.isArray(raw.domain_scores) ? raw.domain_scores : [];
  const notes   = raw.notes ?? raw.clinical_notes ?? raw.physician_notes ?? '';
  return { score: Number(score), date, risk, interpretation: interp, domains, notes };
}

function normaliseMemory(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const score = raw.score ?? raw.total_score ?? raw.moca_score ?? null;
  if (score === null) return null;
  const date   = raw.date ?? raw.test_date ?? raw.created_at?.slice(0, 10) ?? new Date().toISOString().slice(0, 10);
  const risk   = String(raw.risk ?? raw.risk_level ?? raw.category ?? 'unknown').toLowerCase();
  const interp = raw.interpretation ?? raw.summary ?? raw.comment ?? '';
  const domains = Array.isArray(raw.domains) ? raw.domains : Array.isArray(raw.domain_scores) ? raw.domain_scores : [];
  const recs    = Array.isArray(raw.recommendations) ? raw.recommendations : Array.isArray(raw.recs) ? raw.recs : [];
  return { score: Number(score), date, risk, interpretation: interp, domains, recs };
}

// ── Ensure extra columns exist ────────────────────────────────
async function ensureBioColumns() {
  for (const sql of [
    `ALTER TABLE records ADD COLUMN source TEXT`,
    `ALTER TABLE records ADD COLUMN source_type TEXT`,
  ]) {
    try { await runAsync(sql); } catch (_) {}
  }
}

// ── Write (or update) a Vault record ─────────────────────────
async function writeVaultRecord(userId, text, label) {
  await ensureBioColumns();

  const existing = await getAsync(
    `SELECT id FROM records WHERE user_id = ? AND source_type = 'biometrics' LIMIT 1`,
    [userId]
  );

  const now      = new Date().toISOString();
  const fileName = label || 'Bio-Metrics Health Report';
  const topic    = 'Personal health data — SLEDSS lupus disease activity and cognitive memory assessment';

  if (existing) {
    await runAsync(
      `UPDATE records SET extracted_text = ?, topic = ?, uploaded_at = ?, file_name = ? WHERE id = ?`,
      [text, topic, now, fileName, existing.id]
    );
    console.log(`[bioMetrics] Updated Vault record id=${existing.id}`);
    return existing.id;
  }

  const dir      = path.join(app.getPath('userData'), 'biometrics');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const filePath = path.join(dir, `biometrics_${userId}.txt`);
  fs.writeFileSync(filePath, text, 'utf8');

  const result = await runAsync(
    `INSERT INTO records (user_id, file_name, file_path, extracted_text, topic, uploaded_at, source, source_type)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [userId, fileName, filePath, text, topic, now, 'biometrics', 'biometrics']
  );
  console.log(`[bioMetrics] Created new Vault record id=${result.lastID}`);
  return result.lastID;
}

// ════════════════════════════════════════════════════════════
// IPC: biometrics:load-demo
//
// Injects a named demo profile directly into the Vault so the
// LLM can be queried about it immediately — no real API needed.
//
// payload: { profile: 'moderate' | 'high' | 'low', token: string }
// ════════════════════════════════════════════════════════════
ipcMain.handle('biometrics:load-demo', async (_event, { profile = 'moderate', token } = {}) => {
  if (!token) return { success: false, error: 'Not authenticated.' };

  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Invalid session.' };

  const profileData = PROFILES[profile];
  if (!profileData) return { success: false, error: `Unknown profile: "${profile}". Use moderate, high, or low.` };

  try {
    const text     = buildVaultText(profileData);
    const label    = `Bio-Metrics — ${profileData.patient.name} (Demo: ${profile} risk)`;
    const recordId = await writeVaultRecord(decoded.userId, text, label);

    return {
      success: true,
      data: {
        recordId,
        profile,
        patient:          profileData.patient,
        sledss:           profileData.sledss,
        memoryTest:       profileData.memoryTest,
        combinedInsights: profileData.combinedInsights,
      },
    };
  } catch (err) {
    console.error('[bioMetrics] load-demo error:', err.message);
    return { success: false, error: err.message };
  }
});

// ════════════════════════════════════════════════════════════
// IPC: biometrics:fetch-sledss
// ════════════════════════════════════════════════════════════
ipcMain.handle('biometrics:fetch-sledss', async (_event, { email, password } = {}) => {
  if (!email || !password) return { success: false, error: 'Email and password are required.' };

  let authToken = null;
  try {
    const loginRes = await postJSON(`${SLEDSS_BASE}/api/login`, { email, password });
    if (loginRes.ok && loginRes.data) {
      authToken = loginRes.data.token || loginRes.data.access_token || loginRes.data.jwt;
    }
  } catch (e) {
    console.warn('[bioMetrics] SLEDSS login failed:', e.message, '— using demo data');
  }

  let normalised = null;
  if (authToken) {
    try {
      const ctrl  = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), API_TIMEOUT);
      const res   = await fetch(`${SLEDSS_BASE}/api/results/latest`, {
        headers: { Authorization: `Bearer ${authToken}`, Accept: 'application/json' },
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (res.ok) normalised = normaliseSledss((await res.json())?.data);
    } catch (e) { console.warn('[bioMetrics] SLEDSS fetch error:', e.message); }
  }

  if (!normalised) {
    console.log('[bioMetrics] Using SLEDSS demo data (moderate profile)');
    normalised = PROFILES.moderate.sledss;
  }

  return { success: true, data: normalised };
});

// ════════════════════════════════════════════════════════════
// IPC: biometrics:fetch-memory
// ════════════════════════════════════════════════════════════
ipcMain.handle('biometrics:fetch-memory', async (_event, { email, password } = {}) => {
  if (!email || !password) return { success: false, error: 'Email and password are required.' };

  let authToken = null;
  try {
    const loginRes = await postJSON(`${MEMORY_BASE}/api/login`, { email, password });
    if (loginRes.ok && loginRes.data) {
      authToken = loginRes.data.token || loginRes.data.access_token || loginRes.data.jwt;
    }
  } catch (e) {
    console.warn('[bioMetrics] Memory login failed:', e.message, '— using demo data');
  }

  let normalised = null;
  if (authToken) {
    try {
      const ctrl  = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), API_TIMEOUT);
      const res   = await fetch(`${MEMORY_BASE}/api/results/latest`, {
        headers: { Authorization: `Bearer ${authToken}`, Accept: 'application/json' },
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (res.ok) normalised = normaliseMemory((await res.json())?.data);
    } catch (e) { console.warn('[bioMetrics] Memory fetch error:', e.message); }
  }

  if (!normalised) {
    console.log('[bioMetrics] Using Memory Test demo data (moderate profile)');
    normalised = PROFILES.moderate.memoryTest;
  }

  return { success: true, data: normalised };
});

// ════════════════════════════════════════════════════════════
// IPC: biometrics:upload-vault
// ════════════════════════════════════════════════════════════
ipcMain.handle('biometrics:upload-vault', async (_event, { text, token } = {}) => {
  if (!text || !token) return { success: false, error: 'Text and token are required.' };
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated.' };
  try {
    const recordId = await writeVaultRecord(decoded.userId, text, 'Bio-Metrics Health Report');
    return { success: true, data: { recordId } };
  } catch (err) {
    return { success: false, error: err.message };
  }
});