// app/ipc/uploadHandler.js
// ── Progress events sent to renderer during upload ────────────
// Each stage fires: event.sender.send('upload:progress', { stage, message, pct })
//
// Stages:
//   1. saving      → "Saving file to vault…"            10%
//   2. extracting  → "Extracting text from document…"   30%
//   3. topic       → "Analysing document topic…"         60%
//   4. done        → "Document ready!"                  100%

const { ipcMain, app } = require('electron');
const fs   = require('fs');
const path = require('path');
const axios = require('axios');
const extractFamilyDataFromFile = require('../services/extract');
const { decodeToken }           = require('../model/userModel');
const { runAsync, getAsync }    = require('../database/db');

// ── Config ────────────────────────────────────────────────────
const SLM_URL_ONLINE     = process.env.SLM_URL          || 'http://208.109.228.76:11435/api/generate';
const OLLAMA_URL_ONLINE   = process.env.OLLAMA_URL       || 'http://208.109.228.76:11435';

// Offline → llama-server on port 8080/8081
const SLM_URL_OFFLINE    = 'http://127.0.0.1:8080/v1/chat/completions';
const OLLAMA_URL_OFFLINE  = 'http://127.0.0.1:8081';

const SLM_MODEL           = process.env.SLM_MODEL          || 'granite3.2:2b';
const OLLAMA_EMBED_MODEL  = process.env.OLLAMA_EMBED_MODEL  || 'all-minilm';
const EMBEDDING_DIM       = Number(process.env.EMBEDDING_DIM || 384);

const LINES_PER_CHUNK     = 120;
const LINES_OVERLAP       = 20;
const MAX_TOKENS_PER_CHUNK = 2000;
const TOKEN_CHAR_RATIO    = 4;
const DEBUG               = !!process.env.DEBUG;

// ── Helpers ───────────────────────────────────────────────────
function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

function uniqueDestPath(destDir, originalName) {
  const ext   = path.extname(originalName);
  const base  = path.basename(originalName, ext);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  return path.join(destDir, `${base}__${stamp}${ext}`);
}

function getMimeType(filePath) {
  const lower = filePath.toLowerCase();
  if (lower.endsWith('.pdf'))  return 'application/pdf';
  if (lower.endsWith('.docx')) return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
  if (lower.endsWith('.doc'))  return 'application/msword';
  if (lower.endsWith('.txt'))  return 'text/plain';
  if (lower.endsWith('.mp3'))  return 'audio/mpeg';
  if (lower.endsWith('.wav'))  return 'audio/wav';
  if (lower.endsWith('.m4a'))  return 'audio/mp4';
  if (lower.endsWith('.ogg'))  return 'audio/ogg';
  if (lower.endsWith('.flac')) return 'audio/flac';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.png'))  return 'image/png';
  if (lower.endsWith('.gif'))  return 'image/gif';
  return 'application/octet-stream';
}

function getAppUserFolder(baseKey, userId) {
  const basePath = app.getPath(baseKey);
  const target   = path.join(basePath, 'Kin-Keepers', 'Family-Circle', `my-data-${userId}`);
  ensureDir(target);
  return target;
}

function chunkByLines(text, linesPerChunk = LINES_PER_CHUNK, overlap = LINES_OVERLAP) {
  const lines  = String(text || '').split(/\r?\n/);
  const chunks = [];
  for (let i = 0; i < lines.length; i += (linesPerChunk - overlap)) {
    const part = lines.slice(i, i + linesPerChunk).join('\n');
    if (part.trim()) chunks.push(part);
  }
  return chunks;
}

function splitDocumentIntoCharChunks(text, maxTokens = MAX_TOKENS_PER_CHUNK, ratio = TOKEN_CHAR_RATIO) {
  const maxChars = maxTokens * ratio;
  const chunks   = [];
  let start = 0;
  while (start < text.length) {
    let end = start + maxChars;
    if (end >= text.length) end = text.length;
    else {
      const lastSpace = text.lastIndexOf(' ', end);
      if (lastSpace > start) end = lastSpace;
    }
    chunks.push(text.slice(start, end));
    start = end;
  }
  return chunks;
}

function cosineSimilarity(a, b) {
  const dot  = a.reduce((sum, ai, i) => sum + ai * b[i], 0);
  const magA = Math.sqrt(a.reduce((sum, ai) => sum + ai * ai, 0)) || 1;
  const magB = Math.sqrt(b.reduce((sum, bi) => sum + bi * bi, 0)) || 1;
  return dot / (magA * magB);
}

function safeMsg(e) {
  if (e?.response?.data) try { return JSON.stringify(e.response.data); } catch (_) {}
  return e?.message || String(e);
}

function normalizeTopic(s) {
  if (!s) return null;
  let t = String(s).trim();
  t = t.replace(/^\s*(topic:|main topic:)\s*/i, '').trim();
  t = t.replace(/[\s\.\!\?]+$/, '').trim();
  t = t.replace(/\s+/g, ' ').slice(0, 120);
  if (t) t = t.charAt(0).toUpperCase() + t.slice(1);
  return t || null;
}

// ── Resolve endpoints ─────────────────────────────────────────
function resolveEndpoints(mode) {
  const offline = mode === 'offline';
  return {
    slmUrl:    offline ? SLM_URL_OFFLINE    : SLM_URL_ONLINE,
    ollamaUrl: offline ? OLLAMA_URL_OFFLINE : OLLAMA_URL_ONLINE,
    isOffline: offline,
  };
}

// ── Embed (handles both Ollama format and llama-server format) ─
async function embedOne(ollamaUrl, text, isOffline = false) {
  if (isOffline) {
    // llama-server /embedding on port 8081
    const { data } = await axios.post(
      `${ollamaUrl}/embedding`,
      { content: `search_document: ${String(text || '')}` },
      { timeout: 30000 }
    );
    let vec = null;
    if (Array.isArray(data) && data[0]?.embedding) {
      vec = data[0].embedding;
      if (Array.isArray(vec[0])) vec = vec[0];
    } else if (data?.embedding) {
      vec = data.embedding;
      if (Array.isArray(vec[0])) vec = vec[0];
    } else if (Array.isArray(data) && typeof data[0] === 'number') {
      vec = data;
    }
    if (!Array.isArray(vec) || !vec.length) throw new Error('Embedding returned empty vector');
    return vec;
  }

  // Ollama format (online)
  const { data } = await axios.post(
    `${ollamaUrl}/api/embeddings`,
    { model: OLLAMA_EMBED_MODEL, prompt: String(text || '') },
    { timeout: 300000 }
  );
  const vec = data?.embedding || data?.data || data?.vector || [];
  if (!Array.isArray(vec) || !vec.length) throw new Error('Embedding returned empty vector');
  if (vec.length !== EMBEDDING_DIM)
    throw new Error(`Embedding dimension mismatch: expected ${EMBEDDING_DIM}, got ${vec.length}`);
  return vec;
}

// ── Granite call (handles online Ollama + offline llama-server) ─
function genOptions() {
  return {
    max_tokens:  150,
    temperature: 0.0,
    top_k:       40,
    top_p:       0.95,
    options: {
      num_predict:       512,
      temperature:       0.2,
      top_p:             0.9,
      repeat_penalty:    1.25,
      presence_penalty:  0.2,
      frequency_penalty: 0.2,
      stop: ['\n\nCONTEXT:', '\n\nQUESTION:', '\n\nAnswer:', '\n\nContext:'],
    },
  };
}

async function askGranite(slmUrl, prompt, { timeout = 600000, isOffline = false } = {}) {
  if (isOffline) {
    // llama-server /v1/chat/completions
    const body = {
      messages: [
        { role: 'system', content: 'You are a document assistant. Be concise.' },
        { role: 'user',   content: prompt },
      ],
      max_tokens: 150, temperature: 0.0, top_k: 40, top_p: 0.95,
      stream: false,
      stop: ['<|end_of_text|>', '<|start_of_role|>'],
    };
    const { data } = await axios.post(slmUrl, body, { timeout });
    return data?.choices?.[0]?.message?.content?.trim() || '';
  }

  // Ollama /api/generate
  const body = { model: SLM_MODEL, prompt, stream: false, ...genOptions() };
  const { data } = await axios.post(slmUrl, body, { timeout });
  if (data && typeof data === 'object' && typeof data.response === 'string')
    return data.response.trim();
  if (typeof data === 'string') {
    let answer = '';
    for (const ln of data.split('\n')) {
      try { const o = JSON.parse(ln); if (o.response) answer += o.response; if (o.done) break; } catch (_) {}
    }
    if (answer) return answer.trim();
  }
  return String(data || '');
}

// ── Topic generation ──────────────────────────────────────────
async function generateTopicForRecord(recordId, userId, { slmUrl, ollamaUrl, isOffline }) {
  try {
    const row  = await getAsync(
      `SELECT extracted_text, file_name FROM records WHERE id = ? AND user_id = ?`,
      [recordId, userId]
    );
    const text = (row?.extracted_text || '').trim();
    if (!text) return null;

    let chunks = chunkByLines(text, LINES_PER_CHUNK, LINES_OVERLAP);
    if (!chunks.length) chunks = splitDocumentIntoCharChunks(text, MAX_TOKENS_PER_CHUNK);

    const chunkEmbeddings = [];
    for (let i = 0; i < chunks.length; i++) {
      try   { chunkEmbeddings.push({ index: i, emb: await embedOne(ollamaUrl, chunks[i], isOffline) }); }
      catch (e) {
        if (DEBUG) console.warn(`Embedding chunk ${i} failed:`, safeMsg(e));
        chunkEmbeddings.push({ index: i, emb: null });
      }
    }

    const question = 'What is the main topic of this document?';
    let qEmb = null;
    try { qEmb = await embedOne(ollamaUrl, question, isOffline); }
    catch (e) { if (DEBUG) console.warn('Embedding question failed:', safeMsg(e)); }

    let autoAnswer = null;
    if (qEmb) {
      const scored = chunkEmbeddings
        .filter(c => c.emb)
        .map(c => ({ index: c.index, score: cosineSimilarity(qEmb, c.emb) }))
        .sort((a, b) => b.score - a.score);
      if (scored.length) {
        const top     = scored.slice(0, 2).map(s => chunks[s.index]);
        const context = top.join('\n---\n');
        const prompt  = `Answer the question using ONLY this context:\n${context}\n\nQuestion: ${question}\n\nAnswer:`;
        try { autoAnswer = (await askGranite(slmUrl, prompt, { isOffline })).trim(); }
        catch (e) { if (DEBUG) console.warn('Granite topic call failed:', safeMsg(e)); }
      }
    }

    let topic = normalizeTopic(autoAnswer);

    if (!topic) {
      const excerpt = text.slice(0, 6000);
      const prompt2 = `From the document excerpt below, produce a short, human-friendly topic (max ~7 words). Respond with just the topic.\n\n=== DOCUMENT EXCERPT ===\n${excerpt}\n\n=== END ===\n\nTopic:`;
      try { topic = normalizeTopic(await askGranite(slmUrl, prompt2, { isOffline })); }
      catch (e) { if (DEBUG) console.warn('Fallback topic failed:', safeMsg(e)); }
    }

    if (topic) await runAsync(
      `UPDATE records SET topic = ? WHERE user_id = ? AND id = ?`,
      [topic, userId, recordId]
    );

    return topic;
  } catch (e) {
    if (DEBUG) console.warn('generateTopicForRecord error:', safeMsg(e));
    return null;
  }
}

// ══════════════════════════════════════════════════════════════
// IPC: upload:files
// Sends progress events back to the renderer so the UI can
// show each stage rather than a single "Uploading..." spinner.
// ══════════════════════════════════════════════════════════════
ipcMain.handle('upload:files', async (event, { docPath, photoPaths, musicPaths, token, mode }) => {

  // Helper — send progress to renderer
  const progress = (stage, message, pct) => {
    try {
      event.sender.send('upload:progress', { stage, message, pct });
    } catch (_) {}
  };

  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };
  const userId = decoded.userId;

  const { slmUrl, ollamaUrl, isOffline } = resolveEndpoints(mode || 'online');

  try {
    let savedDocPath    = null;
    let originalDocName = null;
    let recordId        = null;

    // ── Stage 1: Save file to disk ─────────────────────────────
    if (docPath && fs.existsSync(docPath)) {
      progress('uploading', '⬆ Uploading file', 15);

      const userDocsFolder = getAppUserFolder('documents', userId);
      originalDocName      = path.basename(docPath);

      try {
        const existing = await getAsync(
          `SELECT id, file_path FROM records
            WHERE user_id = ? AND LOWER(file_name) = LOWER(?)
            ORDER BY uploaded_at DESC, id DESC LIMIT 1`,
          [userId, originalDocName]
        );
        if (existing) {
          if (existing.file_path && fs.existsSync(existing.file_path)) {
            try { fs.unlinkSync(existing.file_path); } catch (_) {}
          }
          await runAsync(`DELETE FROM records WHERE id = ? AND user_id = ?`, [existing.id, userId]);
        }
      } catch (e) { console.warn('⚠️ Error checking existing record:', e.message); }

      const destDocPath = uniqueDestPath(userDocsFolder, originalDocName);
      fs.copyFileSync(docPath, destDocPath);
      savedDocPath = destDocPath;

      // ── Stage 2: Extract text ───────────────────────────────
      progress('extracting', '📄 Upload done — extracting document text…', 45);

      recordId = await extractFamilyDataFromFile(destDocPath, getMimeType(destDocPath), userId);

      await runAsync(
        `UPDATE records SET file_name = ?, uploaded_at = COALESCE(uploaded_at, CURRENT_TIMESTAMP) WHERE user_id = ? AND id = ?`,
        [originalDocName, userId, recordId]
      );
    }

    // ── Photos ─────────────────────────────────────────────────
    if (Array.isArray(photoPaths)) {
      const userPicsFolder = getAppUserFolder('pictures', userId);
      for (const photo of photoPaths) {
        if (!photo || !fs.existsSync(photo)) continue;
        fs.copyFileSync(photo, uniqueDestPath(userPicsFolder, path.basename(photo)));
      }
    }

    // ── Music ──────────────────────────────────────────────────
    if (Array.isArray(musicPaths)) {
      const userMusicFolder = getAppUserFolder('music', userId);
      for (const music of musicPaths) {
        if (!music || !fs.existsSync(music)) continue;
        fs.copyFileSync(music, uniqueDestPath(userMusicFolder, path.basename(music)));
      }
    }

    if (!savedDocPath && !(photoPaths?.length) && !(musicPaths?.length)) {
      return { success: false, error: 'No files selected.' };
    }

    // ── Stage 3: Generate topic ────────────────────────────────
    let topicNormalized = null;
    if (recordId) {
      progress('topic', '🧠 Analysing document with AI…', 70);
      topicNormalized = await generateTopicForRecord(recordId, userId, { slmUrl, ollamaUrl, isOffline });
    }

    // ── Stage 4: Done ──────────────────────────────────────────
    progress('done', '✅ Upload and processing complete!', 100);

    return {
      success: true,
      data: {
        docSavedTo: savedDocPath,
        fileName:   originalDocName,
        recordId,
        topic:      topicNormalized,
      },
    };
  } catch (err) {
    progress('error', `❌ ${err.message || 'Upload failed'}`, 0);
    console.error('❌ Upload failed:', err);
    return { success: false, error: err.message || 'Upload failed' };
  }
});

// ── Photos listing ────────────────────────────────────────────
ipcMain.handle('photos:get-all', async (_event, token) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };
  try {
    const userPicsFolder = getAppUserFolder('pictures', decoded.userId);
    const files  = fs.existsSync(userPicsFolder) ? fs.readdirSync(userPicsFolder) : [];
    const photos = files.filter(f => /\.(jpg|jpeg|png|gif)$/i.test(f)).map(f => path.join(userPicsFolder, f));
    return { success: true, data: photos };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ── Music listing ─────────────────────────────────────────────
ipcMain.handle('music:get-all', async (_event, token) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };
  try {
    const userMusicFolder = getAppUserFolder('music', decoded.userId);
    const files  = fs.existsSync(userMusicFolder) ? fs.readdirSync(userMusicFolder) : [];
    const tracks = files.filter(f => /\.(mp3|wav|m4a|ogg|flac)$/i.test(f)).map(f => path.join(userMusicFolder, f));
    return { success: true, data: tracks };
  } catch (err) {
    return { success: false, error: err.message };
  }
});