// app/ipc/askOnHandler.js
//
// Exports `streamOnline(event, payload)` — called by the stream router in
// ipcMainHandlers.js.  Everything else is unchanged.
//
const { ipcMain } = require('electron');
const { allAsync } = require('../database/db');
const axios = require('axios');
const { decodeToken } = require('../model/userModel');

// ── Config (hosted server) ───────────────────────────────────────────────────
const SLM_URL            = process.env.SLM_URL             || 'http://208.109.228.76:11435/api/generate';
const SLM_MODEL          = process.env.SLM_MODEL            || 'granite3.2:2b';
const OLLAMA_URL         = process.env.OLLAMA_URL           || 'http://208.109.228.76:11435';
const OLLAMA_EMBED_MODEL  = process.env.OLLAMA_EMBED_MODEL  || 'all-minilm';
const EMBEDDING_DIM       = Number(process.env.EMBEDDING_DIM || 384);

const DEBUG                = true;
const MAX_TOKENS_PER_CHUNK = 2000;
const TOKEN_CHAR_RATIO     = 4;

// ── Utils ────────────────────────────────────────────────────────────────────
function safeMsg(e) {
  if (e?.response?.data) try { return JSON.stringify(e.response.data); } catch (_) {}
  return e?.message || String(e);
}

async function fetchScopedText(userId, scope) {
  const type = scope?.type || 'all';

  if (type === 'latest') {
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text FROM records
        WHERE user_id = ? ORDER BY datetime(uploaded_at) DESC, id DESC LIMIT 1`,
      [userId]
    );
    const r = rows?.[0];
    if (!r?.extracted_text) return '';
    return `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text}\n`;
  }

  if (type === 'current') {
    const currentId = Number(scope?.id);
    if (!Number.isInteger(currentId)) return '';
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text FROM records WHERE user_id = ? AND id = ? LIMIT 1`,
      [userId, currentId]
    );
    const r = rows?.[0];
    if (!r?.extracted_text) return '';
    return `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text}\n`;
  }

  if (type === 'ids') {
    const cleanIds = Array.isArray(scope?.ids) ? scope.ids.map(Number).filter(Number.isInteger) : [];
    if (!cleanIds.length) return '';
    const placeholders = cleanIds.map(() => '?').join(',');
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text FROM records
        WHERE id IN (${placeholders}) AND user_id = ? ORDER BY id DESC`,
      [...cleanIds, userId]
    );
    if (!rows?.length) return '';
    return rows.map(r => `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text || ''}\n`)
               .join('\n-------------------------\n');
  }

  // default: all
  const rows = await allAsync(
    `SELECT id, file_name, extracted_text FROM records WHERE user_id = ? ORDER BY id DESC`,
    [userId]
  );
  if (!rows?.length) return '';
  return rows.map(r => `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text || ''}\n`)
             .join('\n-------------------------\n');
}

function splitDocumentIntoChunks(text, maxTokensPerChunk = MAX_TOKENS_PER_CHUNK, ratio = TOKEN_CHAR_RATIO) {
  const maxChars = maxTokensPerChunk * ratio;
  const chunks = [];
  let start = 0;
  while (start < text.length) {
    let end = start + maxChars;
    if (end >= text.length) end = text.length;
    else {
      const lastSpace = text.lastIndexOf(' ', end);
      if (lastSpace > start) end = lastSpace;
    }
    chunks.push(text.slice(start, end));
    start = end;
  }
  return chunks;
}

function cosineSimilarity(a, b) {
  const dot  = a.reduce((sum, ai, i) => sum + ai * b[i], 0);
  const magA = Math.sqrt(a.reduce((sum, ai) => sum + ai * ai, 0)) || 1;
  const magB = Math.sqrt(b.reduce((sum, bi) => sum + bi * bi, 0)) || 1;
  return dot / (magA * magB);
}

function extractGraniteStreamedAnswer(rawData) {
  if (!rawData || typeof rawData !== 'string') return 'Document ready for questioning.';
  const lines = rawData.trim().split('\n');
  let answer = '';
  for (const line of lines) {
    try { const obj = JSON.parse(line); if (obj.response) answer += obj.response; if (obj.done) break; }
    catch (_) {}
  }
  return answer.trim() || 'Document ready for questioning.';
}

function genOptions() {
  return {
    max_tokens: 512,
    temperature: 0.2,
    top_p: 0.9,
    options: {
      num_predict: 512,
      temperature: 0.2,
      top_p: 0.9,
      repeat_penalty: 1.25,
      presence_penalty: 0.2,
      frequency_penalty: 0.2,
      stop: ['\n\nCONTEXT:', '\n\nQUESTION:', '\n\nAnswer:', '\n\nContext:'],
    },
  };
}

async function askGranite(prompt, { stream = false, timeout = 600000 } = {}) {
  const body = { model: SLM_MODEL, prompt, stream, ...genOptions() };

  if (stream) {
    return axios.post(SLM_URL, body, { responseType: 'stream', timeout });
  }

  const { data } = await axios.post(SLM_URL, body, { timeout });
  if (DEBUG) console.log('Granite online non-stream:', typeof data === 'string' ? data.slice(0, 200) : data);

  if (data && typeof data === 'object') {
    if (typeof data.response === 'string') return data.response.trim();
    if (typeof data.data === 'string') return extractGraniteStreamedAnswer(data.data);
    return 'No response field in Granite reply.';
  }
  if (typeof data === 'string') return extractGraniteStreamedAnswer(data);
  return 'No usable response from Granite.';
}

async function embedOne(text) {
  const { data } = await axios.post(
    `${OLLAMA_URL}/api/embeddings`,
    { model: OLLAMA_EMBED_MODEL, prompt: String(text || '') },
    { timeout: 300000 }
  );
  const vec = data?.embedding || data?.data || data?.vector || [];
  if (!Array.isArray(vec) || !vec.length) throw new Error('Embedding returned empty vector');
  if (vec.length !== EMBEDDING_DIM) throw new Error(`Embedding dimension mismatch: expected ${EMBEDDING_DIM}, got ${vec.length}`);
  return vec;
}

// ── Category ─────────────────────────────────────────────────────────────────
function categoryPrompt(category) {
  switch ((category || '').toLowerCase()) {
    case 'medical':       return 'Extract medical information: conditions, allergies, medications, and any hospitalizations.';
    case 'profile':       return "Summarize the person's profile including full name, DOB, location, occupation, and education.";
    case 'timeline':      return 'List important life events in chronological order with approximate dates.';
    case 'relationships': return "Describe the person's family and social relationships including parents, spouse, children, siblings.";
    case 'family-tree':
    case 'family_tree':   return 'Generate a family tree in the form A —[relationship]→ B.';
    default:              return 'Answer the question based on the document text.';
  }
}

ipcMain.handle('ask:on:category', async (_event, { category, token, scope }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  try {
    const mergedText = await fetchScopedText(decoded.userId, scope);
    if (!mergedText.trim()) return { success: false, error: 'No document text found' };
    const instructions = `Your task is to: ${categoryPrompt(category)}\nProvide only the answer itself. Be concise.`;
    const answer = await askGranite(`Use the following document text to answer.\n\n${mergedText}\n\nInstruction: ${instructions}\nAnswer:`);
    return { success: true, answer };
  } catch (err) {
    console.error('SLM (online) category error:', err.message);
    return { success: false, error: 'Failed to contact Granite API.' };
  }
});

// ── Non-streaming Q&A ─────────────────────────────────────────────────────────
ipcMain.handle('ask:on:question', async (_event, { question, token, scope, topK = 4 }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  try {
    const mergedText = await fetchScopedText(decoded.userId, scope);
    if (!mergedText.trim()) return { success: true, answer: 'No document text found.' };

    const chunks = splitDocumentIntoChunks(mergedText);
    const chunkEmbeddings = [];
    for (const c of chunks) {
      try { chunkEmbeddings.push(await embedOne(c)); }
      catch (e) { console.warn('Embedding chunk failed:', e.message); chunkEmbeddings.push(null); }
    }

    const qEmb = await embedOne(question);
    const scored = [];
    for (let i = 0; i < chunks.length; i++) {
      if (!chunkEmbeddings[i]) continue;
      scored.push({ index: i, score: cosineSimilarity(qEmb, chunkEmbeddings[i]) });
    }
    if (!scored.length) return { success: true, answer: 'No relevant context found.' };

    scored.sort((a, b) => b.score - a.score);
    const top     = scored.slice(0, topK).map(s => chunks[s.index]);
    const context = top.join('\n---\n');
    const answer  = await askGranite(
      `Answer the question using ONLY this context. Be concise.\n\nCONTEXT:\n${context}\n\nQUESTION: ${question}\n\nAnswer:`
    );
    return { success: true, answer, sources: top.map((c, i) => ({ chunkPreview: c.slice(0, 240), score: scored[i]?.score })) };
  } catch (err) {
    console.error('SLM (online) Q&A error:', safeMsg(err));
    return { success: false, error: safeMsg(err) };
  }
});

// ── Streaming Q&A — exported, called by stream router in ipcMainHandlers.js ──
async function streamOnline(event, { question, token, scope, topK = 4 }) {
  const decoded = decodeToken(token);
  if (!decoded?.userId) {
    event.sender.send('ask:on:question:stream:error', 'Not authenticated');
    return;
  }

  const send  = data => event.sender.send('ask:on:question:stream:chunk', JSON.stringify(data));
  const error = msg  => event.sender.send('ask:on:question:stream:error', msg);

  try {
    const mergedText = await fetchScopedText(decoded.userId, scope);
    if (!mergedText.trim()) {
      send({ type: 'token', response: 'No document text found.' });
      send({ type: 'done' });
      return;
    }

    const chunks = splitDocumentIntoChunks(mergedText);
    const chunkEmbeddings = [];
    for (const c of chunks) {
      try { chunkEmbeddings.push(await embedOne(c)); }
      catch (e) { console.warn('Embedding chunk failed:', e.message); chunkEmbeddings.push(null); }
    }

    const qEmb = await embedOne(question);
    const scored = [];
    for (let i = 0; i < chunks.length; i++) {
      if (!chunkEmbeddings[i]) continue;
      scored.push({ index: i, score: cosineSimilarity(qEmb, chunkEmbeddings[i]) });
    }

    if (!scored.length) {
      send({ type: 'token', response: 'No relevant context found.' });
      send({ type: 'done' });
      return;
    }

    scored.sort((a, b) => b.score - a.score);
    const topIndices = scored.slice(0, topK).map(s => s.index);
    const docs  = topIndices.map(i => chunks[i]);
    const metas = topIndices.map((i, idx) => ({
      chunk:   i,
      preview: (chunks[i] || '').slice(0, 220),
      score:   scored[idx].score,
    }));

    send({ type: 'sources', sources: metas });

    const body = {
      model:  SLM_MODEL,
      prompt: `Answer the question using ONLY this context. Be concise.\n\nCONTEXT:\n${docs.join('\n---\n')}\n\nQUESTION: ${question}\n\nAnswer:`,
      stream: true,
      ...genOptions(),
    };

    const resp = await axios.post(SLM_URL, body, { responseType: 'stream', timeout: 0 });
    let buffer = '';

    resp.data.on('data', chunk => {
      buffer += chunk.toString('utf-8');
      const lines = buffer.split('\n');
      buffer = lines.pop();
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        try {
          const obj = JSON.parse(trimmed);
          if (obj.response) send({ type: 'token', response: obj.response });
          if (obj.done)     send({ type: 'done' });
        } catch (e) { console.warn('Parse online stream chunk:', e.message); }
      }
    });

    resp.data.on('end', () => {
      const leftover = buffer.trim();
      if (leftover) {
        try {
          const obj = JSON.parse(leftover);
          if (obj.response) send({ type: 'token', response: obj.response });
        } catch (_) {}
      }
      send({ type: 'done' });
    });

    resp.data.on('error', e => error(e.message || 'Stream error'));

  } catch (e) {
    error(safeMsg(e));
  }
}

module.exports = { streamOnline };
