// app/ipc/ipcMainHandlers.js

const { ipcMain } = require('electron');
const path        = require('path');
const fs          = require('fs');
const { app }     = require('electron');
const bcrypt      = require('bcrypt');
const userModel   = require('../model/userModel');
const { getAsync, runAsync } = require('../database/db');

// ── llama-server (replaces ollamaProcess) ─────────────────────
const { ensureStarted, stop: stopOllama } = require('./llamaProcess');

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'your-very-secure-secret';
const P2P_SERVER = process.env.P2P_SERVER || 'http://localhost:5020';

// ── Helpers ───────────────────────────────────────────────────
function issueToken(userId, email) {
  return jwt.sign({ userId, email }, JWT_SECRET, { expiresIn: '30d' });
}

async function postJSON(url, body) {
  const res = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
    signal:  AbortSignal.timeout(12_000),
  });
  let data = null;
  try { data = await res.json(); } catch (_) {}
  return data ?? {};
}

async function fetchJSON(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(12_000) });
  if (!res.ok) throw new Error(`Server returned ${res.status}`);
  return res.json();
}

async function ensureInviteColumns() {
  const cols = [
    `ALTER TABLE users ADD COLUMN server_user_id TEXT`,
    `ALTER TABLE users ADD COLUMN profile_photo_url TEXT`,
    `ALTER TABLE users ADD COLUMN claimed_at INTEGER`,
  ];
  for (const sql of cols) {
    try { await runAsync(sql); } catch (_) {} // column already exists — safe to ignore
  }
}

// ── AUTH ──────────────────────────────────────────────────────

ipcMain.handle('auth:register', async (_event, { email, password }) => {
  try {
    await userModel.registerUser({ email, password });
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ─────────────────────────────────────────────────────────────
// auth:login
//
// Flow A — user already has a local account (registered or
//           previously claimed): validate password via bcrypt.
//
// Flow B — user has NO local account (first-time invited user):
//           1. Check server for their invite (pending OR accepted)
//           2. Verify the password they typed matches tempPassword
//           3. Create local SQLite account with that password
//           4. Return JWT so they are logged in immediately
// ─────────────────────────────────────────────────────────────
ipcMain.handle('auth:login', async (_event, { email, password }) => {
  const cleanEmail = String(email || '').trim().toLowerCase();

  // ── Flow A: local account exists ─────────────────────────
  try {
    const token = await userModel.validateLogin({ email: cleanEmail, password });
    await ensureStarted({ log: true });
    return { success: true, token };
  } catch (localErr) {

    const localUser = await getAsync(
      'SELECT id FROM users WHERE LOWER(email)=LOWER(?)', [cleanEmail]
    ).catch(() => null);

    if (localUser) {
      return { success: false, error: localErr.message || 'Incorrect password.' };
    }

    // ── Flow B: no local account — check server invite ────
    let serverData = null;
    try {
      serverData = await fetchJSON(
        `${P2P_SERVER}/api/invitation-check?email=${encodeURIComponent(cleanEmail)}`
      );
    } catch (_) {
      return {
        success: false,
        error:   'Account not found. If you were invited, please connect to the internet and try again.',
      };
    }

    if (!serverData?.hasPendingInvite) {
      return {
        success: false,
        error:   'No account found for this email. Please register or check your invitation email.',
      };
    }

    const tempPassword = serverData.tempPassword;
    if (!tempPassword) {
      return {
        success: false,
        error:   'Could not retrieve your invitation password. Please contact the group owner.',
      };
    }

    if (String(password).trim() !== String(tempPassword).trim()) {
      return {
        success: false,
        error:   'Incorrect password. Please use the password from your invitation email.',
      };
    }

    // ── Create local account ──────────────────────────────
    try {
      await ensureInviteColumns();

      let serverUserId   = serverData.serverId || null;
      let serverUserName = null;

      if (!serverUserId) {
        try {
          const regRes   = await postJSON(`${P2P_SERVER}/api/register`, { email: cleanEmail, name: cleanEmail });
          serverUserId   = regRes.user?.id   ?? null;
          serverUserName = regRes.user?.name ?? null;
        } catch (_) {}
      }

      if (serverData.token) {
        try { await postJSON(`${P2P_SERVER}/api/invitations/accept-link`, { token: serverData.token }); } catch (_) {}
      }

      const passwordHash = await bcrypt.hash(String(tempPassword).trim(), 10);

      const displayName = (serverUserName && serverUserName !== cleanEmail)
        ? serverUserName
        : cleanEmail.split('@')[0];

      await runAsync(
        `INSERT INTO users (email, password, name, server_user_id, claimed_at) VALUES (?, ?, ?, ?, ?)`,
        [cleanEmail, passwordHash, displayName, serverUserId ?? null, Date.now()]
      );

      if (serverUserId) {
        postJSON(`${P2P_SERVER}/api/user/mark-claimed`, { serverUserId, email: cleanEmail }).catch(() => {});
      }

      const newUser = await getAsync('SELECT * FROM users WHERE LOWER(email)=LOWER(?)', [cleanEmail]);
      if (!newUser) throw new Error('Failed to read back new local user');

      const jwtToken = issueToken(newUser.id, cleanEmail);
      await ensureStarted({ log: true });
      return { success: true, token: jwtToken };

    } catch (claimErr) {
      return { success: false, error: `Could not set up your account: ${claimErr.message}` };
    }
  }
});

ipcMain.handle('auth:decode-token', async (_event, token) => {
  try {
    const decoded = userModel.decodeToken(token);
    return decoded ? { success: true, data: decoded } : { success: false, error: 'Invalid token' };
  } catch {
    return { success: false, error: 'Invalid token' };
  }
});

ipcMain.handle('auth:get-current-user', async (_event, token) => {
  try {
    const user = await userModel.getCurrentUser(token);
    return user ? { success: true, data: user } : { success: false, error: 'Not authenticated' };
  } catch {
    return { success: false, error: 'Failed to get current user' };
  }
});

ipcMain.handle('auth:logout', async () => {
  await stopOllama({ log: true });
  return { success: true };
});

ipcMain.handle('auth:change-password', async (_event, { token, currentPassword, newPassword }) => {
  try {
    if (!token) return { success: false, error: 'Not authenticated' };
    const decoded = userModel.decodeToken(token);
    if (!decoded?.userId) return { success: false, error: 'Invalid session. Please log in again.' };
    await userModel.changePassword(decoded.userId, { currentPassword, newPassword });
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message || 'Failed to change password' };
  }
});

// ── PROFILE ───────────────────────────────────────────────────
function saveProfilePhotoToAppData(userId, sourcePath) {
  if (!sourcePath) return null;
  try {
    const imgDir = path.join(app.getPath('userData'), 'profile_photos');
    if (!fs.existsSync(imgDir)) fs.mkdirSync(imgDir, { recursive: true });
    const ext  = path.extname(sourcePath) || '.jpg';
    const dest = path.join(imgDir, `user_${userId}${ext}`);
    fs.copyFileSync(sourcePath, dest);
    return dest;
  } catch { return null; }
}

ipcMain.handle('auth:update-profile', async (_event, { token, profile }) => {
  try {
    const user = await userModel.getCurrentUser(token);
    if (!user) return { success: false, error: 'Not authenticated' };
    let profile_photo_path = user.profile_photo_path || null;
    if (profile?.photoPath) {
      const saved = saveProfilePhotoToAppData(user.id, profile.photoPath);
      if (saved) profile_photo_path = saved;
    }
    const fresh = await userModel.updateProfile(user.id, {
      email: profile?.email, name: profile?.name, phone: profile?.phone,
      age: profile?.age, dob: profile?.dob, gender: profile?.gender, profile_photo_path,
    });
    return { success: true, data: fresh };
  } catch {
    return { success: false, error: 'Failed to update profile' };
  }
});

// ── OTHER HANDLERS ────────────────────────────────────────────
require('./uploadHandler');
require('./recordsHandler');
require('./ollamaHandler');
require('./p2pFileSave');
require('./voiceElevenLabsHandlers');
require('./elevenLabsKeyHandlers');
require('./circlePhotosHandler');
require('./claimInvitationHandler');
require('./dbManager');

// ── Bio-Metrics handler ───────────────────────────────────────
// Registers three IPC channels:
//   biometrics:fetch-sledss      (fetch SLEDSS results from sledss.elderchatgpt.com)
//   biometrics:fetch-memory      (fetch Memory Test results from elderchatgpt.com/memorytest)
//   biometrics:upload-vault      (inject health data as a queryable Vault record)
require('./bioMetricsHandler');

// ── STREAM ROUTER ─────────────────────────────────────────────
const { streamOnline  } = require('./askOnHandler');
const { streamOffline } = require('./askOffHandler');

ipcMain.on('ask:on:question:stream', async (event, payload) => {
  const mode = payload?.mode || 'online';
  console.log(`[stream-router] mode=${mode} q="${(payload?.question || '').slice(0, 60)}"`);
  if (mode === 'offline') {
    await streamOffline(event, payload);
  } else {
    await streamOnline(event, payload);
  }
});