// app/ipc/bioMetricsDemoData.js
//
// Rich dummy bio-metrics data for testing LLM interpretation.
// Contains three patient profiles so you can test different risk levels.
// Switch the active profile by changing ACTIVE_PROFILE below.
//
//  'moderate'  — middle-aged patient with moderate disease + mild cognitive concerns
//  'high'      — elderly patient with high disease activity + moderate cognitive impairment
//  'low'       — younger patient in good health (control / baseline)

'use strict';

const ACTIVE_PROFILE = 'moderate';   // change to 'high' or 'low' to test different scenarios

// ════════════════════════════════════════════════════════════
// PROFILE: moderate
// 52-year-old woman, known SLE patient, early memory concerns
// ════════════════════════════════════════════════════════════
const PROFILE_MODERATE = {
  patient: {
    name:     'Sarah Nakato',
    age:      52,
    sex:      'Female',
    dob:      '1972-08-14',
    diagnosis: 'Systemic Lupus Erythematosus (SLE), diagnosed 2009',
    physician: 'Dr. James Okello, Rheumatology — Mulago National Referral Hospital',
    reportDate: '2025-04-18',
  },

  sledss: {
    score: 74,
    maxScore: 100,
    date: '2025-04-18',
    risk: 'moderate',
    riskLabel: 'Moderate Disease Activity',
    interpretation:
      'Score of 74/100 indicates moderate systemic lupus disease activity. ' +
      'The patient is experiencing a partial flare with elevation in several organ systems. ' +
      'Haematological involvement is notable. Immediate medication review is warranted.',
    domains: [
      {
        name: 'Constitutional',
        score: 14,
        max: 20,
        pct: 70,
        note: 'Fatigue reported daily, low-grade fever (37.8°C) on two occasions this month.',
      },
      {
        name: 'Musculoskeletal',
        score: 11,
        max: 20,
        pct: 55,
        note: 'Morning stiffness lasting >1 hour in wrists and MCP joints bilaterally. Mild synovitis confirmed on exam.',
      },
      {
        name: 'Cardiovascular / Vascular',
        score: 13,
        max: 20,
        pct: 65,
        note: 'Mild pericardial effusion noted on echo. Blood pressure controlled on amlodipine.',
      },
      {
        name: 'Renal',
        score: 18,
        max: 20,
        pct: 90,
        note: 'Urinalysis shows 2+ proteinuria. 24-hour urine protein 480 mg/day. Creatinine stable at 88 µmol/L.',
      },
      {
        name: 'Neurological / Neuropsychiatric',
        score: 10,
        max: 20,
        pct: 50,
        note: 'Headaches 3–4x/week, possible lupus cerebritis. No seizures. Mild cognitive fog reported by patient.',
      },
      {
        name: 'Haematological',
        score: 8,
        max: 20,
        pct: 40,
        note: 'Lymphopenia (0.8 × 10⁹/L). Mild thrombocytopenia (platelet count 118 × 10⁹/L). No active bleeding.',
      },
    ],
    labResults: {
      'Anti-dsDNA antibodies': '45 IU/mL (elevated; normal <10)',
      'Complement C3':         '0.58 g/L (low; normal 0.90–1.80)',
      'Complement C4':         '0.08 g/L (low; normal 0.16–0.47)',
      'ESR':                   '68 mm/hr (elevated)',
      'CRP':                   '18 mg/L (elevated)',
      'Haemoglobin':           '10.4 g/dL (mild anaemia)',
      'WBC':                   '3.2 × 10⁹/L (leukopenia)',
      'Platelets':             '118 × 10⁹/L (mild thrombocytopenia)',
      'Creatinine':            '88 µmol/L (normal)',
      'eGFR':                  '68 mL/min/1.73m² (mildly reduced)',
      'Urinalysis':            '2+ protein, microscopic haematuria',
    },
    currentMedications: [
      'Hydroxychloroquine 400 mg daily',
      'Prednisolone 10 mg daily (tapering)',
      'Amlodipine 5 mg daily',
      'Calcium + Vitamin D supplementation',
    ],
    clinicalNotes:
      'Patient presents for 3-monthly review. Reports increased fatigue and joint pain over the past 6 weeks, ' +
      'consistent with a moderate flare. Complement levels have dropped since last visit (C3 was 0.72 in January). ' +
      'Anti-dsDNA titre has doubled. Renal function remains near baseline but proteinuria is new — ' +
      'consider nephrology referral and possible repeat renal biopsy to rule out class III/IV nephritis. ' +
      'Plan: increase prednisolone to 20 mg, add mycophenolate mofetil 1g BD, ' +
      'and refer to nephrology. Follow up in 4 weeks. Warn patient about infection risk with immunosuppression.',
    nextAppointment: '2025-05-16',
  },

  memoryTest: {
    score: 22,
    maxScore: 30,
    date: '2025-04-20',
    testType: 'Montreal Cognitive Assessment (MoCA)',
    risk: 'mild',
    riskLabel: 'Mild Cognitive Impairment (MCI)',
    interpretation:
      'Score of 22/30 is below the normal threshold of 26. ' +
      'Findings are consistent with Mild Cognitive Impairment, possibly related to neuropsychiatric lupus, ' +
      'chronic pain burden, or medication side effects. ' +
      'Annual re-testing and neuropsychology referral recommended.',
    domains: [
      {
        name: 'Visuospatial / Executive',
        score: 3,
        max: 5,
        pct: 60,
        note: 'Clock drawing test mildly impaired — numbers crowded in right half. Trail-making task (B) completed with 2 errors.',
      },
      {
        name: 'Naming',
        score: 3,
        max: 3,
        pct: 100,
        note: 'All three animals correctly identified. Language naming intact.',
      },
      {
        name: 'Attention / Working Memory',
        score: 4,
        max: 6,
        pct: 67,
        note: 'Digit span forward intact (5 digits). Serial 7 subtraction: 3/5 correct. Attention lapses noted.',
      },
      {
        name: 'Language',
        score: 3,
        max: 3,
        pct: 100,
        note: 'Sentence repetition correct. Letter fluency (F words): 11 in 60 seconds — within normal limits.',
      },
      {
        name: 'Abstraction',
        score: 1,
        max: 2,
        pct: 50,
        note: 'One of two similarity questions correct (train/bicycle correct; watch/ruler incorrect).',
      },
      {
        name: 'Delayed Recall',
        score: 2,
        max: 5,
        pct: 40,
        note: 'Recalled 2/5 words after 5-minute delay. With category cuing: 4/5. Encoding rather than retrieval deficit suggested.',
      },
      {
        name: 'Orientation',
        score: 6,
        max: 6,
        pct: 100,
        note: 'Fully oriented to time, place, and person.',
      },
    ],
    riskFactors: [
      'Neuropsychiatric SLE (NPSLE) — lupus cerebritis possible',
      'Chronic fatigue and disrupted sleep reducing cognitive reserve',
      'Corticosteroid use (prednisolone) — associated with memory impairment',
      'Mild anaemia (Hb 10.4 g/dL) reducing cerebral oxygenation',
      'Reports of low mood and anxiety (PHQ-9 score: 11 — moderate depression)',
    ],
    recommendations: [
      {
        priority: 'High',
        category: 'Medical',
        action:   'Refer to neuropsychology for full cognitive battery to differentiate NPSLE from medication-related cognitive impairment.',
      },
      {
        priority: 'High',
        category: 'Medical',
        action:   'Consider MRI brain with FLAIR sequences to exclude lupus cerebritis or small vessel disease.',
      },
      {
        priority: 'Medium',
        category: 'Lifestyle',
        action:   'Structured aerobic exercise 150 min/week — proven to improve cognitive function in autoimmune patients.',
      },
      {
        priority: 'Medium',
        category: 'Lifestyle',
        action:   'Cognitive training: daily mental exercises (puzzles, memory games, new skill learning).',
      },
      {
        priority: 'Medium',
        category: 'Sleep',
        action:   'Sleep hygiene programme — target 7–9 hours. Treat pain at night to reduce sleep fragmentation.',
      },
      {
        priority: 'Low',
        category: 'Diet',
        action:   'Mediterranean dietary pattern — associated with 35% reduced dementia risk in longitudinal studies.',
      },
      {
        priority: 'Low',
        category: 'Mental health',
        action:   'Psychological support / CBT for mood symptoms (PHQ-9 = 11). Consider SSRI if mood does not improve.',
      },
    ],
    psychomotorScore: '6.2 seconds (Trail Making A — within normal limits)',
    administeredBy: 'Dr. Lydia Apio, Neurology Clinic',
  },

  combinedInsights: [
    'Moderate SLE flare is temporally associated with cognitive decline — neuropsychiatric lupus should be ruled out.',
    'Low complement C3/C4 and elevated anti-dsDNA correlate with both renal involvement and potential CNS inflammation.',
    'Delayed recall deficit (2/5 words) with good cueing suggests encoding problems, not retrieval — consistent with early hippocampal involvement rather than dementia.',
    'Haematological lupus (anaemia + leukopenia) may independently reduce cognitive performance via hypoxia.',
    'Prednisolone at 10 mg daily is a recognised risk factor for steroid-induced cognitive impairment; balance carefully against disease control.',
    'Increasing immunosuppression (planned MMF) may paradoxically improve cognition if NPSLE is the driver.',
  ],
};

// ════════════════════════════════════════════════════════════
// PROFILE: high
// 71-year-old man, longstanding SLE + moderate cognitive impairment
// ════════════════════════════════════════════════════════════
const PROFILE_HIGH = {
  patient: {
    name:     'Robert Ssekandi',
    age:      71,
    sex:      'Male',
    dob:      '1953-11-22',
    diagnosis: 'Systemic Lupus Erythematosus (SLE), diagnosed 1998; Hypertension; Type 2 Diabetes',
    physician: 'Dr. Grace Tumwine, Internal Medicine',
    reportDate: '2025-04-10',
  },

  sledss: {
    score: 88,
    maxScore: 100,
    date: '2025-04-10',
    risk: 'high',
    riskLabel: 'High Disease Activity',
    interpretation:
      'Score of 88/100 indicates high systemic lupus disease activity across multiple organ systems. ' +
      'The patient requires urgent medication escalation and close monitoring. ' +
      'Renal function is deteriorating. Hospitalisation may be required.',
    domains: [
      { name: 'Constitutional',          score: 17, max: 20, pct: 85, note: 'Significant fatigue, fever (38.4°C), 4 kg weight loss over 6 weeks.' },
      { name: 'Musculoskeletal',         score: 16, max: 20, pct: 80, note: 'Polyarthritis affecting knees, ankles, wrists. Reduced mobility — uses walking stick.' },
      { name: 'Cardiovascular / Vascular', score: 16, max: 20, pct: 80, note: 'Pleuritis confirmed on CXR. Moderate pericardial effusion. BP poorly controlled (158/96 mmHg).' },
      { name: 'Renal',                   score: 19, max: 20, pct: 95, note: 'Creatinine 198 µmol/L (baseline 120). Proteinuria 2.8 g/day. Active urinary sediment. Likely class IV nephritis.' },
      { name: 'Neurological',            score: 12, max: 20, pct: 60, note: 'Recent seizure episode (1st ever). EEG ordered. Confusion episodes at night.' },
      { name: 'Haematological',          score: 8,  max: 20, pct: 40, note: 'Hb 8.9 g/dL (haemolytic anaemia suspected — positive Coombs). Platelets 89 × 10⁹/L.' },
    ],
    labResults: {
      'Anti-dsDNA antibodies': '>200 IU/mL (markedly elevated)',
      'Complement C3':         '0.28 g/L (critically low)',
      'Complement C4':         '0.04 g/L (critically low)',
      'ESR':                   '112 mm/hr',
      'CRP':                   '54 mg/L',
      'Haemoglobin':           '8.9 g/dL',
      'Direct Coombs test':    'Positive',
      'Platelets':             '89 × 10⁹/L',
      'Creatinine':            '198 µmol/L (rising)',
      'eGFR':                  '31 mL/min/1.73m² (stage 3b CKD)',
      'Urinalysis':            '3+ protein, RBC casts, granular casts',
      'HbA1c':                 '8.2% (poorly controlled diabetes)',
    },
    currentMedications: [
      'Prednisolone 60 mg daily (recently escalated)',
      'Hydroxychloroquine 200 mg daily',
      'Metformin 500 mg BD',
      'Amlodipine 10 mg daily',
      'Ramipril 5 mg daily',
    ],
    clinicalNotes:
      'Patient admitted for urgent review. Severe flare with multi-organ involvement. ' +
      'Renal biopsy scheduled — creatinine has risen by 65% over 4 weeks. ' +
      'Haemolytic anaemia requires haematology review. First seizure this week — neurology consulted. ' +
      'Plan: IV methylprednisolone pulse × 3 days, start cyclophosphamide after infection screen. ' +
      'Nephrology and neurology co-management. Diabetic control must be reassessed given high-dose steroids.',
    nextAppointment: '2025-04-17 (inpatient review)',
  },

  memoryTest: {
    score: 16,
    maxScore: 30,
    date: '2025-04-11',
    testType: 'Montreal Cognitive Assessment (MoCA)',
    risk: 'moderate',
    riskLabel: 'Moderate Cognitive Impairment',
    interpretation:
      'Score of 16/30 indicates moderate cognitive impairment. ' +
      'Combined with acute lupus cerebritis (possible) and longstanding vascular risk factors, ' +
      'this warrants urgent neurology review and MRI brain.',
    domains: [
      { name: 'Visuospatial / Executive', score: 2, max: 5, pct: 40, note: 'Clock drawing significantly abnormal — numbers missing, hands incorrectly placed.' },
      { name: 'Naming',                   score: 2, max: 3, pct: 67, note: 'Failed to name rhinoceros. Named lion and camel correctly.' },
      { name: 'Attention / Working Memory', score: 2, max: 6, pct: 33, note: 'Serial 7s: 1/5 correct. Digit span: 3 forward, 2 backward. Significant attention impairment.' },
      { name: 'Language',                 score: 2, max: 3, pct: 67, note: 'One sentence repetition error. Letter fluency poor (only 6 F-words in 60 seconds).' },
      { name: 'Abstraction',              score: 0, max: 2, pct: 0,  note: 'Both similarity questions incorrect. Abstract reasoning significantly impaired.' },
      { name: 'Delayed Recall',           score: 1, max: 5, pct: 20, note: 'Recalled 1/5 words without cues; 2/5 with multiple-choice cuing. Significant memory deficit.' },
      { name: 'Orientation',              score: 5, max: 6, pct: 83, note: 'Incorrect date (gave 2 days ago). All other orientation items correct.' },
    ],
    riskFactors: [
      'Active lupus cerebritis (new seizure, MRI pending)',
      'Longstanding hypertension with likely cerebrovascular disease',
      'Type 2 diabetes — vascular dementia risk factor',
      'High-dose corticosteroid therapy',
      'Haemolytic anaemia — cerebral hypoperfusion',
      'Age 71 — baseline age-related cognitive vulnerability',
    ],
    recommendations: [
      { priority: 'Urgent', category: 'Medical',    action: 'MRI brain with contrast + FLAIR urgently — rule out lupus cerebritis and vascular lesions.' },
      { priority: 'Urgent', category: 'Medical',    action: 'Neurology review same admission for new-onset seizure.' },
      { priority: 'High',   category: 'Medical',    action: 'Control disease activity — cognitive impairment may partially reverse with lupus treatment.' },
      { priority: 'High',   category: 'Medical',    action: 'Optimise diabetes and blood pressure — key modifiable vascular risk factors.' },
      { priority: 'Medium', category: 'Carer support', action: 'Assess safety at home — is patient safe to live alone? Involve family in care planning.' },
      { priority: 'Medium', category: 'Lifestyle',  action: 'Supervised gentle physical activity when medically stable.' },
    ],
    administeredBy: 'Dr. Grace Tumwine',
  },

  combinedInsights: [
    'High-level disease activity (score 88/100) with new-onset seizure strongly suggests active neuropsychiatric SLE — urgent brain imaging required.',
    'Cognitive score of 16/30 in the context of acute multi-organ lupus flare may partially recover with aggressive immunosuppression.',
    'Critically low complement C3 (0.28 g/L) and anti-dsDNA >200 indicate severe immune complex deposition — renal and CNS involvement confirmed.',
    'Haemolytic anaemia (Hb 8.9 g/dL, positive Coombs) is directly reducing cerebral oxygenation and contributing to cognitive impairment.',
    'Diabetes (HbA1c 8.2%) and hypertension (BP 158/96) create a perfect storm for vascular cognitive impairment in addition to lupus-related CNS disease.',
    'Family members should be engaged immediately in care planning — patient may lack capacity for complex medical decisions during acute phase.',
  ],
};

// ════════════════════════════════════════════════════════════
// PROFILE: low
// 34-year-old woman, new SLE diagnosis, mild activity, normal cognition
// ════════════════════════════════════════════════════════════
const PROFILE_LOW = {
  patient: {
    name:     'Amara Birungi',
    age:      34,
    sex:      'Female',
    dob:      '1991-03-07',
    diagnosis: 'Systemic Lupus Erythematosus (SLE), newly diagnosed 2024',
    physician: 'Dr. Paul Mugisha, Rheumatology',
    reportDate: '2025-04-22',
  },

  sledss: {
    score: 28,
    maxScore: 100,
    date: '2025-04-22',
    risk: 'low',
    riskLabel: 'Low Disease Activity',
    interpretation:
      'Score of 28/100 indicates low disease activity, consistent with well-controlled SLE on current therapy. ' +
      'Patient is approaching clinical remission. Continue current management and 6-monthly monitoring.',
    domains: [
      { name: 'Constitutional',          score: 6,  max: 20, pct: 30, note: 'Mild fatigue on strenuous activity only. No fever.' },
      { name: 'Musculoskeletal',         score: 8,  max: 20, pct: 40, note: 'Occasional arthralgia in fingers after long typing sessions. No active synovitis on exam.' },
      { name: 'Cardiovascular / Vascular', score: 4, max: 20, pct: 20, note: 'No cardiorespiratory symptoms. BP 118/74 mmHg. Echo normal.' },
      { name: 'Renal',                   score: 4,  max: 20, pct: 20, note: 'Urinalysis normal. Creatinine 72 µmol/L (normal).' },
      { name: 'Neurological',            score: 3,  max: 20, pct: 15, note: 'Occasional mild headaches, likely tension-type. No neurological deficits.' },
      { name: 'Haematological',          score: 3,  max: 20, pct: 15, note: 'Haemoglobin 12.8 g/dL (mild). WBC and platelets normal.' },
    ],
    labResults: {
      'Anti-dsDNA antibodies': '8 IU/mL (normal <10)',
      'Complement C3':         '1.02 g/L (normal)',
      'Complement C4':         '0.21 g/L (normal)',
      'ESR':                   '18 mm/hr (normal)',
      'CRP':                   '<5 mg/L (normal)',
      'Haemoglobin':           '12.8 g/dL',
      'WBC':                   '5.8 × 10⁹/L (normal)',
      'Platelets':             '224 × 10⁹/L (normal)',
      'Creatinine':            '72 µmol/L (normal)',
      'eGFR':                  '>90 mL/min/1.73m² (normal)',
      'Urinalysis':            'Normal — no protein or blood',
    },
    currentMedications: [
      'Hydroxychloroquine 400 mg daily',
      'Folic acid 5 mg daily',
    ],
    clinicalNotes:
      'Excellent response to hydroxychloroquine since diagnosis in 2024. ' +
      'Anti-dsDNA has normalised and complement levels are within range. ' +
      'Patient is planning pregnancy — discussed implications of SLE and medications. ' +
      'Hydroxychloroquine is safe to continue. ' +
      'Will need pre-conception counselling and early rheumatology review once pregnant. ' +
      'Continue 6-monthly review. Consider reducing frequency to annual if remains in remission at next visit.',
    nextAppointment: '2025-10-22',
  },

  memoryTest: {
    score: 28,
    maxScore: 30,
    date: '2025-04-22',
    testType: 'Montreal Cognitive Assessment (MoCA)',
    risk: 'low',
    riskLabel: 'Normal Cognition',
    interpretation:
      'Score of 28/30 is within the normal range (≥26). ' +
      'No evidence of cognitive impairment. Consistent with her age and education level.',
    domains: [
      { name: 'Visuospatial / Executive', score: 5, max: 5, pct: 100, note: 'Clock drawing test perfect. Trail-making task error-free.' },
      { name: 'Naming',                   score: 3, max: 3, pct: 100, note: 'All animals named correctly and rapidly.' },
      { name: 'Attention / Working Memory', score: 5, max: 6, pct: 83, note: 'Serial 7s: 4/5. Digit span: 6 forward, 5 backward. One vigilance error (tapped on a letter that was not A).' },
      { name: 'Language',                 score: 3, max: 3, pct: 100, note: 'Both sentences repeated without error. Letter fluency excellent (18 F-words in 60 seconds).' },
      { name: 'Abstraction',              score: 2, max: 2, pct: 100, note: 'Both similarity questions correct.' },
      { name: 'Delayed Recall',           score: 4, max: 5, pct: 80, note: 'Recalled 4/5 words without cuing. One word retrieved with category cue.' },
      { name: 'Orientation',              score: 6, max: 6, pct: 100, note: 'Fully oriented to all dimensions.' },
    ],
    riskFactors: [
      'SLE diagnosis — small but real long-term cognitive risk',
      'Occasional disrupted sleep reported',
    ],
    recommendations: [
      { priority: 'Low', category: 'Monitoring',  action: 'Repeat cognitive screening annually as part of routine SLE follow-up.' },
      { priority: 'Low', category: 'Lifestyle',   action: 'Maintain current physical activity. Regular aerobic exercise is protective.' },
      { priority: 'Low', category: 'Sleep',        action: 'Address sleep disruption if it worsens — even mild sleep disturbance affects memory consolidation.' },
    ],
    administeredBy: 'Dr. Paul Mugisha',
  },

  combinedInsights: [
    'Well-controlled SLE with normal complement levels and normalised anti-dsDNA — excellent treatment response.',
    'Normal cognition (28/30) consistent with low disease burden and young age.',
    'Pre-pregnancy planning is the primary current clinical focus — SLE requires careful management during conception and pregnancy.',
    'Annual cognitive screening is appropriate given SLE diagnosis, even in low-activity disease.',
    'This profile represents a positive outcome — early diagnosis and hydroxychloroquine treatment achieved near-remission within 12 months.',
  ],
};

// ── Export active profile + all profiles ────────────────────
const PROFILES = {
  moderate: PROFILE_MODERATE,
  high:     PROFILE_HIGH,
  low:      PROFILE_LOW,
};

const ACTIVE_DATA = PROFILES[ACTIVE_PROFILE] || PROFILE_MODERATE;

// ── Build the vault text document from a profile ─────────────
function buildVaultText(profile) {
  const { patient, sledss, memoryTest, combinedInsights } = profile;

  let t = '';
  t += `BIO-METRICS HEALTH REPORT — Kin-Keepers Family Health Vault\n`;
  t += `Generated: ${new Date().toLocaleDateString('en-GB', { day:'numeric', month:'long', year:'numeric' })}\n`;
  t += `${'═'.repeat(60)}\n\n`;

  // Patient
  t += `PATIENT INFORMATION\n${'-'.repeat(40)}\n`;
  t += `Name:            ${patient.name}\n`;
  t += `Age:             ${patient.age} years\n`;
  t += `Sex:             ${patient.sex}\n`;
  t += `Date of Birth:   ${patient.dob}\n`;
  t += `Diagnosis:       ${patient.diagnosis}\n`;
  t += `Physician:       ${patient.physician}\n`;
  t += `Report Date:     ${patient.reportDate}\n\n`;

  // SLEDSS
  t += `SLEDSS ASSESSMENT — Systemic Lupus Disease Activity\n${'-'.repeat(40)}\n`;
  t += `Assessment Date: ${sledss.date}\n`;
  t += `Overall Score:   ${sledss.score} / ${sledss.maxScore}\n`;
  t += `Risk Level:      ${sledss.riskLabel}\n`;
  t += `\nInterpretation:\n${sledss.interpretation}\n\n`;

  t += `Domain Scores:\n`;
  sledss.domains.forEach(d => {
    t += `  ${d.name.padEnd(32)} ${String(d.score).padStart(3)} / ${d.max}  (${d.pct}%)\n`;
    t += `    Note: ${d.note}\n`;
  });

  t += `\nLaboratory Results:\n`;
  Object.entries(sledss.labResults).forEach(([k, v]) => {
    t += `  ${k.padEnd(30)} ${v}\n`;
  });

  t += `\nCurrent Medications:\n`;
  sledss.currentMedications.forEach(m => { t += `  - ${m}\n`; });

  t += `\nClinical Notes:\n${sledss.clinicalNotes}\n`;
  t += `Next Appointment: ${sledss.nextAppointment}\n\n`;

  // Memory Test
  t += `MEMORY TEST — ${memoryTest.testType}\n${'-'.repeat(40)}\n`;
  t += `Test Date:       ${memoryTest.date}\n`;
  t += `Overall Score:   ${memoryTest.score} / ${memoryTest.maxScore}\n`;
  t += `Risk Level:      ${memoryTest.riskLabel}\n`;
  t += `Administered By: ${memoryTest.administeredBy}\n`;
  t += `\nInterpretation:\n${memoryTest.interpretation}\n\n`;

  t += `Cognitive Domain Scores:\n`;
  memoryTest.domains.forEach(d => {
    t += `  ${d.name.padEnd(32)} ${String(d.score).padStart(2)} / ${d.max}  (${d.pct}%)\n`;
    t += `    Note: ${d.note}\n`;
  });

  if (memoryTest.riskFactors?.length) {
    t += `\nRisk Factors:\n`;
    memoryTest.riskFactors.forEach(r => { t += `  - ${r}\n`; });
  }

  t += `\nRecommendations:\n`;
  memoryTest.recommendations.forEach(r => {
    t += `  [${r.priority.toUpperCase()}] ${r.category}: ${r.action}\n`;
  });

  // Combined
  t += `\nCOMBINED CLINICAL INSIGHTS\n${'-'.repeat(40)}\n`;
  combinedInsights.forEach((ins, i) => { t += `${i + 1}. ${ins}\n`; });

  // Interpretation guide
  t += `\nINTERPRETATION REFERENCE\n${'-'.repeat(40)}\n`;
  t += `SLEDSS Scoring:\n`;
  t += `  0–30   Low disease activity — monitor every 6 months\n`;
  t += `  31–60  Mild disease activity — review medication\n`;
  t += `  61–80  Moderate disease activity — escalate treatment\n`;
  t += `  81–100 High disease activity — urgent intervention required\n\n`;
  t += `MoCA Scoring:\n`;
  t += `  26–30  Normal cognition\n`;
  t += `  18–25  Mild Cognitive Impairment (MCI)\n`;
  t += `  10–17  Moderate cognitive impairment\n`;
  t += `  0–9    Severe cognitive impairment\n\n`;
  t += `Note: Cognitive impairment in SLE may be reversible if due to active disease (NPSLE) — treating the lupus flare can improve cognition.\n`;

  return t;
}

module.exports = {
  PROFILES,
  ACTIVE_DATA,
  ACTIVE_PROFILE,
  buildVaultText,
};