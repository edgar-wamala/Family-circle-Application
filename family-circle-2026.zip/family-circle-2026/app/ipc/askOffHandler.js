// app/ipc/askOffHandler.js
// OFFLINE mode — now uses llama-server (llama.cpp) instead of local Ollama.
//
// Changed:
//   OLD: http://127.0.0.1:11434/api/generate       (Ollama LLM)
//   NEW: http://127.0.0.1:8080/v1/chat/completions (llama-server LLM)
//
//   OLD: http://127.0.0.1:11434/api/embeddings      (Ollama embed)
//   NEW: http://127.0.0.1:8081/embedding             (Nomic llama-server)
//
// Everything else — chunking, cosine search, streaming — unchanged.

const { ipcMain } = require('electron');
const { allAsync } = require('../database/db');
const axios = require('axios');
const { decodeToken } = require('../model/userModel');

// ── Local llama-server endpoints ──────────────────────────────
const LLM_URL    = 'http://127.0.0.1:8080';   // Granite answers
const EMBED_URL  = 'http://127.0.0.1:8081';   // Nomic embeddings

const MAX_TOKENS_PER_CHUNK = 2000;
const TOKEN_CHAR_RATIO     = 4;
const DEBUG                = true;

// ── Utils (same as askOnHandler) ──────────────────────────────
function safeMsg(e) {
  if (e?.response?.data) try { return JSON.stringify(e.response.data); } catch (_) {}
  return e?.message || String(e);
}

async function fetchScopedText(userId, scope) {
  const type = scope?.type || 'all';

  if (type === 'latest') {
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text FROM records
        WHERE user_id = ? ORDER BY datetime(uploaded_at) DESC, id DESC LIMIT 1`,
      [userId]
    );
    const r = rows?.[0];
    if (!r?.extracted_text) return '';
    return `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text}\n`;
  }

  if (type === 'current') {
    const currentId = Number(scope?.id);
    if (!Number.isInteger(currentId)) return '';
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text FROM records WHERE user_id = ? AND id = ? LIMIT 1`,
      [userId, currentId]
    );
    const r = rows?.[0];
    if (!r?.extracted_text) return '';
    return `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text}\n`;
  }

  if (type === 'ids') {
    const cleanIds = Array.isArray(scope?.ids) ? scope.ids.map(Number).filter(Number.isInteger) : [];
    if (!cleanIds.length) return '';
    const placeholders = cleanIds.map(() => '?').join(',');
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text FROM records
        WHERE id IN (${placeholders}) AND user_id = ? ORDER BY id DESC`,
      [...cleanIds, userId]
    );
    if (!rows?.length) return '';
    return rows.map(r => `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text || ''}\n`)
               .join('\n-------------------------\n');
  }

  // default: all
  const rows = await allAsync(
    `SELECT id, file_name, extracted_text FROM records WHERE user_id = ? ORDER BY id DESC`,
    [userId]
  );
  if (!rows?.length) return '';
  return rows.map(r => `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text || ''}\n`)
             .join('\n-------------------------\n');
}

function splitDocumentIntoChunks(text, maxTokensPerChunk = MAX_TOKENS_PER_CHUNK, ratio = TOKEN_CHAR_RATIO) {
  const maxChars = maxTokensPerChunk * ratio;
  const chunks   = [];
  let start = 0;
  while (start < text.length) {
    let end = start + maxChars;
    if (end >= text.length) end = text.length;
    else {
      const lastSpace = text.lastIndexOf(' ', end);
      if (lastSpace > start) end = lastSpace;
    }
    chunks.push(text.slice(start, end));
    start = end;
  }
  return chunks;
}

function cosineSimilarity(a, b) {
  const dot  = a.reduce((sum, ai, i) => sum + ai * b[i], 0);
  const magA = Math.sqrt(a.reduce((sum, ai) => sum + ai * ai, 0)) || 1;
  const magB = Math.sqrt(b.reduce((sum, bi) => sum + bi * bi, 0)) || 1;
  return dot / (magA * magB);
}

// ── Embed using Nomic llama-server ────────────────────────────
// Changed from Ollama /api/embeddings to llama-server /embedding
async function embedOne(text, isQuery = false) {
  const prefix  = isQuery ? 'search_query: ' : 'search_document: ';
  const content = prefix + String(text || '');

  const { data } = await axios.post(
    `${EMBED_URL}/embedding`,
    { content },
    { timeout: 30000 }
  );

  // llama-server returns different shapes depending on version
  let vec = null;
  if (Array.isArray(data) && data[0]?.embedding) {
    vec = data[0].embedding;
    if (Array.isArray(vec[0])) vec = vec[0];
  } else if (data?.embedding) {
    vec = data.embedding;
    if (Array.isArray(vec[0])) vec = vec[0];
  } else if (Array.isArray(data) && typeof data[0] === 'number') {
    vec = data;
  }

  if (!Array.isArray(vec) || !vec.length)
    throw new Error('Embedding returned empty vector from Nomic llama-server');

  return vec;
}

// ── LLM call using Granite llama-server ───────────────────────
// Changed from Ollama /api/generate to llama-server /v1/chat/completions
// top_k and top_p values confirmed working from test_granite.js
function genOptions() {
  return {
    max_tokens:  150,        // conservative for CPU — change to 512 if GPU
    temperature: 0.0,        // deterministic = fastest + most consistent
    top_k:       40,         // confirmed from test_granite.js
    top_p:       0.95,       // confirmed from test_granite.js
    stop:        ['<|end_of_text|>', '<|start_of_role|>'],
  };
}

async function askGraniteLocal(prompt, { stream = false, timeout = 120000 } = {}) {
  const messages = [
    { role: 'system', content: 'You are a document assistant. Answer questions using ONLY the provided document context. Be concise and direct.' },
    { role: 'user',   content: prompt },
  ];

  const body = { messages, stream, ...genOptions() };

  if (stream) {
    return axios.post(`${LLM_URL}/v1/chat/completions`, body, { responseType: 'stream', timeout });
  }

  const { data } = await axios.post(`${LLM_URL}/v1/chat/completions`, body, { timeout });
  return data?.choices?.[0]?.message?.content?.trim() || 'No response from local Granite.';
}

// ── Category handler (offline) ────────────────────────────────
ipcMain.handle('ask:off:category', async (_event, { category, token, scope }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  try {
    const mergedText = await fetchScopedText(decoded.userId, scope);
    if (!mergedText.trim()) return { success: false, error: 'No document text found' };

    const prompt = `Answer the question using ONLY this document text.\n\n${mergedText}\n\nInstruction: ${category}\nAnswer:`;
    const answer = await askGraniteLocal(prompt);
    return { success: true, answer };
  } catch (err) {
    console.error('askOff category error:', err.message);
    return { success: false, error: safeMsg(err) };
  }
});

// ── Non-streaming Q&A (offline) ───────────────────────────────
ipcMain.handle('ask:off:question', async (_event, { question, token, scope, topK = 4 }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  try {
    const mergedText = await fetchScopedText(decoded.userId, scope);
    if (!mergedText.trim()) return { success: true, answer: 'No document text found.' };

    const chunks          = splitDocumentIntoChunks(mergedText);
    const chunkEmbeddings = [];

    for (const c of chunks) {
      try   { chunkEmbeddings.push(await embedOne(c, false)); }
      catch (e) { console.warn('Chunk embed failed:', e.message); chunkEmbeddings.push(null); }
    }

    const qEmb   = await embedOne(question, true);
    const scored = [];
    for (let i = 0; i < chunks.length; i++) {
      if (!chunkEmbeddings[i]) continue;
      scored.push({ index: i, score: cosineSimilarity(qEmb, chunkEmbeddings[i]) });
    }
    if (!scored.length) return { success: true, answer: 'No relevant context found.' };

    scored.sort((a, b) => b.score - a.score);
    const top     = scored.slice(0, topK).map(s => chunks[s.index]);
    const context = top.join('\n---\n');
    const answer  = await askGraniteLocal(
      `Answer the question using ONLY this context. Be concise.\n\nCONTEXT:\n${context}\n\nQUESTION: ${question}\n\nAnswer:`
    );
    return { success: true, answer };
  } catch (err) {
    console.error('askOff question error:', safeMsg(err));
    return { success: false, error: safeMsg(err) };
  }
});

// ── Streaming Q&A (offline) ───────────────────────────────────
async function streamOffline(event, { question, token, scope, topK = 4 }) {
  const decoded = decodeToken(token);
  if (!decoded?.userId) {
    event.sender.send('ask:on:question:stream:error', 'Not authenticated');
    return;
  }

  const send  = data => event.sender.send('ask:on:question:stream:chunk', JSON.stringify(data));
  const error = msg  => event.sender.send('ask:on:question:stream:error', msg);

  try {
    const mergedText = await fetchScopedText(decoded.userId, scope);
    if (!mergedText.trim()) {
      send({ type: 'token', response: 'No document text found.' });
      send({ type: 'done' });
      return;
    }

    const chunks          = splitDocumentIntoChunks(mergedText);
    const chunkEmbeddings = [];

    for (const c of chunks) {
      try   { chunkEmbeddings.push(await embedOne(c, false)); }
      catch (e) { console.warn('Chunk embed failed:', e.message); chunkEmbeddings.push(null); }
    }

    const qEmb   = await embedOne(question, true);
    const scored = [];
    for (let i = 0; i < chunks.length; i++) {
      if (!chunkEmbeddings[i]) continue;
      scored.push({ index: i, score: cosineSimilarity(qEmb, chunkEmbeddings[i]) });
    }

    if (!scored.length) {
      send({ type: 'token', response: 'No relevant context found.' });
      send({ type: 'done' });
      return;
    }

    scored.sort((a, b) => b.score - a.score);
    const topIndices = scored.slice(0, topK).map(s => s.index);
    const docs       = topIndices.map(i => chunks[i]);
    const metas      = topIndices.map((i, idx) => ({
      chunk:   i,
      preview: (chunks[i] || '').slice(0, 220),
      score:   scored[idx].score,
    }));

    send({ type: 'sources', sources: metas });

    // Stream from llama-server /v1/chat/completions
    const body = {
      messages: [
        { role: 'system', content: 'You are a document assistant. Answer questions using ONLY the provided document context. Be concise and direct.' },
        { role: 'user',   content: `Answer the question using ONLY this context. Be concise.\n\nCONTEXT:\n${docs.join('\n---\n')}\n\nQUESTION: ${question}\n\nAnswer:` },
      ],
      ...genOptions(),
      stream: true,
    };

    const resp = await axios.post(
      `${LLM_URL}/v1/chat/completions`,
      body,
      { responseType: 'stream', timeout: 0 }
    );

    let buffer = '';

    resp.data.on('data', chunk => {
      buffer += chunk.toString('utf-8');
      const lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || !trimmed.startsWith('data: ')) continue;
        const jsonStr = trimmed.slice(6).trim();
        if (jsonStr === '[DONE]') continue;
        try {
          const obj    = JSON.parse(jsonStr);
          const token  = obj.choices?.[0]?.delta?.content;
          if (token)                              send({ type: 'token', response: token });
          if (obj.choices?.[0]?.finish_reason)   send({ type: 'done' });
        } catch (e) {
          console.warn('[streamOffline] parse error:', e.message);
        }
      }
    });

    resp.data.on('end', () => {
      if (buffer.trim()) {
        try {
          const jsonStr = buffer.trim().startsWith('data: ') ? buffer.trim().slice(6) : buffer.trim();
          const obj     = JSON.parse(jsonStr);
          const token   = obj.choices?.[0]?.delta?.content;
          if (token) send({ type: 'token', response: token });
        } catch (_) {}
      }
      send({ type: 'done' });
    });

    resp.data.on('error', e => error(e.message || 'Stream error'));

  } catch (e) {
    error(safeMsg(e));
  }
}

module.exports = { streamOffline };