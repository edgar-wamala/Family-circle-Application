// app/ipc/dbManager.js
// ─────────────────────────────────────────────────────────────
// Handles:
//   1. On launch:    detect existing DB, ask user what to do
//   2. On uninstall: ask user whether to delete DB
//   3. Backup DB     → saves timestamped copy
//   4. Restore DB    → restores from a backup file
//   5. List backups  → returns all backup files
// ─────────────────────────────────────────────────────────────

const { ipcMain, dialog, app } = require('electron');
const path = require('path');
const fs   = require('fs');
const {
  openDatabase,
  databaseExists,
  deleteDatabase,
  backupDatabase,
  restoreDatabase,
  listBackups,
  dbPath,
  backupDir,
} = require('../database/db');

// ══════════════════════════════════════════════════════════════
// STARTUP CHECK
// Call this from main.js BEFORE creating the window.
// Shows a native dialog if an existing database is found.
// ══════════════════════════════════════════════════════════════
async function handleStartupDatabaseCheck() {
  const flagPath = path.join(app.getPath('userData'), '.db-setup-done');

  // ── Development mode (npm start) ─────────────────────────────
  // Skip the dialog entirely — just open or create the DB silently.
  // The dialog is only meant for end users installing the packaged app.
  if (!app.isPackaged) {
    openDatabase();
    console.log('[dbManager] Development mode — DB opened silently, no dialog shown.');
    return { action: 'dev' };
  }

  if (!databaseExists()) {
    // Fresh install — create DB and write the flag so we never ask again
    openDatabase();
    fs.writeFileSync(flagPath, '1');
    console.log('[dbManager] Fresh install — new database created.');
    return { action: 'new' };
  }

  // DB exists AND flag exists — user already made their choice, just open
  if (fs.existsSync(flagPath)) {
    openDatabase();
    console.log('[dbManager] Existing database — skipping dialog (already set up).');
    return { action: 'existing' };
  }

  // DB exists but flag missing — first launch after install with old data
  // Show the dialog ONCE, then write the flag so it never shows again
  console.log('[dbManager] Existing database found at:', dbPath);

  const { response } = await dialog.showMessageBox({
    type:      'question',
    title:     'Existing Data Found',
    message:   'Family Circle data from a previous installation was found on this device.',
    detail:    'Would you like to continue with your existing data, or start fresh?\n\nStarting fresh will permanently delete all your previous records.',
    buttons:   ['Use Existing Data', 'Start Fresh (Delete Old Data)', 'Cancel'],
    defaultId: 0,
    cancelId:  2,
    noLink:    true,
  });

  if (response === 0) {
    // Use existing
    openDatabase();
    fs.writeFileSync(flagPath, '1');
    console.log('[dbManager] Using existing database.');
    return { action: 'existing' };
  }

  if (response === 1) {
    // Confirm delete
    const { response: confirm } = await dialog.showMessageBox({
      type:      'warning',
      title:     'Confirm: Delete All Data',
      message:   'Are you sure you want to delete all existing data?',
      detail:    'This cannot be undone. All your documents, records, and settings will be permanently removed.',
      buttons:   ['Yes, Delete Everything', 'No, Keep My Data'],
      defaultId: 1,
      cancelId:  1,
    });

    if (confirm === 0) {
      // Offer to back up first
      const { response: wantBackup } = await dialog.showMessageBox({
        type:      'question',
        title:     'Back Up Before Deleting?',
        message:   'Would you like to save a backup of your data before deleting?',
        buttons:   ['Yes, Save a Backup First', 'No, Delete Without Backup'],
        defaultId: 0,
      });

      if (wantBackup === 0) {
        try {
          const dest = await dialog.showSaveDialog({
            title:       'Save Backup As',
            defaultPath: path.join(app.getPath('desktop'), 'family-circle-backup.db'),
            filters:     [{ name: 'Database Backup', extensions: ['db'] }],
          });
          if (!dest.canceled && dest.filePath) {
            fs.copyFileSync(dbPath, dest.filePath);
            await dialog.showMessageBox({
              type:    'info',
              title:   'Backup Saved',
              message: 'Backup saved successfully.',
              detail:  `Location: ${dest.filePath}`,
              buttons: ['OK'],
            });
          }
        } catch (e) {
          console.warn('[dbManager] Backup before delete failed:', e.message);
        }
      }

      deleteDatabase();
      openDatabase();
      fs.writeFileSync(flagPath, '1');
      console.log('[dbManager] Old database deleted — fresh start.');
      return { action: 'deleted' };
    }

    // Changed mind — keep existing
    openDatabase();
    fs.writeFileSync(flagPath, '1');
    return { action: 'existing' };
  }

  // Cancel
  openDatabase();
  fs.writeFileSync(flagPath, '1');
  return { action: 'existing' };
}

// ══════════════════════════════════════════════════════════════
// UNINSTALL CHECK
// Call this when the app detects it is being uninstalled.
// Or expose via ipcMain so the uninstaller can trigger it.
// ══════════════════════════════════════════════════════════════
async function handleUninstallDatabaseCheck() {
  if (!databaseExists()) return;

  const { response } = await dialog.showMessageBox({
    type:      'question',
    title:     'Uninstalling Family Circle',
    message:   'What would you like to do with your data?',
    detail:    'Your documents and records are stored locally on this device.\n\nKeeping your data means you can use it if you reinstall the app later.',
    buttons:   ['Keep My Data', 'Delete Everything'],
    defaultId: 0,
    noLink:    true,
  });

  if (response === 1) {
    const { response: wantBackup } = await dialog.showMessageBox({
      type:      'question',
      title:     'Save a Backup First?',
      message:   'Would you like to save a backup before deleting?',
      buttons:   ['Yes, Save Backup', 'No, Just Delete'],
      defaultId: 0,
    });

    if (wantBackup === 0) {
      try {
        const dest = await dialog.showSaveDialog({
          title:       'Save Final Backup',
          defaultPath: path.join(app.getPath('desktop'), 'family-circle-final-backup.db'),
          filters:     [{ name: 'Database Backup', extensions: ['db'] }],
        });
        if (!dest.canceled && dest.filePath) {
          fs.copyFileSync(dbPath, dest.filePath);
        }
      } catch (e) {
        console.warn('[dbManager] Final backup failed:', e.message);
      }
    }

    deleteDatabase();
    console.log('[dbManager] Database deleted on uninstall.');
  } else {
    console.log('[dbManager] User kept database on uninstall.');
  }
}

// ══════════════════════════════════════════════════════════════
// IPC HANDLERS — called from renderer (settings/profile page)
// ══════════════════════════════════════════════════════════════

// Quick backup — auto-named, saved to backups folder
ipcMain.handle('db:backup', async () => {
  try {
    const dest = backupDatabase();
    return { success: true, path: dest, name: path.basename(dest) };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// Backup to a user-chosen location
ipcMain.handle('db:backup-to', async () => {
  try {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const dest  = await dialog.showSaveDialog({
      title:       'Save Database Backup',
      defaultPath: path.join(app.getPath('desktop'), `family-circle-backup-${stamp}.db`),
      filters:     [{ name: 'Database Backup', extensions: ['db'] }],
    });
    if (dest.canceled || !dest.filePath) return { success: false, error: 'Cancelled' };
    backupDatabase(dest.filePath);
    return { success: true, path: dest.filePath };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// Restore from a file the user picks via file dialog
ipcMain.handle('db:restore', async () => {
  try {
    const result = await dialog.showOpenDialog({
      title:      'Select Backup File to Restore',
      filters:    [{ name: 'Database Backup', extensions: ['db'] }],
      properties: ['openFile'],
    });
    if (result.canceled || !result.filePaths.length)
      return { success: false, error: 'Cancelled' };

    const chosen = result.filePaths[0];

    const { response } = await dialog.showMessageBox({
      type:      'warning',
      title:     'Confirm Restore',
      message:   'This will replace your current database with the selected backup.',
      detail:    `Backup: ${path.basename(chosen)}\n\nA backup of your current data will be saved automatically before restoring.`,
      buttons:   ['Restore', 'Cancel'],
      defaultId: 1,
    });
    if (response !== 0) return { success: false, error: 'Cancelled' };

    // Auto-backup current data before restore
    try { backupDatabase(); } catch (_) {}

    restoreDatabase(chosen);
    return { success: true, message: 'Database restored successfully. Please restart the app.' };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// Restore from one of the listed automatic backups
ipcMain.handle('db:restore-from-list', async (_event, backupFilePath) => {
  try {
    if (!fs.existsSync(backupFilePath))
      return { success: false, error: 'Backup file not found' };

    const { response } = await dialog.showMessageBox({
      type:      'warning',
      title:     'Confirm Restore',
      message:   'Restore this backup?',
      detail:    `File: ${path.basename(backupFilePath)}\n\nYour current data will be backed up automatically before restoring.`,
      buttons:   ['Restore', 'Cancel'],
      defaultId: 1,
    });
    if (response !== 0) return { success: false, error: 'Cancelled' };

    try { backupDatabase(); } catch (_) {}
    restoreDatabase(backupFilePath);
    return { success: true, message: 'Restored successfully. Please restart the app.' };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// List all automatic backups
ipcMain.handle('db:list-backups', async () => {
  try {
    return { success: true, data: listBackups() };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// Delete a specific backup file
ipcMain.handle('db:delete-backup', async (_event, backupFilePath) => {
  try {
    if (!fs.existsSync(backupFilePath))
      return { success: false, error: 'File not found' };
    fs.unlinkSync(backupFilePath);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// Get database info
ipcMain.handle('db:info', async () => {
  try {
    const exists  = databaseExists();
    const size    = exists ? fs.statSync(dbPath).size : 0;
    const backups = listBackups();
    return {
      success: true,
      data: {
        path:         dbPath,
        backupDir,
        exists,
        sizeBytes:    size,
        sizeKB:       Math.round(size / 1024),
        backupCount:  backups.length,
        latestBackup: backups[0] || null,
      },
    };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// Open the folder containing the database in File Explorer
ipcMain.handle('db:open-folder', async () => {
  const { shell } = require('electron');
  try {
    shell.showItemInFolder(dbPath);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

module.exports = { handleStartupDatabaseCheck, handleUninstallDatabaseCheck };