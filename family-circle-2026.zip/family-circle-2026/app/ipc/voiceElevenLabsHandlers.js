// app/ipc/voiceElevenLabsHandlers.js
const { ipcMain } = require("electron");
const fs = require("fs");
const os = require("os");
const path = require("path");

// Optional secure store (recommended)
let secureStore = null;
try {
  secureStore = require("./secureStore"); // must be CommonJS
} catch (_) {
  secureStore = null;
}

function guessExtFromMime(mimeType = "") {
  const m = String(mimeType || "").toLowerCase();
  if (m.includes("wav")) return ".wav";
  if (m.includes("mpeg") || m.includes("mp3")) return ".mp3";
  if (m.includes("ogg")) return ".ogg";
  if (m.includes("webm")) return ".webm";
  return ".webm";
}

function getElevenLabsApiKey() {
  const HARD_CODED_KEY = "sk_7032db81238a9462a102db3d07d03512537b425d78fd4ffa";

  const fromStore =
    secureStore?.get?.("elevenlabsApiKey") ||
    secureStore?.get?.("elevenlabs_api_key");

  const fromEnv = process.env.ELEVENLABS_API_KEY;

  return String(fromStore || fromEnv || HARD_CODED_KEY || "").trim();
}


function getVoiceId() {
  return String(process.env.ELEVENLABS_VOICE_ID || "EXAVITQu4vr4xnSDxMaL").trim();
}

function getTtsModelId() {
  return String(process.env.ELEVENLABS_TTS_MODEL || "eleven_multilingual_v2").trim();
}

// =======================
// STT: ElevenLabs Speech-to-Text (Scribe v2)
// =======================
ipcMain.handle("stt:elevenlabs", async (_e, { audio, mimeType }) => {
  try {
    const apiKey = getElevenLabsApiKey();
    if (!apiKey) return { success: false, error: "Missing ElevenLabs API key (env or secureStore)." };
    if (!audio || !audio.length) return { success: false, error: "No audio received." };

    const ext = guessExtFromMime(mimeType);
    const tmpPath = path.join(os.tmpdir(), `fc-voice-${Date.now()}${ext}`);
    fs.writeFileSync(tmpPath, Buffer.from(audio));

    const form = new FormData();
    const fileBlob = new Blob([fs.readFileSync(tmpPath)], { type: mimeType || "application/octet-stream" });
    form.append("file", fileBlob, path.basename(tmpPath));
    form.append("model_id", "scribe_v2");

    const r = await fetch("https://api.elevenlabs.io/v1/speech-to-text", {
      method: "POST",
      headers: { "xi-api-key": apiKey },
      body: form,
    });

    try { fs.unlinkSync(tmpPath); } catch (_) {}

    if (!r.ok) {
      const errText = await r.text().catch(() => "");
      return { success: false, error: `STT HTTP ${r.status}: ${errText}` };
    }

    const data = await r.json().catch(() => ({}));
    return { success: true, text: data?.text || "" };
  } catch (err) {
    return { success: false, error: err?.message || String(err) };
  }
});

// =======================
// TTS: ElevenLabs Text-to-Speech
// =======================
ipcMain.handle("tts:elevenlabs", async (_e, { text }) => {
  try {
    const apiKey = getElevenLabsApiKey();
    if (!apiKey) return { success: false, error: "Missing ElevenLabs API key (env or secureStore)." };

    const voiceId = getVoiceId();
    const modelId = getTtsModelId();

    const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: "POST",
      headers: {
        "xi-api-key": apiKey,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg",
      },
      body: JSON.stringify({
        text: String(text || ""),
        model_id: modelId,
        voice_settings: { stability: 0.5, similarity_boost: 0.75 },
      }),
    });

    if (!r.ok) {
      const errText = await r.text().catch(() => "");
      return { success: false, error: `TTS HTTP ${r.status}: ${errText}` };
    }

    const buf = Buffer.from(await r.arrayBuffer());
    return { success: true, audioBase64: buf.toString("base64"), mimeType: "audio/mpeg" };
  } catch (err) {
    return { success: false, error: err?.message || String(err) };
  }
});
