// app/ipc/llamaProcess.js
// ─────────────────────────────────────────────────────────────
// Starts llama-server.exe automatically when the Electron app launches.
// Both servers start once and stay running until the app closes.
//
// Folder structure expected:
//   family-desktop-app\
//     bin\
//       llama-b8772-bin-win-cpu-x64\   ← whole folder copied here
//         llama-server.exe
//         ggml.dll
//         llama.dll
//         ... all other .dll files
//     models\
//       granite-4.0-h-1b-Q4_K_M.gguf
//       nomic-embed-text-v1.5.Q4_K_M.gguf
//
// Commands being run (same as your manual start):
//   llama-server.exe --model granite-4.0-h-1b-Q4_K_M.gguf
//     --ctx-size 1024 --port 8080 --threads 4
//
//   llama-server.exe --model nomic-embed-text-v1.5.Q4_K_M.gguf
//     --ctx-size 512 --port 8081 --threads 4
//     --embeddings --pooling mean
// ─────────────────────────────────────────────────────────────

const { spawn, execSync } = require('child_process');
const path   = require('path');
const http   = require('http');
const os     = require('os');

// ── Resolve base path ─────────────────────────────────────────
// Packaged app  → process.resourcesPath
// Development   → two levels up from app/ipc/ = project root
function getBasePath() {
  try {
    const { app } = require('electron');
    if (app.isPackaged) return process.resourcesPath;
  } catch (_) {}
  return path.join(__dirname, '..', '..');
}

const BASE = getBasePath();

// ── The llama folder that contains server.exe AND all .dll files ──
// cwd MUST be this folder so Windows finds the .dll files
const LLAMA_DIR  = path.join(BASE, 'bin', 'llama-b8772-bin-win-cpu-x64');
const SERVER_EXE = path.join(LLAMA_DIR, 'llama-server.exe');

// ── Model paths ───────────────────────────────────────────────
const MODEL_DIR = path.join(BASE, 'models');
const LLM_MODEL = path.join(MODEL_DIR, 'granite-4.0-h-1b-Q4_K_M.gguf');
const EMB_MODEL = path.join(MODEL_DIR, 'nomic-embed-text-v1.5.Q4_K_M.gguf');

// Public URLs used by askOffHandler and uploadHandler
const LLM_URL   = 'http://127.0.0.1:8080';
const EMBED_URL = 'http://127.0.0.1:8081';

// ── Hardware auto-detection ───────────────────────────────────
const CPU_CORES    = os.cpus().length;
const TOTAL_RAM_GB = os.totalmem() / 1024 ** 3;

function detectGPU() {
  try {
    const raw = execSync(
      'wmic path win32_VideoController get Name,AdapterRAM /format:csv',
      { timeout: 5000, encoding: 'utf8' }
    );
    for (const line of raw.split('\n').filter(l => l.trim() && !l.startsWith('Node'))) {
      const parts  = line.split(',');
      const vramGb = (parseInt(parts[1]) || 0) / 1024 ** 3;
      const name   = (parts[2] || '').trim();
      if (name.toLowerCase().includes('nvidia'))
        return { found: true, name, vramGb };
    }
  } catch (_) {}
  return { found: false, name: null, vramGb: 0 };
}

const GPU = detectGPU();

// Threads — use all logical CPU cores
const THREADS = CPU_CORES;

// GPU layers
function calcGpuLayers(gpu) {
  if (!gpu.found)       return 0;
  if (gpu.vramGb >= 6) return -1;  // full GPU offload
  if (gpu.vramGb >= 4) return 20;
  if (gpu.vramGb >= 2) return 10;
  return 0;
}
const GPU_LAYERS = calcGpuLayers(GPU);

console.log('\n[llamaProcess] ── Hardware detected ─────────────');
console.log(`[llamaProcess] CPU      : ${CPU_CORES} cores → --threads ${THREADS}`);
console.log(`[llamaProcess] RAM      : ${TOTAL_RAM_GB.toFixed(1)} GB`);
console.log(`[llamaProcess] GPU      : ${GPU.found ? `${GPU.name} (${GPU.vramGb.toFixed(1)}GB VRAM)` : 'none (CPU only)'}`);
if (GPU_LAYERS !== 0) console.log(`[llamaProcess] GPU layers: ${GPU_LAYERS === -1 ? 'all (full GPU)' : GPU_LAYERS}`);
console.log('[llamaProcess] ────────────────────────────────────\n');

// ── Process handles ───────────────────────────────────────────
let llmProc = null;
let embProc = null;

// ── Health check ──────────────────────────────────────────────
function ping(port) {
  return new Promise((resolve, reject) => {
    const req = http.get(
      { hostname: '127.0.0.1', port, path: '/health', timeout: 3000 },
      r => r.statusCode === 200 ? resolve() : reject(new Error(`HTTP ${r.statusCode}`))
    );
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

async function isHealthy() {
  try { await Promise.all([ping(8080), ping(8081)]); return true; }
  catch { return false; }
}

// ── Start one llama-server ─────────────────────────────────────
// cwd = LLAMA_DIR so all .dll files are found automatically
function startServer(modelPath, port, extraArgs = []) {
  return new Promise((resolve, reject) => {

    const args = [
      '--model',   modelPath,
      '--port',    String(port),
      '--threads', String(THREADS),
      ...extraArgs,
    ];

    // Add GPU layers if GPU found (LLM server only)
    if (GPU_LAYERS !== 0 && !extraArgs.includes('--embeddings')) {
      args.push('--n-gpu-layers', String(GPU_LAYERS));
    }

    console.log(`[llamaProcess] Starting port ${port}...`);
    console.log(`[llamaProcess] Exe : ${SERVER_EXE}`);
    console.log(`[llamaProcess] Args: ${args.join(' ')}`);
    console.log(`[llamaProcess] cwd : ${LLAMA_DIR}`);

    const proc = spawn(SERVER_EXE, args, {
      cwd:   LLAMA_DIR,   // ← CRITICAL: must be the folder with .dll files
      stdio: 'ignore',    // suppress server logs in Electron console
      windowsHide: true,  // hide the console window on Windows
    });

    proc.on('error', err => {
      console.error(`[llamaProcess] Failed to start port ${port}:`, err.message);
      reject(err);
    });

    proc.on('exit', code => {
      if (code !== null)
        console.warn(`[llamaProcess] Server port ${port} exited (code ${code})`);
    });

    // Poll /health every 500ms until ready (max 60s)
    const started  = Date.now();
    const interval = setInterval(async () => {
      try {
        await ping(port);
        clearInterval(interval);
        console.log(`[llamaProcess] ✓ Server ready on port ${port}`);
        resolve(proc);
      } catch {
        if (Date.now() - started > 60000) {
          clearInterval(interval);
          proc.kill();
          reject(new Error(`Server port ${port} did not start within 60s`));
        }
      }
    }, 500);
  });
}

// ── Public API ─────────────────────────────────────────────────

// Called from ipcMainHandlers.js and main.js on app launch
// Starts BOTH servers — runs once, stays running until app closes
async function ensureStarted({ log = false } = {}) {
  try {
    // Check if already running (e.g. app restarted without closing)
    if (llmProc && embProc) {
      if (log) console.log('[llamaProcess] Both servers already running');
      return true;
    }

    // Start Granite LLM (port 8080)
    // Same as: .\llama-b8772-bin-win-cpu-x64\llama-server.exe
    //   --model .\granite-4.0-h-1b-Q4_K_M.gguf
    //   --ctx-size 1024 --port 8080 --threads 4
    if (!llmProc) {
      if (log) console.log('[llamaProcess] Starting Granite LLM server (port 8080)...');
      llmProc = await startServer(LLM_MODEL, 8080, [
        '--ctx-size', '1024',
      ]);
    }

    // Start Nomic embeddings (port 8081)
    // Same as: .\llama-b8772-bin-win-cpu-x64\llama-server.exe
    //   --model .\nomic-embed-text-v1.5.Q4_K_M.gguf
    //   --ctx-size 512 --port 8081 --threads 4
    //   --embeddings --pooling mean
    if (!embProc) {
      if (log) console.log('[llamaProcess] Starting Nomic embedding server (port 8081)...');
      embProc = await startServer(EMB_MODEL, 8081, [
        '--ctx-size',  '512',
        '--embeddings',
        '--pooling',   'mean',
      ]);
    }

    if (log) console.log('[llamaProcess] ✓ Both servers started and ready');
    return true;

  } catch (err) {
    console.error('[llamaProcess] ensureStarted failed:', err.message);
    console.error('[llamaProcess] Check that bin\\llama-b8772-bin-win-cpu-x64\\ exists');
    console.error('[llamaProcess] Check that models\\ contains the .gguf files');
    return false;
  }
}

// Called on app quit — stops both servers cleanly
function stop({ log = false } = {}) {
  if (llmProc) {
    try { llmProc.kill(); } catch (_) {}
    llmProc = null;
    if (log) console.log('[llamaProcess] Granite LLM stopped');
  }
  if (embProc) {
    try { embProc.kill(); } catch (_) {}
    embProc = null;
    if (log) console.log('[llamaProcess] Nomic embeddings stopped');
  }
}

function getState() {
  return {
    running:    !!llmProc && !!embProc,
    llmPid:     llmProc?.pid || null,
    embPid:     embProc?.pid || null,
    llmUrl:     LLM_URL,
    embedUrl:   EMBED_URL,
    OLLAMA_URL: LLM_URL,  // compatibility alias
  };
}

async function killAll({ log = false } = {}) {
  stop({ log });
  const stillReachable = await isHealthy();
  return { success: true, stillReachable };
}

module.exports = {
  ensureStarted,
  stop,
  killAll,
  getState,
  isHealthy,
  LLM_URL,
  EMBED_URL,
  OLLAMA_URL: LLM_URL,
};