// app/ipc/secureStore.js  (CommonJS)
const Store = require("electron-store");

// Uses OS keychain encryption automatically on Windows/macOS/Linux
const store = new Store({
  name: "family-circle-secrets",
});

module.exports = {
  get(key) {
    return store.get(key);
  },
  set(key, value) {
    store.set(key, value);
  },
  delete(key) {
    store.delete(key);
  },
};
