// login.js

// 🔐 Show / hide password logic on Login page
const passwordInput = document.getElementById('passwordInput');
const togglePasswordBtn = document.getElementById('togglePassword');

function togglePassword() {
  if (!passwordInput || !togglePasswordBtn) return;

  const isPassword = passwordInput.type === 'password';
  passwordInput.type = isPassword ? 'text' : 'password';

  // Change icon + accessibility label
  togglePasswordBtn.textContent = isPassword ? '🙈' : '👁️';
  togglePasswordBtn.setAttribute(
    'aria-label',
    isPassword ? 'Hide password' : 'Show password'
  );
}

if (passwordInput && togglePasswordBtn) {
  togglePasswordBtn.addEventListener('click', togglePassword);
  togglePasswordBtn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      togglePassword();
    }
  });
}

// Existing login logic
document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  const messageEl = document.getElementById('loginMessage');
  messageEl.textContent = ""; // Clear old message

  // NEW: read selected mode (online/offline) and store globally
  const selectedMode =
    document.querySelector('input[name="mode"]:checked')?.value || 'online';
  // Reuse qaModel as the global app mode key
  localStorage.setItem('qaModel', selectedMode);

  try {
    const res = await window.api.login(data);
    if (res?.token) {
      localStorage.setItem('token', res.token);
      window.api.navigateTo('index.html'); // Or your main page
    } else {
      messageEl.style.color = "red";
      messageEl.textContent = res.error || "Login failed";
    }
  } catch (err) {
    messageEl.style.color = "red";
    messageEl.textContent = "Error: " + err.message;
  }
});

document.getElementById('goToRegister').addEventListener('click', (e) => {
  e.preventDefault();
  window.api.navigateTo('register.html');
});
