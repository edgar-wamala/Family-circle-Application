// recordsHandler.js
const { ipcMain } = require('electron');
const { getAsync, allAsync, runAsync } = require('../database/db'); // <-- add runAsync
const { decodeToken } = require('../model/userModel');

// Helper: simple summary (first 200 characters)
function generateSummary(text) {
  if (!text || !text.trim()) return '';
  return text.length > 200 ? text.slice(0, 200) + '...' : text;
}

// -------------------------
// Get all records
// -------------------------
ipcMain.handle('records:get-all', async (_event, token) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  try {
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text, uploaded_at
       FROM records
       WHERE user_id = ?
       ORDER BY id DESC`,
      [decoded.userId]
    );

    const data = (rows || []).map(row => ({
      ...row,
      summary: generateSummary(row.extracted_text)
    }));

    return { success: true, data };
  } catch (err) {
    console.error('❌ Failed to fetch records:', err.message);
    return { success: false, error: 'Failed to fetch records' };
  }
});

// -------------------------
// Get one record by ID
// -------------------------
ipcMain.handle('records:get-one', async (_event, { id, token }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  try {
    const row = await getAsync(
      `SELECT id, file_name, extracted_text, uploaded_at
       FROM records
       WHERE id = ? AND user_id = ?`,
      [id, decoded.userId]
    );

    if (!row) return { success: false, error: 'Record not found' };

    return { success: true, data: { ...row, summary: generateSummary(row.extracted_text) } };
  } catch (err) {
    console.error('❌ Failed to fetch record by ID:', err.message);
    return { success: false, error: 'Failed to fetch record' };
  }
});

// -------------------------
// Delete one record by ID  ← NEW
// -------------------------
ipcMain.handle('records:delete', async (_event, { id, token }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  if (!id || isNaN(Number(id))) return { success: false, error: 'Invalid record id' };

  try {
    const info = await runAsync(
      `DELETE FROM records WHERE id = ? AND user_id = ?`,
      [id, decoded.userId]
    );
    if (info.changes > 0) {
      return { success: true };
    } else {
      return { success: false, error: 'Record not found' };
    }
  } catch (err) {
    console.error('❌ Failed to delete record:', err.message);
    return { success: false, error: 'Failed to delete record' };
  }
});

// -------------------------
// Bulk delete by IDs       ← NEW (optional helper)
// -------------------------
ipcMain.handle('records:delete-many', async (_event, { ids, token }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  if (!Array.isArray(ids) || ids.length === 0) {
    return { success: false, error: 'No record ids provided' };
  }
  const cleanIds = ids.map(Number).filter(n => Number.isInteger(n));
  if (cleanIds.length === 0) return { success: false, error: 'Invalid record ids' };

  const placeholders = cleanIds.map(() => '?').join(',');
  const params = [...cleanIds, decoded.userId];

  try {
    const info = await runAsync(
      `DELETE FROM records WHERE id IN (${placeholders}) AND user_id = ?`,
      params
    );
    return { success: true, deleted: info.changes || 0 };
  } catch (err) {
    console.error('❌ Failed bulk delete:', err.message);
    return { success: false, error: 'Failed to delete records' };
  }
});
