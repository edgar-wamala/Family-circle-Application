// --- app/ipc/uploadHandler.js ---
const { ipcMain, app } = require('electron');
const fs = require('fs');
const path = require('path');
const extractFamilyDataFromFile = require('../services/extract');
const { decodeToken } = require('../model/userModel');
const { runAsync, getAsync } = require('../database/db');

// -------- Embeddings + Chroma (lazy ESM imports so CJS stays working) --------
let _embedderPromise = null;
async function getEmbedder() {
  if (!_embedderPromise) {
    _embedderPromise = (async () => {
      const { pipeline } = await import('@xenova/transformers');
      return pipeline('feature-extraction', 'Xenova/all-MiniLM-L12-v2');
    })();
  }
  return _embedderPromise;
}

async function embedOne(text) {
  const embedder = await getEmbedder();
  const out = await embedder(text, { pooling: 'mean', normalize: true });
  return Array.from(out.data);
}

async function getChromaClient() {
  const { ChromaClient } = await import('chromadb');
  return new ChromaClient({
    host: '208.109.228.76',
    port: 8031,
    ssl: false,
  });
}

function chunkByLines(text, linesPerChunk = 120, overlap = 20) {
  const lines = String(text || '').split(/\r?\n/);
  const chunks = [];
  for (let i = 0; i < lines.length; i += (linesPerChunk - overlap)) {
    const part = lines.slice(i, i + linesPerChunk).join('\n');
    if (part.trim()) chunks.push(part);
  }
  return chunks;
}

// ----------------- Helpers -----------------
function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

function uniqueDestPath(destDir, originalName) {
  const ext = path.extname(originalName);
  const base = path.basename(originalName, ext);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  return path.join(destDir, `${base}__${stamp}${ext}`);
}

function getMimeType(filePath) {
  const lower = filePath.toLowerCase();
  if (lower.endsWith('.pdf')) return 'application/pdf';
  if (lower.endsWith('.docx')) return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
  if (lower.endsWith('.doc')) return 'application/msword';
  if (lower.endsWith('.txt')) return 'text/plain';
  // AUDIO
  if (lower.endsWith('.mp3')) return 'audio/mpeg';
  if (lower.endsWith('.wav')) return 'audio/wav';
  if (lower.endsWith('.m4a')) return 'audio/mp4';
  if (lower.endsWith('.ogg')) return 'audio/ogg';
  if (lower.endsWith('.flac')) return 'audio/flac';
  // IMAGES
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.gif')) return 'image/gif';
  return 'application/octet-stream';
}

function getAppUserFolder(baseKey, userId) {
  const basePath = app.getPath(baseKey); // 'documents', 'pictures', 'music'
  const target = path.join(basePath, 'Kin-Keepers', 'Family-Circle', `my-data-${userId}`);
  ensureDir(target);
  return target;
}

// ----------------- IPC: Upload -----------------
ipcMain.handle('upload:files', async (_event, { docPath, photoPaths, musicPaths, token }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };
  const userId = decoded.userId;

  try {
    let savedDocPath = null;
    let originalDocName = null;
    let recordId = null;

    // Documents
    if (docPath && fs.existsSync(docPath)) {
      const userDocsFolder = getAppUserFolder('documents', userId);
      originalDocName = path.basename(docPath);
      const destDocPath = uniqueDestPath(userDocsFolder, originalDocName);
      fs.copyFileSync(docPath, destDocPath);
      savedDocPath = destDocPath;

      // Extract to DB (returns inserted record id)
      recordId = await extractFamilyDataFromFile(destDocPath, getMimeType(destDocPath), userId);

      // Update filename + timestamp for that record
      await runAsync(
        `UPDATE records
           SET file_name = ?, uploaded_at = COALESCE(uploaded_at, CURRENT_TIMESTAMP)
         WHERE user_id = ? AND id = ?`,
        [originalDocName, userId, recordId]
      );

      // Index into Chroma for RAG (best-effort; failure does not abort upload)
      try {
        const row = await getAsync(
          `SELECT extracted_text FROM records WHERE id = ? AND user_id = ?`,
          [recordId, userId]
        );
        const text = row?.extracted_text || '';
        if (text.trim()) {
          const chunks = chunkByLines(text, 120, 20);
          const client = await getChromaClient();
          const collectionName = `user_${userId}_records`;
          const coll = await client.getOrCreateCollection({ name: collectionName, embeddingFunction: null });

          // prepare vectors + ids + metadata
          const ids = [];
          const embeddings = [];
          const metadatas = [];
          for (let i = 0; i < chunks.length; i++) {
            ids.push(`${collectionName}_${recordId}_chunk_${i}`);
            embeddings.push(await embedOne(chunks[i]));
            metadatas.push({
              user_id: userId,
              record_id: recordId,
              file_name: originalDocName,
              chunk: i
            });
          }
          await coll.add({ ids, embeddings, documents: chunks, metadatas });
        }
      } catch (e) {
        console.error('⚠️ Chroma indexing failed (continuing upload):', e.message);
      }
    }

    // Photos
    if (Array.isArray(photoPaths)) {
      const userPicsFolder = getAppUserFolder('pictures', userId);
      for (const photo of photoPaths) {
        if (!photo || !fs.existsSync(photo)) continue;
        const destPhotoPath = uniqueDestPath(userPicsFolder, path.basename(photo));
        fs.copyFileSync(photo, destPhotoPath);
      }
    }

    // Music
    if (Array.isArray(musicPaths)) {
      const userMusicFolder = getAppUserFolder('music', userId);
      for (const music of musicPaths) {
        if (!music || !fs.existsSync(music)) continue;
        const destMusicPath = uniqueDestPath(userMusicFolder, path.basename(music));
        fs.copyFileSync(music, destMusicPath);
      }
    }

    if (!savedDocPath && (!photoPaths?.length && !musicPaths?.length)) {
      return { success: false, error: 'No files selected.' };
    }

    return {
      success: true,
      data: { docSavedTo: savedDocPath, fileName: originalDocName, recordId }
    };
  } catch (err) {
    console.error('❌ Upload failed:', err);
    return { success: false, error: err.message || 'Upload failed' };
  }
});

// ----------------- IPC: Photos listing (existing) -----------------
ipcMain.handle('photos:get-all', async (_event, token) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };
  const userId = decoded.userId;

  try {
    const userPicsFolder = getAppUserFolder('pictures', userId);
    const files = fs.existsSync(userPicsFolder) ? fs.readdirSync(userPicsFolder) : [];
    const photos = files
      .filter(f => /\.(jpg|jpeg|png|gif)$/i.test(f))
      .map(f => path.join(userPicsFolder, f));
    return { success: true, data: photos };
  } catch (err) {
    console.error('❌ Failed to list photos:', err);
    return { success: false, error: err.message };
  }
});

// ----------------- IPC: Music listing (existing) -----------------
ipcMain.handle('music:get-all', async (_event, token) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };
  const userId = decoded.userId;

  try {
    const userMusicFolder = getAppUserFolder('music', userId);
    const files = fs.existsSync(userMusicFolder) ? fs.readdirSync(userMusicFolder) : [];
    const tracks = files
      .filter(f => /\.(mp3|wav|m4a|ogg|flac)$/i.test(f))
      .map(f => path.join(userMusicFolder, f));
    return { success: true, data: tracks };
  } catch (err) {
    console.error('❌ Failed to list music:', err);
    return { success: false, error: err.message };
  }
});
