// --- app/ipc/askOnHandler.js ---
const { ipcMain } = require('electron');
const { allAsync } = require('../database/db'); 
const axios = require('axios');
const { decodeToken } = require('../model/userModel');

const SLM_URL = 'http://208.109.228.76:11435/api/generate';
const SLM_MODEL = 'granite3.2:2b';
const DEBUG = true;
const MAX_TOKENS_PER_CHUNK = 2000;
const TOKEN_CHAR_RATIO = 4;

// ---------------- Embeddings + Chroma (lazy ESM imports) ----------------
let _embedderPromise = null;
async function getEmbedder() {
  if (!_embedderPromise) {
    _embedderPromise = (async () => {
      const { pipeline } = await import('@xenova/transformers');
      return pipeline('feature-extraction', 'Xenova/all-MiniLM-L12-v2');
    })();
  }
  return _embedderPromise;
}

async function embedOne(text) {
  const embedder = await getEmbedder();
  const out = await embedder(text, { pooling: 'mean', normalize: true });
  return Array.from(out.data);
}

async function getChromaCollectionForUser(userId) {
  const { ChromaClient } = await import('chromadb');
  const client = new ChromaClient({
    host: '208.109.228.76',
    port: 8031,
    ssl: false,
  });
  const coll = await client.getOrCreateCollection({
    name: `user_${userId}_records`,
    embeddingFunction: null
  });
  return coll;
}

// ---------------- Prompts & helpers (existing) ----------------
function categoryPrompt(category) {
  switch ((category || '').toLowerCase()) {
    case 'medical':
      return 'Extract medical information: conditions, allergies, medications, and any hospitalizations.';
    case 'profile':
      return 'Summarize the person’s profile including full name, DOB, location, occupation, and education.';
    case 'timeline':
      return 'List important life events in chronological order with approximate dates.';
    case 'relationships':
      return 'Describe the person’s family and social relationships including parents, spouse, children, siblings.';
    case 'family-tree':
    case 'family_tree':
      return 'Generate a family tree in the form A —[relationship]→ B.';
    default:
      return 'Answer the question based on the document text.';
  }
}

// Legacy scope helpers kept for offline & category flows
async function fetchScopedText(userId, scope) {
  const type = scope?.type || 'all';

  if (type === 'latest') {
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text
         FROM records
        WHERE user_id = ?
        ORDER BY id DESC
        LIMIT 1`,
      [userId]
    );
    const r = rows?.[0];
    if (!r?.extracted_text) return '';
    return `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text}\n`;
  }

  if (type === 'all') {
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text
         FROM records
        WHERE user_id = ?
        ORDER BY id DESC`,
      [userId]
    );
    if (!rows?.length) return '';
    return rows
      .map((r) => `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text || ''}\n`)
      .join('\n-------------------------\n');
  }

  if (type === 'ids') {
    const cleanIds = Array.isArray(scope?.ids)
      ? scope.ids.map(Number).filter(Number.isInteger)
      : [];
    if (!cleanIds.length) return '';
    const placeholders = cleanIds.map(() => '?').join(',');
    const params = [...cleanIds, userId];
    const rows = await allAsync(
      `SELECT id, file_name, extracted_text
         FROM records
        WHERE id IN (${placeholders}) AND user_id = ?
        ORDER BY id DESC`,
      params
    );
    if (!rows?.length) return '';
    return rows
      .map((r) => `[[${r.file_name || `Record ${r.id}`}]]\n${r.extracted_text || ''}\n`)
      .join('\n-------------------------\n');
  }

  return fetchScopedText(userId, { type: 'all' });
}

function splitDocumentIntoChunks(text, maxTokensPerChunk, ratio = TOKEN_CHAR_RATIO) {
  const maxChars = maxTokensPerChunk * ratio;
  const chunks = [];
  let start = 0;

  while (start < text.length) {
    let end = start + maxChars;
    if (end >= text.length) end = text.length;
    else {
      const lastSpace = text.lastIndexOf(' ', end);
      if (lastSpace > start) end = lastSpace;
    }
    chunks.push(text.slice(start, end));
    start = end;
  }

  return chunks;
}

function extractGraniteStreamedAnswer(rawData) {
  if (!rawData || typeof rawData !== 'string') return 'No answer returned.';
  const lines = rawData.trim().split('\n');
  let answer = '';
  for (const line of lines) {
    try {
      const obj = JSON.parse(line);
      if (obj.response) answer += obj.response;
      if (obj.done) break;
    } catch (_) {}
  }
  return answer.trim() || 'No answer returned.';
}

// Low-repetition generation options for Ollama-compatible backends
function genOptions() {
  return {
    // top-level (some servers accept these)
    max_tokens: 512,
    temperature: 0.2,
    top_p: 0.9,
    // nested (Ollama-style) options
    options: {
      num_predict: 512,
      temperature: 0.2,
      top_p: 0.9,
      repeat_penalty: 1.25,
      presence_penalty: 0.2,
      frequency_penalty: 0.2,
      stop: ["\n\nCONTEXT:", "\n\nQUESTION:", "\n\nAnswer:", "\n\nContext:"]
    }
  };
}

async function askGranite(prompt) {
  const body = {
    model: SLM_MODEL,
    prompt,
    stream: false,
    ...genOptions(),
  };
  const response = await axios.post(SLM_URL, body, { timeout: 600000 });
  if (DEBUG) console.log('Granite raw response:', response.data?.slice?.(0, 200) || typeof response.data);
  return extractGraniteStreamedAnswer(response.data);
}

// ---------------- Category (kept as is; not RAG) ----------------
ipcMain.handle('ask:on:category', async (_event, { category, token, scope }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  try {
    const mergedText = await fetchScopedText(decoded.userId, scope);
    if (!mergedText.trim()) return { success: false, error: 'No document text found' };

    const instructions = `
Your task is to: ${categoryPrompt(category)}
If multiple files are present (marked like [[filename]]), reconcile conflicts sensibly.
Provide only the answer itself. Avoid repetition, be concise.
`;

    const answer = await askGranite(`
Use the following document text to answer. Do not repeat words, avoid stuttering.

${mergedText}

Instruction: ${instructions}
Answer:
`);
    return { success: true, answer };
  } catch (err) {
    console.error('SLM (online) category error:', err.message);
    return { success: false, error: 'Failed to contact Granite API.' };
  }
});

// ---------------- RAG (non-streaming) ----------------
ipcMain.handle('ask:on:question', async (_event, { question, token, scope, topK = 4 }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) return { success: false, error: 'Not authenticated' };

  try {
    const coll = await getChromaCollectionForUser(decoded.userId);
    const qEmb = await embedOne(question);
    const result = await coll.query({ queryEmbeddings: [qEmb], nResults: topK });

    const docs = result.documents?.[0] || [];
    const metas = result.metadatas?.[0] || [];
    const context = docs.join('\n---\n');

    if (!context.trim()) return { success: true, answer: 'No relevant context found.' };

    const prompt = `Answer the question using ONLY this context. Be concise. Do not repeat words or syllables.

CONTEXT:
${context}

QUESTION: ${question}

Answer:`;

    const answer = await askGranite(prompt);
    return { success: true, answer, sources: metas };
  } catch (err) {
    console.error('SLM (online) Q&A error:', err.message);
    return { success: false, error: 'Failed to contact Granite API.' };
  }
});

// ---------------- RAG (streaming over IPC) ----------------
ipcMain.on('ask:on:question:stream', async (event, { question, token, scope, topK = 4 }) => {
  const decoded = decodeToken(token);
  if (!decoded?.userId) {
    event.sender.send('ask:on:question:stream:error', 'Not authenticated');
    return;
  }
  try {
    const coll = await getChromaCollectionForUser(decoded.userId);
    const qEmb = await embedOne(question);
    const result = await coll.query({ queryEmbeddings: [qEmb], nResults: topK });

    const docs = result.documents?.[0] || [];
    const metas = result.metadatas?.[0] || [];
    const context = docs.join('\n---\n');

    // send RAG sources first
    event.sender.send(
      'ask:on:question:stream:chunk',
      JSON.stringify({
        type: 'sources',
        sources: metas.map((m, i) => ({ ...m, preview: (docs[i] || '').slice(0, 220) }))
      })
    );

    if (!context.trim()) {
      event.sender.send('ask:on:question:stream:chunk', JSON.stringify({ response: 'No relevant context found.' }));
      event.sender.send('ask:on:question:stream:chunk', JSON.stringify({ type: 'done' }));
      return;
    }

    // stream Granite (NDJSON lines) with repetition controls
    const body = {
      model: SLM_MODEL,
      prompt: `Answer the question using ONLY this context. Be concise. Do not repeat words or syllables.\n\nCONTEXT:\n${context}\n\nQUESTION: ${question}\n\nAnswer:`,
      stream: true,
      ...genOptions(),
    };

    const resp = await axios.post(SLM_URL, body, { responseType: 'stream', timeout: 0 });

    // forward line(s) as-is; downstream will split by \n
    resp.data.on('data', (buf) => {
      const s = buf.toString('utf-8');
      if (s) event.sender.send('ask:on:question:stream:chunk', s);
    });
    resp.data.on('end', () => {
      event.sender.send('ask:on:question:stream:chunk', JSON.stringify({ type: 'done' }));
    });
    resp.data.on('error', (e) => {
      event.sender.send('ask:on:question:stream:error', e.message || 'Stream error');
    });
  } catch (e) {
    event.sender.send('ask:on:question:stream:error', e.message || 'Failed to start stream');
  }
});
