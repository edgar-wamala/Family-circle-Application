// src/app/ipc/ipcMainHandlers.js
const { ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { app } = require('electron');

const userModel = require('../model/userModel');
const { db, getAsync, runAsync } = require('../database/db');

// 🔌 Ollama process controls
const { ensureStarted, stop: stopOllama } = require('./ollamaProcess');

// ---------- Auth handlers ----------
ipcMain.handle('auth:register', async (_event, { email, password }) => {
  try {
    await userModel.registerUser({ email, password });
    return { success: true };
  } catch (err) {
    console.error('Register error:', err.message);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('auth:login', async (_event, { email, password }) => {
  try {
    const token = await userModel.validateLogin({ email, password });

    // ✅ Ensure Ollama is up after successful login
    try { await ensureStarted({ log: true }); } catch (e) {
      console.warn('Ollama ensure-started after login failed:', e.message);
    }

    return { success: true, token };
  } catch (err) {
    console.error('Login error:', err.message);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('auth:get-current-user', async (_event, token) => {
  try {
    const user = await userModel.getCurrentUser(token);
    if (!user) return { success: false, error: 'Not authenticated' };
    return { success: true, data: user };
  } catch (err) {
    console.error('Get current user error:', err.message);
    return { success: false, error: 'Failed to get current user' };
  }
});

ipcMain.handle('auth:logout', async () => {
  // ✅ Stop Ollama if we started it
  try { await stopOllama({ log: true }); } catch (e) {
    console.warn('Ollama stop on logout warning:', e.message);
  }
  return { success: true };
});

// ---------- Profile Update ----------
function saveProfilePhotoToAppData(userId, sourcePath) {
  if (!sourcePath) return null;
  try {
    const imgDir = path.join(app.getPath('userData'), 'profile_photos');
    if (!fs.existsSync(imgDir)) fs.mkdirSync(imgDir, { recursive: true });
    const ext = path.extname(sourcePath) || '.jpg';
    const dest = path.join(imgDir, `user_${userId}${ext}`);
    fs.copyFileSync(sourcePath, dest);
    return dest;
  } catch (e) {
    console.error('saveProfilePhotoToAppData error:', e.message);
    return null;
  }
}

ipcMain.handle('auth:update-profile', async (_event, { token, profile }) => {
  try {
    const user = await userModel.getCurrentUser(token);
    if (!user) return { success: false, error: 'Not authenticated' };

    // Handle photo copy (if a new photo path comes in from renderer)
    let profile_photo_path = user.profile_photo_path || null;
    if (profile?.photoPath) {
      const saved = saveProfilePhotoToAppData(user.id, profile.photoPath);
      if (saved) profile_photo_path = saved;
    }

    // Use the model helper to update
    const fresh = await userModel.updateProfile(user.id, {
      email: profile?.email,
      name: profile?.name,
      phone: profile?.phone,
      age: profile?.age,
      dob: profile?.dob,
      gender: profile?.gender,
      profile_photo_path
    });

    return { success: true, data: fresh };
  } catch (err) {
    console.error('auth:update-profile error:', err);
    return { success: false, error: 'Failed to update profile' };
  }
});

// ---------- Other feature handlers (existing app) ----------
require('./uploadHandler');
require('./recordsHandler');
// Granite routes
require('./askOnHandler');         // registers 'ask:on:*'
require('./askOffHandler');        // registers 'ask:off:*'

// Ollama routes (status + ensure/stop defined there)
require('./ollamaHandler');        // registers 'ollama:*'

module.exports = {};
