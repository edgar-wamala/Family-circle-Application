// --- src/preload.js ---
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // Auth
  login: (credentials) => ipcRenderer.invoke('auth:login', credentials),
  register: (credentials) => ipcRenderer.invoke('auth:register', credentials),
  logout: () => ipcRenderer.invoke('auth:logout'),
  decodeToken: (token) => ipcRenderer.invoke('auth:decode-token', token),
  getCurrentUser: (token) => ipcRenderer.invoke('auth:get-current-user', token),

  // Profile
  updateUserProfile: (profile, token) => ipcRenderer.invoke('auth:update-profile', { profile, token }),

  // Upload
  uploadFiles: (data) => ipcRenderer.invoke('upload:files', data),

  // Records
  getAllRecords: (token) => ipcRenderer.invoke('records:get-all', token),
  getRecordById: (id, token) => ipcRenderer.invoke('records:get-one', { id, token }),
  deleteRecord: (id, token) => ipcRenderer.invoke('records:delete', { id, token }),
  deleteRecords: (ids, token) => ipcRenderer.invoke('records:delete-many', { ids, token }),

  // Q&A — Explicit Online/Offline Granite (default scope = 'all')
  askQuestionOn:  (question, token, scope = { type: 'all' }) => ipcRenderer.invoke('ask:on:question', { question, token, scope }),
  askQuestionOff: (question, token, scope = { type: 'all' }) => ipcRenderer.invoke('ask:off:question', { question, token, scope }),
  askCategoryOn:  (category, token, scope = { type: 'all' }) => ipcRenderer.invoke('ask:on:category', { category, token, scope }),
  askCategoryOff: (category, token, scope = { type: 'all' }) => ipcRenderer.invoke('ask:off:category', { category, token, scope }),

  // Photos
  getAllPhotos: (token) => ipcRenderer.invoke('photos:get-all', token),

  // Music
  getAllMusic: (token) => ipcRenderer.invoke('music:get-all', token),

  // Ollama status + controls
  getOllamaStatus: () => ipcRenderer.invoke('ollama:status'),
  ensureOllamaStarted: () => ipcRenderer.invoke('ollama:ensure-started'),
  stopOllama: () => ipcRenderer.invoke('ollama:stop'),

  // Navigation helper
  navigateTo: (page) => ipcRenderer.send('navigate-to', page),

  // Streaming (online)
  askStreamStart: ({ question, token, scope, topK = 4 }) =>
    ipcRenderer.send('ask:on:question:stream', { question, token, scope, topK }),
  onAskStreamChunk: (cb) =>
    ipcRenderer.on('ask:on:question:stream:chunk', (_e, data) => cb(data)),
  onAskStreamError: (cb) =>
    ipcRenderer.on('ask:on:question:stream:error', (_e, msg) => cb(msg)),
  // ✨ allow renderer to remove old listeners before starting a new stream
  removeAskStreamListeners: () => {
    ipcRenderer.removeAllListeners('ask:on:question:stream:chunk');
    ipcRenderer.removeAllListeners('ask:on:question:stream:error');
  },
});
