// token check
const token = localStorage.getItem('token');
if (!token) {
  window.location.href = "login.html";
}

// -----------------------------
// Utility / Auth
// -----------------------------
function logout() {
  try { window.api.logout?.(); } catch (e) {}
  // stop Ollama watcher on logout
  if (slmProbeTimer) { clearInterval(slmProbeTimer); slmProbeTimer = null; }
  localStorage.clear();
  window.location.href = "login.html";
}

// -----------------------------
// Inline notices (uploads)
// -----------------------------
function showRecordMessage(type, text) {
  const el = document.getElementById('recordMessage');
  if (!el) return;
  const color = type === 'success' ? '#0a7b34' : (type === 'danger' ? '#8c1c13' : '#3a3a3a');
  el.innerHTML = `<div style="padding:6px 10px;border-radius:6px;background:#f7f7f7;color:${color};border:1px solid rgba(0,0,0,.08)">${text}</div>`;
  setTimeout(() => { if (el.textContent && el.textContent.includes(text)) el.innerHTML = ''; }, 4000);
}

function inlineConfirm(targetEl, message, onConfirm, onCancel) {
  targetEl.querySelectorAll('.inline-confirm-wrap').forEach(n => n.remove());
  const wrap = document.createElement('div');
  wrap.className = 'inline-confirm-wrap d-inline-flex align-items-center gap-2';
  wrap.innerHTML = `
    <span class="small text-muted">${message}</span>
    <button type="button" class="btn btn-sm btn-danger">Yes</button>
    <button type="button" class="btn btn-sm btn-secondary">No</button>
  `;
  const [yesBtn, noBtn] = wrap.querySelectorAll('button');
  yesBtn.addEventListener('click', () => { wrap.remove(); onConfirm?.(); });
  noBtn.addEventListener('click', () => { wrap.remove(); onCancel?.(); });
  targetEl.appendChild(wrap);
  yesBtn.focus();
}

// -----------------------------
// SLM / Ollama status (auto-watch on startup)
// -----------------------------
let slmActive = false;
let slmProbeTimer = null;

function updateSLMStatus() {
  const a = document.getElementById("slmArrow");
  const t = document.getElementById("slmText");
  if (slmActive) { a.textContent = "🟢"; t.textContent = "Ollama Active"; }
  else { a.textContent = "🔴"; t.textContent = "Ollama Inactive"; }
}

async function probeOllama() {
  const arrow = document.getElementById("slmArrow");
  const text  = document.getElementById("slmText");
  try {
    text.textContent = "Checking...";
    const status = await window.api.getOllamaStatus();
    slmActive = !!status?.running;
    if (slmActive) {
      arrow.textContent = "🟢";
      text.textContent  = `Ollama${status.version ? " v" + status.version : ""} running`;
    } else {
      arrow.textContent = "🔴";
      text.textContent  = "Ollama not reachable";
    }
  } catch (e) {
    slmActive = false;
    arrow.textContent = "❌";
    text.textContent  = "Check failed";
  }
  updateSLMStatus();
}

async function startOllamaWatch() {
  try {
    // pick / ensure an already-running instance
    await window.api.ensureOllamaStarted();
  } catch (_) {
    // ignore; periodic probe below will keep checking
  }

  await probeOllama();

  // avoid duplicate intervals
  if (slmProbeTimer) clearInterval(slmProbeTimer);
  slmProbeTimer = setInterval(probeOllama, 2000);
}

// Optional manual recheck button
document.getElementById("slmToggleBtn").hidden = false;
document.getElementById("slmToggleBtn").textContent = "Recheck Ollama";
document.getElementById("slmToggleBtn").onclick = probeOllama;

updateSLMStatus();

// -----------------------------
// Section switching
// -----------------------------
function showSection(id) {
  document.querySelectorAll('.section').forEach(div => div.classList.add('hidden'));
  const el = document.getElementById(id);
  if (el) el.classList.remove('hidden');

  const titles = {
    dashboard: "🏠 Dashboard",
    profile: "🙍‍♂️ User Profile",
    upload: "📄 Shared Documents",
    installedAgents: "🧠 Installed Agents",
    qa: "💬 Ask a Question"
  };
  document.getElementById("sectionTitle").textContent = titles[id] || id;

  if (id === 'installedAgents') {
    loadAgentTemplates();
    document.getElementById("agentFeatureContent").textContent = "Select a feature to view its details.";
  }
  if (id === 'upload') loadDocumentRecords();
  if (id === 'profile') loadProfile();
  if (id === 'qa') {
    applyModelUIFromStorage();
    prepareScopePickerOnEnterQA();
  }
}

// -----------------------------
// PROFILE
// -----------------------------
async function loadProfile() {
  const el = document.getElementById("profileDetails");
  el.textContent = '⏳ Loading...';
  try {
    const r = await window.api.getCurrentUser(token);
    if (r && r.success) {
      const u = r.data || {};
      el.innerHTML = `
        <div class="d-flex align-items-center gap-3">
          <img src="${u.profile_photo_path ? `file://${u.profile_photo_path}` : ''}" 
               alt="Profile photo" 
               style="width:48px;height:48px;border-radius:50%;object-fit:cover;${u.profile_photo_path ? '' : 'display:none;'}"
               id="profileDetailsPhoto">
          <div>
            <div><strong>${u.name || 'Unnamed User'}</strong></div>
            <div class="small-muted">${u.email || 'N/A'}</div>
          </div>
        </div>
      `;

      const form = document.getElementById("profileForm");
      form.style.display = 'block';

      document.getElementById("profileEmail").value  = u.email || '';
      document.getElementById("profileName").value   = u.name || '';
      document.getElementById("profilePhone").value  = u.phone || '';
      document.getElementById("profileDob").value    = u.dob || '';
      document.getElementById("profileAge").value    = (u.age ?? '') === null ? '' : (u.age ?? '');
      document.getElementById("profileGender").value = u.gender || '';

      const preview = document.getElementById("profilePhotoPreview");
      if (u.profile_photo_path) {
        preview.src = `file://${u.profile_photo_path}`;
        preview.style.display = '';
      } else {
        preview.style.display = 'none';
      }

      document.getElementById("profileDob").addEventListener("change", () => {
        const dobStr = document.getElementById("profileDob").value;
        const ageInput = document.getElementById("profileAge");
        if (dobStr) {
          const today = new Date();
          const [y,m,d] = dobStr.split('-').map(Number);
          if (y && m && d) {
            let age = today.getFullYear() - y;
            const bd = new Date(y, m - 1, d);
            const hasHadBirthday = (today.getMonth() > bd.getMonth()) ||
                                   (today.getMonth() === bd.getMonth() && today.getDate() >= bd.getDate());
            if (!hasHadBirthday) age -= 1;
            ageInput.value = Math.max(0, age);
          }
        }
      });

      document.getElementById("profilePhoto").addEventListener("change", (e) => {
        const file = e.target.files?.[0];
        if (file && file.path) {
          preview.src = `file://${file.path}`;
          preview.style.display = '';
        }
      });

      document.getElementById("saveProfileBtn").onclick = async () => {
        const updatedData = {
          email:  document.getElementById("profileEmail").value.trim(),
          name:   document.getElementById("profileName").value.trim(),
          phone:  document.getElementById("profilePhone").value.trim(),
          dob:    document.getElementById("profileDob").value || null,
          age:    document.getElementById("profileAge").value,
          gender: document.getElementById("profileGender").value || null,
        };

        const photoFile = document.getElementById("profilePhoto").files?.[0];
        if (photoFile && photoFile.path) updatedData.photoPath = photoFile.path;

        if (updatedData.age === '' || isNaN(Number(updatedData.age))) {
          updatedData.age = null;
        } else {
          updatedData.age = Number(updatedData.age);
        }

        document.getElementById("saveStatus").textContent = 'Saving...';
        try {
          const res = await window.api.updateUserProfile(updatedData, token);
          if (res && res.success) {
            document.getElementById("saveStatus").textContent = '✅ Saved successfully!';
            const nu = res.data || {};
            const detailsImg = document.getElementById('profileDetailsPhoto');
            if (nu.profile_photo_path) {
              detailsImg.src = `file://${nu.profile_photo_path}`;
              detailsImg.style.display = '';
              preview.src = `file://${nu.profile_photo_path}`;
              preview.style.display = '';
            }
          } else {
            document.getElementById("saveStatus").textContent = `❌ ${(res && res.error) || 'Failed to save.'}`;
          }
        } catch (e) {
          document.getElementById("saveStatus").textContent = `❌ ${e.message || 'Error'}`;
        }
      };
    } else {
      el.textContent = `❌ ${(r && r.error) || 'Failed to load profile.'}`;
    }
  } catch (err) {
    el.textContent = `❌ ${err.message || 'Failed to load profile.'}`;
  }
}

// -----------------------------
// UPLOADS (Documents / Photos / Music)
// -----------------------------
function selectUploadTab(tabId) {
  document.querySelectorAll('.upload-tab').forEach(t => t.classList.remove('active'));
  const el = document.getElementById(tabId);
  if (el) el.classList.add('active');
  if (tabId === 'photos') loadUploadedPhotos();
  if (tabId === 'music') loadUploadedMusic();
}

async function handleUpload() {
  const docInput = document.getElementById("docUpload");
  const doc = docInput?.files?.[0];
  const statusEl = document.getElementById("uploadStatus");
  if (!token || !doc) {
    statusEl.textContent = "❌ Please log in and select a document.";
    return;
  }
  statusEl.textContent = '⏳ Uploading...';
  try {
    const res = await window.api.uploadFiles({ docPath: doc.path, photoPaths: [], musicPaths: [], token });
    statusEl.textContent = res && res.success ? "✅ Import successful" : `❌ ${(res && res.error) || 'Upload failed.'}`;
    if (res && res.success) {
      await loadDocumentRecords();
      // refresh "Choose specific files" immediately
      if (document.getElementById('scopeSelected')) { refreshScopeFiles(); }
    }
  } catch (err) {
    statusEl.textContent = `❌ ${err.message || 'Upload failed.'}`;
  }
}
document.getElementById("docUpload").addEventListener("change", handleUpload);

async function loadDocumentRecords() {
  const c = document.getElementById("recordItems");
  c.innerHTML = '<div class="small-muted">⏳ Loading records...</div>';
  try {
    const res = await window.api.getAllRecords(token);
    c.innerHTML = '';
    if (!res || !res.success || !Array.isArray(res.data) || res.data.length === 0) {
      c.innerHTML = '<div class="text-muted">No files found.</div>';
      document.getElementById("selectedFileMeta").textContent = '';
      document.getElementById("extractedText").textContent = '';
      return;
    }

    res.data.forEach(r => {
      const row = document.createElement("div");
      row.className = "record-item";
      row.dataset.id = r.id;

      const left = document.createElement("div");
      left.style.display = 'flex';
      left.style.alignItems = 'center';
      left.style.gap = '8px';
      left.innerHTML = `<span aria-hidden="true">📄</span> <span>${r.file_name || ('Record ' + r.id)}</span>`;

      const right = document.createElement("div");
      right.style.display = 'flex';
      right.style.alignItems = 'center';
      right.style.gap = '10px';

      const date = document.createElement("small");
      date.className = 'small-muted';
      date.textContent = r.uploaded_at || '';

      const delBtn = document.createElement("button");
      delBtn.type = 'button';
      delBtn.className = 'btn btn-sm btn-outline-danger';
      delBtn.title = 'Delete this file';
      delBtn.setAttribute('aria-label', 'Delete imported file');
      delBtn.textContent = '🗑️';

      delBtn.onclick = (e) => {
        e.stopPropagation();
        inlineConfirm(
          right,
          `Delete "${r.file_name || ('Record ' + r.id)}"? This cannot be undone.`,
          async () => {
            try {
              delBtn.disabled = true;
              delBtn.textContent = '…';
              const delRes = await window.api.deleteRecord(r.id, token);
              if (delRes && delRes.success) {
                const metaEl = document.getElementById("selectedFileMeta");
                if (metaEl.textContent && metaEl.textContent.startsWith(r.file_name || `Record ${r.id}`)) {
                  metaEl.textContent = '';
                  document.getElementById("extractedText").textContent = '';
                }
                showRecordMessage('success', '✅ File deleted.');
                await loadDocumentRecords();
                // keep specific-files list in sync after deletion
                if (document.getElementById('scopeSelected')) { refreshScopeFiles(); }
              } else {
                showRecordMessage('danger', `❌ Failed to delete: ${(delRes && delRes.error) || 'Unknown error'}`);
                delBtn.disabled = false;
                delBtn.textContent = '🗑️';
              }
            } catch (err) {
              showRecordMessage('danger', `❌ Error: ${err.message || 'Failed to delete'}`);
              delBtn.disabled = false;
              delBtn.textContent = '🗑️';
            }
          },
          () => {
            showRecordMessage('info', 'Deletion cancelled.');
          }
        );
      };

      right.appendChild(date);
      right.appendChild(delBtn);

      row.appendChild(left);
      row.appendChild(right);

      row.onclick = async () => {
        try {
          const s = await window.api.getRecordById(r.id, token);
          const m = document.getElementById("selectedFileMeta");
          const t = document.getElementById("extractedText");
          if (!s || !s.success) { m.textContent = ''; t.textContent = '❌ Failed to load text.'; return; }
          const fl = s.data.file_name || r.file_name || `Record ${r.id}`;
          const dl = s.data.uploaded_at || r.uploaded_at || '';
          m.textContent = `${fl}${dl ? ' • ' + dl : ''}`;
          t.textContent = s.data.summary || s.data.extracted_text || '';
        } catch (err) {
          document.getElementById("extractedText").textContent = `❌ ${err.message || 'Error'}`;
        }
      };

      c.appendChild(row);
    });
  } catch (err) {
    c.innerHTML = `<div class="text-danger">❌ ${(err && err.message) || 'Failed to load records.'}</div>`;
  }
}

// PHOTOS
function displayPhotos(photoPaths) {
  const container = document.getElementById('uploadedPhotos');
  container.innerHTML = '';
  if (!Array.isArray(photoPaths) || photoPaths.length === 0) {
    container.innerHTML = '<div class="small-muted">No photos uploaded.</div>';
    return;
  }
  photoPaths.forEach(photoPath => {
    const img = document.createElement('img');
    img.src = `file://${photoPath}`;
    img.style.width = '120px';
    img.style.height = '120px';
    img.style.objectFit = 'cover';
    img.style.borderRadius = '6px';
    container.appendChild(img);
  });
}

async function loadUploadedPhotos() {
  const statusEl = document.getElementById("photoUploadStatus");
  statusEl.textContent = '⏳ Loading photos...';
  try {
    const res = await window.api.getAllPhotos(token);
    if (res && res.success) {
      displayPhotos(res.data || []);
      statusEl.textContent = '';
    } else {
      statusEl.textContent = `❌ ${(res && res.error) || 'Failed to load photos.'}`;
    }
  } catch (err) {
    statusEl.textContent = `❌ ${err.message || 'Failed to load photos.'}`;
  }
}

async function handlePhotoUpload() {
  const photos = Array.from(document.getElementById("photoUpload").files || []);
  const statusEl = document.getElementById("photoUploadStatus");
  if (!token || !photos.length) {
    statusEl.textContent = "❌ Please select photos to upload.";
    return;
  }
  statusEl.textContent = '⏳ Uploading photos...';
  try {
    const photoPaths = photos.map(f => f.path);
    const res = await window.api.uploadFiles({ docPath: null, photoPaths, musicPaths: [], token });
    statusEl.textContent = res && res.success ? "✅ Photos uploaded!" : `❌ ${(res && res.error) || 'Upload failed.'}`;
    if (res && res.success) loadUploadedPhotos();
  } catch (err) {
    statusEl.textContent = `❌ ${err.message || 'Upload failed.'}`;
  }
}
document.getElementById("photoUpload").addEventListener("change", handlePhotoUpload);

// MUSIC
function displayMusic(trackPaths) {
  const container = document.getElementById('uploadedMusic');
  container.innerHTML = '';
  if (!Array.isArray(trackPaths) || trackPaths.length === 0) {
    container.innerHTML = '<div class="small-muted">No music uploaded.</div>';
    return;
  }

  trackPaths.forEach((p) => {
    const row = document.createElement('div');
    row.className = 'd-flex align-items-center justify-content-between border rounded p-2';

    const left = document.createElement('div');
    left.className = 'd-flex align-items-center gap-2';
    const name = document.createElement('span');
    name.textContent = `🎵 ${p.split(/[\\/]/).pop()}`;
    left.appendChild(name);

    const right = document.createElement('div');
    const audio = document.createElement('audio');
    audio.controls = true;
    audio.preload = 'metadata';
    audio.src = `file://${p}`;
    audio.style.width = '260px';
    right.appendChild(audio);

    row.appendChild(left);
    row.appendChild(right);
    container.appendChild(row);
  });
}

async function loadUploadedMusic() {
  const statusEl = document.getElementById("musicUploadStatus");
  statusEl.textContent = '⏳ Loading music...';
  try {
    const res = await window.api.getAllMusic(token);
    if (res && res.success) {
      displayMusic(res.data || []);
      statusEl.textContent = '';
    } else {
      statusEl.textContent = `❌ ${(res && res.error) || 'Failed to load music.'}`;
    }
  } catch (err) {
    statusEl.textContent = `❌ ${err.message || 'Failed to load music.'}`;
  }
}

async function handleMusicUpload() {
  const musicFiles = Array.from(document.getElementById("musicUpload").files || []);
  const statusEl = document.getElementById("musicUploadStatus");
  if (!token || !musicFiles.length) {
    statusEl.textContent = "❌ Please select music files to upload.";
    return;
  }
  statusEl.textContent = '⏳ Uploading music...';
  try {
    const musicPaths = musicFiles.map(f => f.path);
    const res = await window.api.uploadFiles({ docPath: null, photoPaths: [], musicPaths, token });
    statusEl.textContent = res && res.success ? "✅ Music uploaded!" : `❌ ${(res && res.error) || 'Upload failed.'}`;
    if (res && res.success) loadUploadedMusic();
  } catch (err) {
    statusEl.textContent = `❌ ${err.message || 'Upload failed.'}`;
  }
}
document.getElementById("musicUpload").addEventListener("change", handleMusicUpload);

// -----------------------------
// MODEL SELECTION (must choose before asking)
// -----------------------------
const MODEL_KEY = 'qaModel'; // 'offline' | 'online' | 'none'

function getStoredModel() {
  return localStorage.getItem(MODEL_KEY) || 'none';
}
function storeModel(value) {
  localStorage.setItem(MODEL_KEY, value);
}

function setAskControlsEnabled(enabled) {
  const askBtn = document.getElementById('askBtn');
  const qEl = document.getElementById('questionInput');
  if (askBtn) askBtn.disabled = !enabled;
  if (qEl) qEl.disabled = !enabled;
  if (qEl) qEl.placeholder = enabled ? 'Type your question…' : 'Select a model to enable asking…';
}

function updateModelBadge(state) {
  const badge = document.getElementById('modelStatusBadge');
  if (!badge) return;
  if (state === 'none') {
    badge.textContent = 'No model selected';
    badge.className = 'badge bg-warning text-dark';
  } else if (state === 'offline') {
    badge.textContent = 'Model: Local / Offline';
    badge.className = 'badge bg-success';
  } else if (state === 'online') {
    badge.textContent = 'Model: Online Granite';
    badge.className = 'badge bg-success';
  }
}

function clearModelButtonsActive() {
  ['btnModelOffline','btnModelOnline'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove('btn-primary');
    el.classList.add('btn-outline-secondary');
  });
}
function activateButton(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.remove('btn-outline-secondary');
  el.classList.add('btn-primary');
}

function emphasizeNotice() {
  const picker = document.getElementById('modelPicker');
  const notice = document.getElementById('modelNotice');
  picker?.classList.add('attention');
  if (notice) {
    notice.style.boxShadow = '0 0 0 3px rgba(255,193,7,.35)';
    setTimeout(() => notice.style.boxShadow = '', 1200);
  }
  setTimeout(() => picker?.classList.remove('attention'), 1200);
}

function applyModelUIFromStorage() {
  const state = getStoredModel();
  const notice = document.getElementById('modelNotice');

  clearModelButtonsActive();

  if (state === 'offline') {
    activateButton('btnModelOffline');
    updateModelBadge('offline');
    setAskControlsEnabled(true);
    if (notice) {
      notice.style.display = 'none';
      document.getElementById('modelNoticeText').textContent = '';
    }
  } else if (state === 'online') {
    activateButton('btnModelOnline');
    updateModelBadge('online');
    setAskControlsEnabled(true);
    if (notice) {
      notice.style.display = 'none';
      document.getElementById('modelNoticeText').textContent = '';
    }
  } else {
    updateModelBadge('none');
    setAskControlsEnabled(false);
    if (notice) {
      notice.style.display = '';
      document.getElementById('modelNoticeText').textContent =
        'Select a model (Local / Offline or Online Granite) to start asking questions.';
    }
  }
}

(function initModelPicker() {
  if (!localStorage.getItem(MODEL_KEY)) {
    storeModel('none'); // start neutral
  }
  applyModelUIFromStorage();

  const btnOffline = document.getElementById('btnModelOffline');
  const btnOnline  = document.getElementById('btnModelOnline');

  btnOffline?.addEventListener('click', () => {
    storeModel('offline');
    applyModelUIFromStorage();
  });

  btnOnline?.addEventListener('click', () => {
    storeModel('online');
    applyModelUIFromStorage();
  });
})();

// -----------------------------
// Scope picker — always fetch fresh list
// -----------------------------
async function refreshScopeFiles() {
  try {
    const res = await window.api.getAllRecords(token);
    const rows = (res?.success && Array.isArray(res.data)) ? res.data : [];
    renderScopeFileList(rows);
  } catch {
    renderScopeFileList([]);
  }
}

function renderScopeFileList(rows) {
  const list = document.getElementById('scopeFileList');
  if (!list) return;
  list.innerHTML = '';
  if (!rows?.length) {
    list.innerHTML = '<div class="text-muted">No files available.</div>';
    return;
  }
  rows.forEach(r => {
    const id = `scopeFile_${r.id}`;
    const wrap = document.createElement('div');
    wrap.className = 'form-check';
    wrap.innerHTML = `
      <input class="form-check-input" type="checkbox" value="\${r.id}" id="\${id}">
      <label class="form-check-label" for="\${id}">
        \${r.file_name || \`Record \${r.id}\`} <span class="small-muted">• \${r.uploaded_at || ''}</span>
      </label>
    `;
    list.appendChild(wrap);
  });
}

function currentScopeFromUI() {
  const latest = document.getElementById('scopeLatest')?.checked;
  const all    = document.getElementById('scopeAll')?.checked;
  const ids    = document.getElementById('scopeSelected')?.checked;

  if (latest) return { type: 'latest' };
  if (all)    return { type: 'all' };

  const list = document.querySelectorAll('#scopeFileList input[type="checkbox"]:checked');
  const selectedIds = Array.from(list).map(el => Number(el.value)).filter(Number.isInteger);
  return { type: 'ids', ids: selectedIds };
}

['scopeLatest','scopeAll','scopeSelected'].forEach(id => {
  const el = document.getElementById(id);
  el?.addEventListener('change', async () => {
    const area = document.getElementById('scopePickerArea');
    if (document.getElementById('scopeSelected').checked) {
      area.style.display = '';
      await refreshScopeFiles();
    } else {
      area.style.display = 'none';
    }
  });
});

function prepareScopePickerOnEnterQA() {
  const area = document.getElementById('scopePickerArea');
  if (document.getElementById('scopeSelected').checked) {
    area.style.display = '';
    refreshScopeFiles();
  } else {
    area.style.display = 'none';
  }
}

// -----------------------------
// QA / Ask a Question
// -----------------------------
async function askQuestion() {
 const qEl = document.getElementById("questionInput");
 const a   = document.getElementById("answer");
 const q   = (qEl?.value || '').trim();

 const chosen = getStoredModel(); // 'offline' | 'online' | 'none'
 if (chosen === 'none') { emphasizeNotice(); a.innerHTML = `<div class="text-muted">Select a model above to continue.</div>`; return; }
 if (!q) { a.textContent = "❌ Please enter a question."; return; }

 const scope = currentScopeFromUI();

 const showThinking = (label) => {
   a.innerHTML = `<div class="d-flex align-items-center text-muted">
     <div class="spinner-border spinner-border-sm me-2"></div>
     <span>Thinking (\${label})…</span>
   </div>`;
 };

 await new Promise(requestAnimationFrame);

 try {
   const label = (chosen === 'online') ? 'Online Granite' : 'Local / Offline';

   if (chosen === 'online') {
 a.innerHTML = '<b>Response:</b> ';
 const sourcesId = 'ragSources';
 let sourcesBox = document.getElementById(sourcesId);
 if (!sourcesBox) {
   sourcesBox = document.createElement('div');
   sourcesBox.id = sourcesId;
   sourcesBox.className = 'mt-2 small-muted';
   a.insertAdjacentElement('beforebegin', sourcesBox);
 }
 sourcesBox.textContent = '';
 showThinking(label);

 // 🔑 prevent duplicate listeners across runs
 window.api.removeAskStreamListeners();

 let buffer = '';
 const onChunk = (data) => {
   buffer += data; // may contain multiple lines or partial JSON
   const parts = buffer.split('\n');
   buffer = parts.pop(); // keep any incomplete tail

   for (const line of parts) {
     if (!line.trim()) continue;
     try {
       const obj = JSON.parse(line);
       if (obj.type === 'sources') {
         sourcesBox.innerHTML = obj.sources.map(s =>
           `<div class="small" style="border-left:3px solid #0d6efd;padding-left:8px;margin-top:6px">
              <b>\${s.file_name || s.filename || 'File'}</b> • chunk \${s.chunk}
              <div style="opacity:.8">\${(s.preview || '').replace(/</g,'&lt;')}...</div>
            </div>`
         ).join('');
       } else if (obj.response) {
         if (a.textContent.includes('Thinking')) a.innerHTML = '<b>Response:</b> ';
         a.innerHTML += obj.response;
       } else if (obj.type === 'done') {
         // flush any remaining partial and finish
         buffer = '';
       }
     } catch {
       // ignore non-JSON lines (some backends send keepalives)
     }
   }
 };
 const onError = (msg) => { a.innerHTML = `❌ \${msg || 'Stream error'}`; };

 window.api.onAskStreamChunk(onChunk);
 window.api.onAskStreamError(onError);
 window.api.askStreamStart({ question: q, token, scope, topK: 4 });
}

   else {
     showThinking(label);
     const r = await window.api.askQuestionOff(q, token, scope);
     a.textContent = (r && r.success) ? r.answer : `❌ \${(r && r.error) || 'An error occurred.'}`;
   }
 } catch (err) {
   a.textContent = `❌ \${err?.message || 'Something went wrong while processing your question.'}`;
 }
}

// -----------------------------
// Agents (unchanged)
// -----------------------------
const agentTemplatesData = [
  { name: "Agent Template", agents: ["Private Data", "Family Calendar", "Misplaced Items", "Relationships"] }
];

function loadAgentTemplates() {
  const container = document.getElementById("agentTemplates");
  container.innerHTML = '';
  document.getElementById("templateAgents").classList.add("hidden");

  agentTemplatesData.forEach(template => {
    const div = document.createElement("div");
    div.className = "agent-template-folder";
    div.innerHTML = `<div style="font-size:28px;line-height:1">📁</div><div style="margin-top:8px;font-weight:600">\${template.name}</div>`;
    div.onclick = () => showAgents(template);
    container.appendChild(div);
  });
}

function showAgents(template) {
  document.getElementById("agentTemplates").classList.add("hidden");
  const agentsContainer = document.getElementById("templateAgents");
  const list = document.getElementById("agentsList");
  const nameSpan = document.getElementById("selectedTemplateName");
  nameSpan.textContent = template.name || 'Agent Template';
  list.innerHTML = '';
  (template.agents || []).forEach(agent => {
    const btn = document.createElement("button");
    btn.type = 'button';
    btn.className = "list-group-item list-group-item-action";
    btn.textContent = `🧠 \${agent}`;
    btn.onclick = () => {
      showAgentFeature(agent.toLowerCase().replace(/\s+/g, ""));
    };
    list.appendChild(btn);
  });
  agentsContainer.classList.remove("hidden");
  document.getElementById("agentFeatureContent").textContent = "Select a feature to view its details.";
}

function backToTemplates() {
  document.getElementById("templateAgents").classList.add("hidden");
  document.getElementById("agentTemplates").classList.remove("hidden");
  document.getElementById("agentFeatureContent").textContent = "Select a feature to view its details.";
}

function showAgentFeature(feature) {
  const c = document.getElementById("agentFeatureContent");
  const map = {
    private: "📄 Private Data Feature Coming Soon",
    calendar: "📅 Family Calendar Feature Coming Soon",
    misplaced: "🧳 Misplaced Items Feature Coming Soon",
    relationships: "👪 Relationships Feature Coming Soon"
  };
  const key = Object.keys(map).find(k => feature.includes(k)) || feature;
  c.textContent = map[key] || "Select a feature to view its details.";
}

// -----------------------------
// Initialize defaults
// -----------------------------
showSection('dashboard');
loadAgentTemplates();

// Start the Ollama watcher on app load
startOllamaWatch();

// Debug helpers
window.__fc = {
  showSection, loadAgentTemplates, showAgents, backToTemplates, loadDocumentRecords, loadUploadedPhotos, loadUploadedMusic, loadProfile
};
